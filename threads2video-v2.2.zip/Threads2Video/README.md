# Threads2Video 2.2

App Android (một APK) biến bài Threads + bình luận thành video dọc 9:16. Vỏ Kotlin + giao diện/engine video bằng web trong WebView.

**Bản 2.2 thay hẳn cách lấy nội dung**: bỏ việc cào trang Threads bằng WebView; dùng **Threads API chính thức của Meta**, hai điểm duyệt bắt buộc, thẻ ảnh dựng từ dữ liệu (không phải ảnh chụp màn hình), và AI chuẩn hóa lời đọc chạy trên máy.

## Luồng dùng

1. Đăng nhập Threads một lần (OAuth chính thức).
2. Nhập **một chủ đề** → “Tìm nội dung”: app tìm bài công khai, lấy replies, loại spam/trùng, xếp hạng.
3. **Điểm duyệt 1**: xem bài nguồn (có permalink) và Top bình luận (mặc định 8; ít hơn thì hiện đúng số thật). Bỏ/thêm/đổi thứ tự/xem toàn văn rồi bấm “Xác nhận Top”. Chưa xác nhận thì chưa tạo thẻ, chưa chuẩn hóa.
4. App dựng **một PNG riêng cho mỗi mục** và tạo `ttsText` (bản đọc) riêng.
5. **Điểm duyệt 2**: mỗi mục hiện ảnh thẻ, `rawText` chỉ đọc, `ttsText` sửa được, cảnh báo nếu cần xem lại. Chỉ mục đã duyệt mới sang video.
6. Engine video cũ: nền, giọng (file/tách theo khoảng lặng/VieNeu Studio/Gemini), timeline, xem trước, xuất 1080×1920 hoặc 720×1280, lưu `Movies/Threads2Video`, chia sẻ, caption.

Nếu API lỗi hoặc chưa được cấp quyền, app **báo đúng nguyên nhân** và đề nghị “Nhập thủ công” (do bạn chọn, gắn nhãn NHẬP THỦ CÔNG, đi qua cùng hai điểm duyệt). **Không bao giờ tự quay về cào trang.**

## Tình trạng thực tế (đọc trước khi dùng)

| Hạng mục | Trạng thái |
|---|---|
| Giao diện, hai điểm duyệt, thẻ PNG, lưu/khôi phục trạng thái, engine video (audio, tách khoảng lặng, timeline, preview, export, MediaStore giả, share) | **Đã kiểm thử**: 102 kiểm tra trong Chromium với cầu nối Android giả (`node tests/e2e/run.js`) |
| Parser Threads API, client, repository, xếp hạng, chuẩn hóa TTS, OAuth (state/PKCE), model manager (tải/tiếp tục/SHA-256), cầu nối | **Đã kiểm thử** bằng 209 kiểm tra Kotlin thuần JVM (`tools/run-jvm-tests.sh`), gồm máy chủ HTTP giả |
| Backend đổi token `backend/token-broker` | **Đã kiểm thử** 19 kiểm tra với Meta giả. **Chưa chạy với Meta thật** |
| **Build APK / biên dịch các file Kotlin dùng `android.*` (MainActivity, SecureTokenStore, …)** | **CHƯA biên dịch được** trong môi trường phát triển (không có Android SDK/Maven). Chạy GitHub Actions để biết kết quả thật; có thể còn lỗi biên dịch nhỏ |
| Gọi Threads API thật (search, replies), OAuth thật | **Chưa thử** — không có credentials Meta. Chặn bởi: App ID/Secret, backend, và có thể cả Meta App Review |
| AI model (llama.cpp/JNI) | **Chưa biên dịch, chưa chạy** (không có NDK). Mặc định APK dùng **luật xác định** (không phải AI sinh văn bản). Xem “AI cục bộ” |
| Thiết bị Samsung A15, Android 16, RAM/nhiệt/30 phút | **Chưa đo** |

## Cấu hình Meta Developer App

1. Tạo app tại developers.facebook.com với use case Threads API. Lấy **App ID** (công khai) và **App Secret** (bí mật — chỉ đặt trên backend).
2. Thêm **Valid OAuth Redirect URI**: `https://<backend-của-bạn>/threads/callback`.
3. Scope app yêu cầu: `threads_basic`, `threads_read_replies`, `threads_keyword_search`. Lưu ý: trang token của Meta không liệt kê `threads_keyword_search`, chỉ trang keyword-search nhắc tới — hãy đối chiếu tên scope trong App Dashboard.
4. **Tìm bài công khai** cần Meta duyệt quyền tìm kiếm. Nguyên văn tài liệu: chưa duyệt thì tìm kiếm “chỉ trên bài do chính người dùng đã xác thực sở hữu”. Khi đó API **không báo lỗi**; app phát hiện khi mọi kết quả là bài của bạn và hiện cảnh báo. Replies của bài người khác có đọc được hay không phụ thuộc quyền/duyệt: chưa xác minh được.
5. API **không trả số tim của bình luận** (theo tài liệu hiện hành). App không hiện/không suy ra số tim; xếp hạng dựa vào nội dung.
6. Hạn mức tìm kiếm: 2.200 truy vấn/24h/người dùng. App giới hạn số truy vấn mỗi lần tìm.

### Backend đổi token (bắt buộc cho đăng nhập)

Meta yêu cầu App Secret khi đổi `code` lấy token ⇒ **không thể làm trong APK**. Dùng `backend/token-broker` (Node ≥ 18, không phụ thuộc thư viện) hoặc tự viết theo cùng hợp đồng:

```bash
THREADS_APP_ID=... THREADS_APP_SECRET=... PUBLIC_BASE_URL=https://ten-mien-cua-ban PORT=8080 node backend/token-broker/server.js
```

Cần đặt sau HTTPS. Broker không lưu token lâu dài (vé 2 phút trong RAM). Chuỗi bảo vệ: `state = nonce.sha256(verifier)`; app giữ `verifier`; app khác chặn deep link cũng không đổi được vé. Trong app: Nội dung → “Kết nối Threads và cấu hình” → nhập App ID + địa chỉ backend → “Đăng nhập Threads”.

**Chưa có backend?** Có đường dự phòng: dán access token tạo thủ công trong App Dashboard (để thử). Token lưu mã hóa bằng Android Keystore; có nút đăng xuất/xóa token.

## Thẻ ảnh (phương án A)

Dựng bằng Canvas từ dữ liệu có cấu trúc, **không** chụp WebView, **không** OCR. Chỉ vẽ: nội dung bình luận, `@username` (công tắc, mặc định **tắt**), số tim (công tắc; chỉ khi API thật sự trả về). Không có chữ/logo Threads, status bar, top/bottom bar, avatar, watermark. Test kiểm tra danh sách chuỗi đã vẽ và dải viền ảnh. Thẻ lưu theo ID (đổi thứ tự không đảo ảnh). Thẻ cao hơn khung video thì engine cuộn theo giọng đọc (như ảnh dài ở bản 2.0).

## Dữ liệu `rawText` / `ttsText`

`rawText` bất biến sau khi nhận từ nguồn; chuẩn hóa chỉ ghi `ttsText` (bỏ emoji, sửa teencode/viết tắt/dấu câu; từ lạ hoặc nhạy cảm thì giữ nguyên và gắn cờ “cần xem lại”). Sửa `ttsText` không đổi ảnh thẻ. Đổi chữ hiển thị trên thẻ là thao tác riêng và bắt duyệt lại. Điểm xếp hạng là **điểm nội bộ**, không phải số liệu Threads.

## AI cục bộ — offline cái gì, online cái gì

- **Có thể offline** (sau khi cài): xếp hạng bình luận, chuẩn hóa lời đọc, caption.
- **Luôn cần Internet**: OAuth, tìm bài/replies Threads, VieNeu Studio, Gemini TTS, OpenAI/Gemini nếu bạn nhập key ở tab Giọng.
- Mặc định (chưa có model hoặc APK không kèm llama.cpp): **luật xác định**, hiển thị “luật xác định (không phải model AI)”.
- Model GGUF (Qwen3 1.7B Q8_0, Qwen3 4B Q4_K_M, giấy phép Apache-2.0; SHA-256 đã đối chiếu trên trang Hugging Face của Qwen ngày 2026-11-15) tải/nhập một lần vào vùng riêng của app (tiếp tục/hủy, kiểm SHA-256, kiểm dung lượng, xóa). Không nhúng model vào APK. **Không khẳng định 4B chạy mượt trên A15** — cần đo.
- Bật llama.cpp (tùy chọn, mặc định tắt): cần NDK + CMake và một bản checkout llama.cpp đã ghim commit mà bạn đã thử:
  `gradle assembleDebug -Pt2v.llama=true -Pt2v.llamaDir=/đường/dẫn/llama.cpp`. Mã JNI `app/src/main/cpp/t2v_llama.cpp` **chưa biên dịch/chạy lần nào**; hãy build, chạy trên thiết bị và đo trước khi tin cậy.
- App trả RAM (giải phóng model) trước khi dựng/xuất video.

## Build và kiểm thử

```bash
gradle testDebugUnitTest assembleDebug        # cần Android SDK; CI (GitHub Actions) làm việc này
node tests/e2e/run.js                          # cần playwright + Chromium
node backend/token-broker/test.js
bash tools/run-jvm-tests.sh                    # chỉ cần JDK + Gradle (dùng Kotlin compiler đi kèm)
```

Repo không có `gradlew`; CI cài Gradle 8.9. APK debug ký bằng `app/debug.keystore` (khóa debug công khai, **không dùng làm khóa phát hành**); không có secret nào trong source/APK (CI có bước quét).

## Checklist hồi quy thủ công trên thiết bị (chưa làm)

Cài trên Android 16; OAuth thành công/hủy/hết hạn; permission denied; chọn video nền từ thư viện; import nhiều file giọng và 1 file dài tách khoảng lặng; VieNeu Studio nhập file; preview; xuất 1080p và 720p; lưu `Movies/Threads2Video`; chia sẻ; thử 1/5/8 bình luận, nội dung dài/emoji/teencode, mạng yếu; đo RAM, nhiệt, throttling sau 30 phút.

## Quyền riêng tư

Token mã hóa bằng Keystore, `allowBackup=false`, không ghi token/nội dung cá nhân vào Logcat, không tải avatar, xóa được project (kể cả thẻ) bằng một nút.

Chi tiết kiểm toán mã nguồn và đối chiếu API: `docs/AUDIT.md`.
