'use strict';
/*
 * Backend ĐỔI TOKEN tham chiếu cho Threads2Video (không phụ thuộc thư viện, Node ≥ 18).
 *
 * Vì sao cần: Meta yêu cầu App Secret khi đổi `code` lấy token. App Secret KHÔNG được nằm trong APK,
 * nên phần này chạy trên máy chủ của bạn (HTTPS). Broker KHÔNG lưu token lâu dài: chỉ giữ "vé" 2 phút trong RAM.
 *
 *  GET  /threads/callback?code&state   <- Meta chuyển trình duyệt về đây (redirect_uri = PUBLIC_BASE_URL/threads/callback)
 *       → đổi code → long-lived token → tạo vé một lần → trang mở lại app: threads2video://oauth?ticket=…&state=…
 *  POST /threads/redeem {ticket, verifier} <- app đổi vé lấy token. verifier chỉ app biết; state = nonce.base64url(sha256(verifier))
 *       → {access_token, expires_in, user_id}
 *
 * Biến môi trường: THREADS_APP_ID, THREADS_APP_SECRET, PUBLIC_BASE_URL (https://…), PORT, GRAPH_HOST (mặc định https://graph.threads.com)
 * Tài liệu Meta cần đối chiếu lại trước khi dùng thật: authorization, access tokens, long-lived tokens (xem README gốc).
 */
const http = require('http');
const crypto = require('crypto');

const TICKET_TTL_MS = 120000;
const STATE_RE = /^[A-Za-z0-9_-]{8,64}\.[A-Za-z0-9_-]{43}$/;     // nonce . sha256(verifier) dạng base64url không đệm
const b64url = buf => buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const sha256b64url = s => b64url(crypto.createHash('sha256').update(s, 'utf8').digest());
const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function createBroker(cfg) {
  const need = ['appId', 'appSecret', 'publicBaseUrl'];
  for (const k of need) if (!cfg[k]) throw new Error('Thiếu cấu hình: ' + k);
  if (!/^https:\/\//.test(cfg.publicBaseUrl) && !cfg.allowInsecureForTests) throw new Error('PUBLIC_BASE_URL phải là https://');
  const graph = (cfg.graphHost || 'https://graph.threads.com').replace(/\/$/, '');
  const now = cfg.now || Date.now;
  const tickets = new Map();
  const hits = new Map();

  const redirectUri = () => cfg.publicBaseUrl.replace(/\/$/, '') + '/threads/callback';
  const sweep = () => { const t = now(); for (const [k, v] of tickets) if (v.exp <= t) tickets.delete(k); };

  function limited(ip) {            // giới hạn thô: 30 yêu cầu / phút / IP
    const t = now(), w = hits.get(ip) || [];
    const recent = w.filter(x => t - x < 60000); recent.push(t); hits.set(ip, recent);
    return recent.length > 30;
  }

  async function exchange(code) {
    const body = new URLSearchParams({ client_id: cfg.appId, client_secret: cfg.appSecret, code, grant_type: 'authorization_code', redirect_uri: redirectUri() });
    const r1 = await fetch(graph + '/oauth/access_token', { method: 'POST', body });
    const j1 = await r1.json().catch(() => ({}));
    if (!r1.ok || !j1.access_token) throw new Error('exchange_failed');
    const u = new URL(graph + '/access_token');
    u.search = new URLSearchParams({ grant_type: 'th_exchange_token', client_secret: cfg.appSecret, access_token: j1.access_token }).toString();
    const r2 = await fetch(u);
    const j2 = await r2.json().catch(() => ({}));
    if (!r2.ok || !j2.access_token) throw new Error('long_lived_failed');
    return { token: j2.access_token, expiresIn: Number(j2.expires_in) || 0, userId: String(j1.user_id || '') };
  }

  const send = (res, status, body, type) => {
    res.writeHead(status, { 'Content-Type': type || 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(typeof body === 'string' ? body : JSON.stringify(body));
  };
  const page = (title, msg, link) => '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + esc(title) + '</title>' +
    '<body style="font-family:sans-serif;padding:24px"><h2>' + esc(title) + '</h2><p>' + esc(msg) + '</p>' +
    (link ? '<p><a href="' + esc(link) + '" style="font-size:20px">Mở Threads2Video</a></p><script>location.href=' + JSON.stringify(link) + '</script>' : '') + '</body>';

  async function handle(req, res) {
    const url = new URL(req.url, 'http://x');
    const ip = (req.socket && req.socket.remoteAddress) || '?';
    if (limited(ip)) return send(res, 429, { error: 'rate_limited' });
    sweep();

    if (req.method === 'GET' && url.pathname === '/threads/callback') {
      const state = url.searchParams.get('state') || '';
      if (!STATE_RE.test(state)) return send(res, 400, page('Yêu cầu không hợp lệ', 'Thiếu hoặc sai tham số state.'), 'text/html; charset=utf-8');
      const back = q => 'threads2video://oauth?' + new URLSearchParams(Object.assign({ state }, q)).toString();
      const err = url.searchParams.get('error');
      if (err) return send(res, 200, page('Đăng nhập không hoàn tất', 'Bạn đã hủy hoặc Meta từ chối.', back({ error: err === 'access_denied' ? 'access_denied' : 'denied' })), 'text/html; charset=utf-8');
      const code = (url.searchParams.get('code') || '').replace(/#_$/, '');
      if (!code) return send(res, 400, page('Yêu cầu không hợp lệ', 'Thiếu code.'), 'text/html; charset=utf-8');
      try {
        const t = await exchange(code);
        const ticket = b64url(crypto.randomBytes(32));
        tickets.set(ticket, { token: t.token, expiresIn: t.expiresIn, userId: t.userId, challenge: state.split('.')[1], exp: now() + TICKET_TTL_MS });
        return send(res, 200, page('Đăng nhập thành công', 'Quay lại ứng dụng để tiếp tục.', back({ ticket })), 'text/html; charset=utf-8');
      } catch (e) {
        return send(res, 200, page('Đăng nhập thất bại', 'Không đổi được mã lấy token. Hãy thử lại.', back({ error: 'exchange_failed' })), 'text/html; charset=utf-8');
      }
    }

    if (req.method === 'POST' && url.pathname === '/threads/redeem') {
      let raw = ''; let tooBig = false;
      for await (const ch of req) { raw += ch; if (raw.length > 4096) { tooBig = true; break; } }
      if (tooBig) return send(res, 413, { error: 'too_large' });
      let b; try { b = JSON.parse(raw); } catch (e) { return send(res, 400, { error: 'bad_json' }); }
      const t = tickets.get(String(b && b.ticket));
      tickets.delete(String(b && b.ticket));                    // dùng một lần dù đúng hay sai
      if (!t || t.exp <= now()) return send(res, 401, { error: 'invalid_ticket' });
      if (typeof b.verifier !== 'string' || !safeEq(sha256b64url(b.verifier), t.challenge)) return send(res, 401, { error: 'invalid_ticket' });
      return send(res, 200, { access_token: t.token, expires_in: t.expiresIn, user_id: t.userId });
    }

    if (req.method === 'GET' && url.pathname === '/healthz') return send(res, 200, { ok: true });
    return send(res, 404, { error: 'not_found' });
  }

  const server = http.createServer((req, res) => { handle(req, res).catch(() => send(res, 500, { error: 'internal' })); });
  return { server, _tickets: tickets, redirectUri };
}

module.exports = { createBroker, sha256b64url };

if (require.main === module) {
  const b = createBroker({ appId: process.env.THREADS_APP_ID, appSecret: process.env.THREADS_APP_SECRET, publicBaseUrl: process.env.PUBLIC_BASE_URL, graphHost: process.env.GRAPH_HOST });
  b.server.listen(Number(process.env.PORT) || 8080, () => console.log('token-broker đang chạy'));
}
