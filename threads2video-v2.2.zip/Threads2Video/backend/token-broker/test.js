'use strict';
const http = require('http');
const crypto = require('crypto');
const { createBroker, sha256b64url } = require('./server.js');

let pass = 0, fail = 0;
const check = (n, c, d) => { if (c) { pass++; console.log('  ok   ' + n); } else { fail++; console.log('  FAIL ' + n + (d !== undefined ? ' → ' + JSON.stringify(d) : '')); } };
const b64u = b => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const listen = s => new Promise(r => s.listen(0, '127.0.0.1', () => r(s.address().port)));

(async () => {
  // Meta GIẢ: kiểm tra đúng tham số mà broker gửi (đặc biệt client_secret chỉ xuất hiện ở đây)
  const seen = [];
  const meta = http.createServer(async (req, res) => {
    let raw = ''; for await (const c of req) raw += c;
    const u = new URL(req.url, 'http://x');
    seen.push({ m: req.method, p: u.pathname, body: raw, q: u.search });
    res.setHeader('Content-Type', 'application/json');
    if (req.method === 'POST' && u.pathname === '/oauth/access_token') {
      const f = new URLSearchParams(raw);
      if (f.get('client_secret') !== 'SECRET' || f.get('code') !== 'GOODCODE' || f.get('grant_type') !== 'authorization_code') { res.statusCode = 400; return res.end('{"error":{"message":"bad"}}'); }
      return res.end(JSON.stringify({ access_token: 'SHORT', user_id: 777 }));
    }
    if (req.method === 'GET' && u.pathname === '/access_token') {
      if (u.searchParams.get('grant_type') !== 'th_exchange_token' || u.searchParams.get('access_token') !== 'SHORT' || u.searchParams.get('client_secret') !== 'SECRET') { res.statusCode = 400; return res.end('{}'); }
      return res.end(JSON.stringify({ access_token: 'LONGLIVED', token_type: 'bearer', expires_in: 5184000 }));
    }
    res.statusCode = 404; res.end('{}');
  });
  const metaPort = await listen(meta);
  let t = 1000000;
  const broker = createBroker({ appId: '1234', appSecret: 'SECRET', publicBaseUrl: 'http://127.0.0.1', allowInsecureForTests: true, graphHost: 'http://127.0.0.1:' + metaPort, now: () => t });
  const bp = await listen(broker.server);
  const base = 'http://127.0.0.1:' + bp;
  const get = async p => { const r = await fetch(base + p); return { status: r.status, text: await r.text() }; };
  const post = async (p, o) => { const r = await fetch(base + p, { method: 'POST', body: JSON.stringify(o) }); return { status: r.status, json: await r.json().catch(() => null) }; };
  const newState = () => { const verifier = b64u(crypto.randomBytes(32)); return { verifier, state: 'nonce' + b64u(crypto.randomBytes(8)) + '.' + sha256b64url(verifier) }; };
  const ticketOf = html => new URL(JSON.parse(html.match(/location\.href=("[^"]+")/)[1])).searchParams.get('ticket');

  console.log('== luồng thành công');
  const a = newState();
  let r = await get('/threads/callback?code=GOODCODE%23_&state=' + encodeURIComponent(a.state));
  check('callback trả trang mở lại app (threads2video://oauth)', r.status === 200 && /threads2video:\/\/oauth\?/.test(r.text));
  check('trang KHÔNG chứa token hay secret', !/LONGLIVED|SHORT|SECRET/.test(r.text));
  check('redirect_uri gửi cho Meta khớp /threads/callback', /redirect_uri=http%3A%2F%2F127\.0\.0\.1%2Fthreads%2Fcallback/.test(seen[0].body), seen[0].body);
  check('client_secret chỉ gửi tới Meta, không bao giờ tới app', seen[0].body.includes('client_secret=SECRET'));
  const ticket = ticketOf(r.text);
  check('state được trả lại nguyên vẹn cho app', new URL(JSON.parse(r.text.match(/location\.href=("[^"]+")/)[1])).searchParams.get('state') === a.state);
  r = await post('/threads/redeem', { ticket, verifier: a.verifier });
  check('redeem đúng verifier → token dài hạn', r.status === 200 && r.json.access_token === 'LONGLIVED' && r.json.expires_in === 5184000 && r.json.user_id === '777', r);
  r = await post('/threads/redeem', { ticket, verifier: a.verifier });
  check('vé chỉ dùng được một lần', r.status === 401);

  console.log('== tấn công / lỗi');
  const b = newState();
  const t2 = ticketOf((await get('/threads/callback?code=GOODCODE&state=' + encodeURIComponent(b.state))).text);
  r = await post('/threads/redeem', { ticket: t2, verifier: newState().verifier });
  check('app khác chặn deep link nhưng sai verifier → bị từ chối', r.status === 401);
  r = await post('/threads/redeem', { ticket: t2, verifier: b.verifier });
  check('vé đã bị hủy sau lần thử sai (dùng-một-lần kể cả khi sai)', r.status === 401);
  const c = newState();
  const t3 = ticketOf((await get('/threads/callback?code=GOODCODE&state=' + encodeURIComponent(c.state))).text);
  t += 121000;
  r = await post('/threads/redeem', { ticket: t3, verifier: c.verifier });
  check('vé hết hạn sau 2 phút', r.status === 401);
  r = await get('/threads/callback?code=BADCODE&state=' + encodeURIComponent(newState().state));
  check('code sai → báo exchange_failed, không có vé', /error=exchange_failed/.test(r.text) && !/ticket=/.test(r.text));
  r = await get('/threads/callback?error=access_denied&state=' + encodeURIComponent(newState().state));
  check('người dùng từ chối → error=access_denied về app', /error=access_denied/.test(r.text));
  r = await get('/threads/callback?code=GOODCODE&state=xyz');
  check('state sai định dạng bị từ chối (400)', r.status === 400);
  r = await post('/threads/redeem', { ticket: 'khong-co', verifier: 'x' });
  check('vé lạ → 401 chung chung', r.status === 401 && r.json.error === 'invalid_ticket');
  r = await fetch(base + '/threads/redeem', { method: 'POST', body: 'x'.repeat(10000) });
  check('body quá lớn bị chặn (413)', r.status === 413);
  check('broker không giữ token sau khi redeem', broker._tickets.size <= 0 || [...broker._tickets.values()].every(v => v.exp > 0));
  let threw = false; try { createBroker({ appId: 'a', appSecret: 's', publicBaseUrl: 'http://khong-https' }); } catch (e) { threw = true; }
  check('từ chối PUBLIC_BASE_URL không phải https', threw);
  threw = false; try { createBroker({ appId: 'a', publicBaseUrl: 'https://x' }); } catch (e) { threw = true; }
  check('từ chối khi thiếu App Secret', threw);
  for (let i = 0; i < 40; i++) await get('/healthz');
  r = await get('/healthz');
  check('giới hạn tần suất theo IP (429)', r.status === 429);

  meta.close(); broker.server.close();
  console.log('\n' + pass + ' đạt, ' + fail + ' thất bại');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
