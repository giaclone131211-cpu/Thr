/* Cầu nối Android GIẢ — CHỈ để kiểm thử giao diện trong Chromium (tests/). Không nằm trong APK.
 * Mô phỏng hợp đồng của bridge/NativeDispatcher.kt (lệnh, kiểu trả về, mã lỗi). Logic thật của Kotlin được kiểm bằng test JVM. */
module.exports = function installMock() {
  const M = window.__MOCK = window.__MOCK || {};
  M.calls = []; M.saved = {}; M.cards = {}; M.chunks = []; M.shares = []; M.openedThreads = 0; M.studio = [];
  const emoji = /[\p{Extended_Pictographic}‍️]/gu;
  const DICT = { ko: 'không', k: 'không', dc: 'được', 'đc': 'được', vs: 'với', ng: 'người' };
  function normalize(raw) {
    const flags = [];
    let s = String(raw).replace(emoji, '').replace(/https?:\/\/\S+/g, ' ');
    s = s.replace(/[\p{L}\p{N}]+/gu, w => { const l = w.toLowerCase(); if (DICT[l]) return (w[0] !== w[0].toLowerCase() ? DICT[l][0].toUpperCase() + DICT[l].slice(1) : DICT[l]); if (l === 'xyz') { flags.push('Từ viết tắt lạ, chưa chắc cách đọc: "' + w + '"'); } return w; });
    s = s.replace(/\s+/g, ' ').trim();
    if (s && !/[.!?…]$/.test(s)) s += '.';
    return { ttsText: s, needsManualReview: flags.length > 0 || !s, flags };
  }
  const handlers = {
    'auth.status': () => M.auth || { configured: true, appId: '1234567', brokerUrl: 'https://broker.example', loggedIn: true, username: 'tester', source: 'oauth', expiresAt: Date.now() + 5e9 },
    'config.set': a => Object.assign({ configured: true, loggedIn: false }, a),
    'auth.begin': () => ({ started: true }),
    'auth.logout': () => ({ configured: true, loggedIn: false }),
    'auth.manualToken': () => ({ configured: false, loggedIn: true, source: 'manual' }),
    'research.run': a => { if (M.researchError) throw M.researchError; return M.research; },
    'research.source': a => { if (M.sourceError) throw M.sourceError; return M.sources[a.post.id]; },
    'research.rank': a => ({ comments: a.comments.map((c, i) => Object.assign({}, c, { rankScore: 1 - i * 0.01, rankReasons: ['thứ tự nhập'] })), topIds: a.comments.slice(0, a.topN).map(c => c.id), dropped: [], engine: 'rules' }),
    'research.cancel': () => ({ ok: true }),
    'tts.normalize': a => a.items.map(i => Object.assign({ id: i.id, engine: 'rules' }, normalize(i.rawText))),
    'card.save': a => { const uri = 'data:image/png;base64,' + a.pngBase64; M.cards[a.commentId] = (M.cards[a.commentId] || 0) + 1; M.lastPng = M.lastPng || {}; M.lastPng[a.commentId] = a.pngBase64; return { uri, bytes: a.pngBase64.length }; },
    'card.delete': a => { M.deleted = (M.deleted || []).concat(a.commentId); return { ok: true }; },
    'project.save': a => { M.saved[a.id] = a.json; return { ok: true }; },
    'project.load': a => ({ json: M.preload != null ? M.preload : (M.saved[a.id] || null) }),
    'project.deleteAll': () => { M.saved = {}; return { ok: true }; },
    'export.prepare': () => ({ ok: true }),
    'caption.make': () => ({ text: 'caption cục bộ' }),
    'ai.status': () => ({ kind: 'rules', modelName: null, ready: true, note: 'luật', loadedFile: null, nativeAvailable: false }),
    'model.catalog': () => ({ profiles: [{ id: 'p1', label: 'Nhẹ', fileName: 'a.gguf', approxBytes: 1.8e9, license: 'Apache-2.0', note: '', downloadable: true, installed: false, verified: false, partialBytes: 0, loaded: false }], installed: [], usedBytes: 0, freeBytes: 5e9 })
  };
  window.Android = {
    call(id, name, argsJson) {
      const args = JSON.parse(argsJson || '{}');
      M.calls.push({ name, args });
      setTimeout(() => {
        try {
          const h = handlers[name];
          if (!h) throw { code: 'bad_request', message: 'Lệnh không hợp lệ: ' + name };
          const res = h(args);
          window.__native(id, true, JSON.stringify(res));
        } catch (e) { window.__native(id, false, JSON.stringify(e && e.code ? e : { code: 'internal', message: String(e && e.message || e) })); }
      }, M.delay || 0);
    },
    beginSave(name, mime) { M.saveName = name; M.saveMime = mime; M.chunks = []; return true; },
    writeChunk(b64) { M.chunks.push(b64.length); return true; },
    endSave() { return 'content://mock/video/1'; },
    share(uri, mime) { M.shares.push([uri, mime]); },
    openStudio(json) { M.studio.push(JSON.parse(json)); },
    toast() {}, exit() {}
  };
  // nếu code cũ còn gọi, ghi nhận để test bắt được
  Object.defineProperty(window.Android, 'openThreads', { get() { M.openedThreads++; return () => {}; }, configurable: true, enumerable: false });
};
