const post = (id, text, extra) => Object.assign({ id, sourceUrl: 'https://www.threads.com/@chu_bai/post/' + id, authorUsername: 'chu_bai', rawText: text, createdAt: '2026-11-10T08:00:00+0000', likeCount: null, hasReplies: true, isReply: false, relevanceScore: 0.8, rankReasons: ['liên quan chủ đề'], origin: 'api' }, extra || {});
const cm = (id, text, extra) => Object.assign({ id, sourcePostId: 'P1', sourceUrl: 'https://www.threads.com/@u/post/' + id, authorUsername: 'user_' + id, rawText: text, ttsText: null, likeCount: null, createdAt: null, rankScore: 0.5, rankReasons: ['nội dung đủ ngữ cảnh'], cardImageUri: null, ocrRequired: false, needsManualReview: false, approvedForVideo: false, origin: 'api' }, extra || {});

const texts = [
  'Ko ai dc nói vs ng làm bếp là dễ đâu 😂😂 mệt lắm luôn.',
  'Nấu cho cả nhà thì không ai trả lương, nấu ở nhà hàng thì có lương và có danh xưng bếp trưởng. Khác nhau chỗ đó thôi.',
  'xyz mà nghĩ lại thấy đúng quá ❤️',
  'Đầu bếp nam thường được trả cao hơn, đó là sự thật đáng buồn của ngành này.',
  'Ba tui nấu ngon nhất nhà nhưng cả đời chỉ nấu mỗi dịp Tết, còn mẹ tui nấu mỗi ngày mà chưa ai khen lần nào.',
  'Bạn bình luận hay quá, đọc xong tui im luôn vì không cãi được câu nào.',
  'Lời khuyên cho genZ: đi làm vài năm rồi mới nên mở quán.',
  'Mình thấy cả hai đều đáng được tôn trọng như nhau, không nên so sánh.',
  'Nhà mình ba nấu mẹ rửa, chia nhau cho công bằng 😅',
  'Hồi nhỏ mẹ nấu cơm mỗi ngày, lớn lên mới thấy mẹ vất vả cỡ nào.'
];
const comments = texts.map((t, i) => cm('C' + (i + 1), t));
const P1 = post('P1', 'Tại sao người giỏi nấu ăn đa số là phụ nữ nhưng đầu bếp thường là nam? Nghĩ kỹ lại thấy đúng quá 🤔');
const P2 = post('P2', 'Chuyện công sở: sếp giao việc lúc 6 giờ chiều thứ sáu, mọi người nghĩ sao?', { id: 'P2', sourceUrl: 'https://www.threads.com/@b/post/P2' });

function research(n) {
  const cs = comments.slice(0, n);
  return {
    topic: 'tâm sự', candidates: [P1, P2], me: { id: '1', username: 'tester' }, queriesUsed: 2, engine: { kind: 'rules' },
    notices: [{ code: 'no_like_data', message: 'API không trả số tim của bình luận.' }],
    source: { post: P1, comments: cs, topIds: cs.slice(0, 8).map(c => c.id), dropped: [{ id: 'X', reason: 'trùng lặp' }], notices: [], engine: 'rules' }
  };
}
module.exports = { post, cm, comments, P1, P2, research };
