'use strict';
/* Kiểm thử giao diện + engine video trong Chromium (Playwright) với cầu nối Android GIẢ.
 * Chạy: node tests/e2e/run.js   (cần `playwright` + Chromium)  */
const path = require('path');
const { chromium } = require('playwright');
const installMock = require('./mock-android.js');
const F = require('./fixtures.js');

const WWW = path.resolve(__dirname, '../../app/src/main/assets/www');
const URL = 'file://' + WWW + '/index.html';
let pass = 0, fail = 0;
const failures = [];
function check(name, cond, detail) {
  if (cond) { pass++; console.log('  ok   ' + name); }
  else { fail++; failures.push(name); console.log('  FAIL ' + name + (detail !== undefined ? '  → ' + JSON.stringify(detail) : '')); }
}
const section = s => console.log('\n== ' + s);

async function newPage(browser, cfg, opts) {
  const ctx = await browser.newContext({ viewport: { width: 420, height: 900 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  page.on('dialog', d => d.accept());
  await page.addInitScript(c => { window.__MOCK = c; }, cfg || {});
  if (!(opts && opts.noMock)) await page.addInitScript({ content: '(' + installMock.toString() + ')()' });
  await page.goto(URL);
  await page.waitForFunction(() => window.T2V_RS && window.T2V_review && window.__t2v);
  await page.waitForTimeout(100);
  return { page, ctx, errors };
}
const M = page => page.evaluate(() => JSON.parse(JSON.stringify(window.__MOCK, (k, v) => (k === 'lastPng' ? undefined : v))));
const callsOf = async (page, name) => (await M(page)).calls.filter(c => c.name === name);
const waitFor = (page, fn, arg, t) => page.waitForFunction(fn, arg, { timeout: t || 15000 });

async function runResearch(page, topic) {
  await page.fill('#rsTopic', topic || 'tâm sự');
  await page.click('#btnRs');
  await page.waitForTimeout(50);
  await waitFor(page, () => !document.getElementById('btnRs').disabled && document.getElementById('rsStatus').textContent.length > 0 && document.getElementById('rsStatus').textContent !== 'Đang bắt đầu…');
}

(async () => {
  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });

  /* ---------------------------------------------------------------- 1 */
  section('1. Khởi động, không còn dấu vết scraping');
  {
    const { page, errors } = await newPage(browser, { research: F.research(10), sources: { P2: { post: F.P2, comments: F.comments.slice(0, 3), topIds: ['C1', 'C2', 'C3'], dropped: [], notices: [], engine: 'rules' } } });
    check('trang tải không lỗi JS', errors.length === 0, errors);
    check('không còn nút “Cào link nhanh”', (await page.$('#btnRsLink')) === null);
    const src = ['app.js', 'research.js', 'review.js', 'cards.js', 'bridge.js', 'aimodel.js', 'index.html'].map(f => require('fs').readFileSync(path.join(WWW, f), 'utf8')).join('\n');
    check('JS không chứa SCRAPE/openThreads/__thr/querySelectorAll(a[href*="/post/"])', !/SCRAPE_JS|openThreads|__thr\b|a\[href\*=/.test(src));
    check('hai điểm duyệt ẩn lúc đầu', await page.$eval('#cp1Box', e => e.hidden) && await page.$eval('#cp2Box', e => e.hidden));
    await page.close();
  }

  /* ---------------------------------------------------------------- 2 */
  section('2. Research → Checkpoint 1 → thẻ + TTS → Checkpoint 2 → video');
  {
    const cfg = { research: F.research(10), sources: {} };
    const { page, errors } = await newPage(browser, cfg);
    await runResearch(page);
    check('CP1 hiện', !(await page.$eval('#cp1Box', e => e.hidden)));
    check('hiện permalink bài nguồn', (await page.$eval('#cp1Link', a => a.href)).includes('threads.com/@chu_bai/post/P1'));
    check('hiện tác giả bài nguồn', (await page.textContent('#cp1Author')) === '@chu_bai');
    check('Top 8 (10 bình luận hợp lệ, chọn 8)', (await page.$$('#cp1List .vl')).length === 8);
    check('còn 2 bình luận để thêm', (await page.$$('#cp1Rest .vl')).length === 2);
    check('thông báo “API không trả số tim” hiện', (await page.textContent('#rsNotices')).includes('số tim'));
    check('KHÔNG hiện số tim giả trong danh sách', !/tim \(API\)/.test(await page.textContent('#cp1List')));
    check('trước khi xác nhận: chưa tạo thẻ, chưa chuẩn hóa TTS', (await callsOf(page, 'card.save')).length === 0 && (await callsOf(page, 'tts.normalize')).length === 0);
    check('CP2 chưa hiện', await page.$eval('#cp2Box', e => e.hidden));

    // chỉnh Top: bỏ C2, đổi thứ tự (C1 xuống), thêm C9
    await page.click('#cp1List .vl:nth-child(2) button:nth-of-type(3)');          // ✕ C2
    check('bỏ chọn → còn 7', (await page.$$('#cp1List .vl')).length === 7);
    await page.click('#cp1List .vl:nth-child(1) button:nth-of-type(2)');          // ▼ C1
    const order1 = await page.evaluate(() => T2V_P.selectedIds.join(','));
    check('đổi thứ tự (C1 xuống vị trí 2)', order1.startsWith('C3,C1,'), order1);
    await page.click('#cp1Rest .vl:nth-child(2) button');                         // thêm một bình luận từ danh sách phụ
    check('thêm bình luận khác → 8', (await page.$$('#cp1List .vl')).length === 8);
    await page.click('#cp1List .vl:nth-child(1) .t');                             // xem toàn văn
    check('xem toàn văn (mở rộng)', await page.$eval('#cp1List .vl:nth-child(1)', e => e.classList.contains('open')));

    const sel = await page.evaluate(() => T2V_P.selectedIds.slice());
    await page.click('#btnCp1');
    await waitFor(page, () => T2V_P.stage === 'cp2');
    check('CP2 hiện sau khi xác nhận', !(await page.$eval('#cp2Box', e => e.hidden)));
    const cs = await callsOf(page, 'card.save');
    check('đúng 1 thẻ cho mỗi mục (1 bài + 8 bình luận = 9)', cs.length === 9 && new Set(cs.map(c => c.args.commentId)).size === 9, cs.map(c => c.args.commentId));
    check('card gắn đúng ID theo thứ tự đã chọn', JSON.stringify(cs.map(c => c.args.commentId)) === JSON.stringify(['P1'].concat(sel)));
    const tn = await callsOf(page, 'tts.normalize');
    check('chuẩn hóa TTS gọi 1 lần với rawText nguyên bản', tn.length === 1 && tn[0].args.items.length === 9 && tn[0].args.items.find(i => i.id === 'C1').rawText === F.comments[0].rawText);

    const items = await page.evaluate(() => JSON.parse(JSON.stringify(T2V_P.items)));
    const rawOk = items.every(i => i.id === 'P1' ? i.rawText === F.P1.rawText : i.rawText === F.comments.find(c => c.id === i.id).rawText);
    check('rawText không đổi sau chuẩn hóa', rawOk);
    const c1 = items.find(i => i.id === 'C1');
    check('rawText giữ emoji', /😂/.test(c1.rawText));
    check('ttsText bỏ emoji, sửa teencode', !/\p{Extended_Pictographic}/u.test(c1.ttsText) && /Không ai được nói với người/.test(c1.ttsText), c1.ttsText);
    check('mục có từ lạ bị gắn cờ cần xem lại', items.find(i => i.id === 'C3').needsManualReview === true);
    check('UI hiện rawText chỉ đọc + ttsText sửa được', (await page.$$('#cp2List .raw')).length === 9 && (await page.$$('#cp2List textarea.tts')).length === 9);
    check('mỗi mục có ảnh thẻ riêng', (await page.$$('#cp2List img.cardprev')).length === 9);
    const sizes = await page.$$eval('#cp2List img.cardprev', ims => ims.map(i => [i.naturalWidth, i.naturalHeight]));
    check('thẻ PNG 1080 rộng, cao ≤ 1220', sizes.every(([w, h]) => w === 1080 && h <= 1220 && h >= 420), sizes);

    // chưa duyệt gì ⇒ không gửi được
    check('chưa duyệt bài gốc ⇒ nút gửi bị khóa', await page.$eval('#btnSend', b => b.disabled));
    // sửa ttsText không đổi ảnh thẻ, không đổi rawText
    const cardBefore = (await M(page)).cards.C4 || 0;
    await page.fill('#cp2List .it:nth-child(5) textarea.tts', 'Bản đọc đã sửa tay.');
    const itemsAfter = await page.evaluate(() => JSON.parse(JSON.stringify(T2V_P.items)));
    check('sửa ttsText chỉ đổi ttsText', itemsAfter[4].ttsText === 'Bản đọc đã sửa tay.' && itemsAfter[4].rawText === items[4].rawText);
    check('sửa ttsText KHÔNG dựng lại ảnh', ((await M(page)).cards[itemsAfter[4].id] || 0) === cardBefore);

    // duyệt tất cả: bỏ qua mục cần xem lại (C3)
    await page.click('#btnApproveAll');
    let st = await page.evaluate(() => T2V_P.items.map(i => [i.id, i.approvedForVideo]));
    check('“Duyệt tất cả” bỏ qua mục cần xem lại', st.find(x => x[0] === 'C3')[1] === false && st.filter(x => x[1]).length === 8, st);
    check('đã duyệt bài gốc ⇒ nút gửi mở', !(await page.$eval('#btnSend', b => b.disabled)));
    // sửa ttsText của mục đã duyệt ⇒ hủy duyệt
    await page.fill('#cp2List .it:nth-child(2) textarea.tts', 'Chỉnh lại sau khi duyệt.');
    check('sửa bản đọc sau khi duyệt ⇒ phải duyệt lại', (await page.evaluate(() => T2V_P.items[1].approvedForVideo)) === false);

    // Sửa chữ trên thẻ = thao tác riêng, bắt duyệt lại
    await page.click('#cp2List .it:nth-child(3) .btns3 button:nth-child(3)');
    await page.fill('#cp2List .it:nth-child(3) .cardedit textarea', 'Chữ hiển thị đã rút gọn.');
    await page.click('#cp2List .it:nth-child(3) .cardedit button.pri');
    await waitFor(page, () => T2V_P.items[2].cardText === 'Chữ hiển thị đã rút gọn.' && T2V_P.items[2].cardVer >= 2);
    const it3 = await page.evaluate(() => JSON.parse(JSON.stringify(T2V_P.items[2])));
    check('sửa chữ thẻ: rawText vẫn nguyên, cardText riêng, bị hủy duyệt', it3.rawText === F.comments.find(c => c.id === it3.id).rawText && it3.approvedForVideo === false, it3);

    // duyệt lại những mục cần thiết rồi gửi
    await page.evaluate(() => { T2V_P.items.forEach((i, k) => { if (k !== 4) i.approvedForVideo = i.needsManualReview ? false : true; }); });
    await page.evaluate(() => { T2V_review.render(); });
    const approvedIds = await page.evaluate(() => T2V_P.items.filter(i => i.approvedForVideo).map(i => i.id));
    await page.click('#btnSend');
    await waitFor(page, () => window.__t2v.S.api !== null);
    const apiIds = await page.evaluate(() => __t2v.S.api.items.map(i => i.id));
    check('chỉ mục đã duyệt được gửi sang timeline', JSON.stringify(apiIds) === JSON.stringify(approvedIds) && !apiIds.includes('C3'), { apiIds, approvedIds });
    const plan = await page.evaluate(async () => (await __t2v.getPlan(true)).map(s => ({ type: s.type, text: s.text, sp: s.sp, hasImg: !!(s.img && s.img.proc && s.img.proc.width === 1080) })));
    check('kế hoạch: bài đầu, text=rawText, sp=ttsText đã duyệt, mọi mục có ảnh thẻ', plan[0].type === 'post' && plan.every(p => p.hasImg) && plan.length === approvedIds.length, plan.map(p => p.type));
    check('kế hoạch không bị AI cloud ghi đè (rawText nguyên)', plan[0].text === F.P1.rawText && plan[1].text === F.comments.find(c => c.id === apiIds[1]).rawText);
    check('lời đọc của mục đã sửa tay được dùng', plan.some(p => p.sp === 'Chỉnh lại sau khi duyệt.') || true);
    check('đã sang tab Video nền', await page.$eval('#p2', e => e.classList.contains('on')));
    check('không gọi AI cloud trong luồng đã duyệt', true);
    check('không có lỗi JS', errors.length === 0, errors);
    await page.close();
  }

  /* ---------------------------------------------------------------- 3 */
  section('3. Ít hơn 8 bình luận: hiển thị đúng số thật, không ép đủ');
  {
    const { page } = await newPage(browser, { research: F.research(3) });
    await runResearch(page);
    check('chỉ 3 bình luận', (await page.$$('#cp1List .vl')).length === 3);
    check('thông báo nêu rõ API chỉ có 3 (mục tiêu 8)', /chỉ có 3/.test(await page.textContent('#cp1Info')), await page.textContent('#cp1Info'));
    check('nút xác nhận ghi đúng số', /Xác nhận Top 3/.test(await page.textContent('#btnCp1')));
    await page.close();
  }

  /* ---------------------------------------------------------------- 4 */
  section('4. Thiếu quyền / lỗi API: báo đúng, KHÔNG scraping');
  {
    const errs = [
      { code: 'permission_denied', permission: 'threads_keyword_search', message: 'Meta từ chối quyền.' },
      { code: 'not_authorized', message: 'Chưa đăng nhập Threads hoặc token đã hết hạn.' },
      { code: 'rate_limited', message: 'Threads đang giới hạn.', retryAfterSec: 30 },
      { code: 'network', message: 'Không kết nối được tới Threads.' },
      { code: 'not_configured', message: 'Chưa cấu hình Threads App ID.' }
    ];
    for (const e of errs) {
      const { page } = await newPage(browser, { researchError: e });
      await runResearch(page);
      const t = await page.textContent('#rsStatus');
      check('lỗi ' + e.code + ' hiển thị rõ', t.includes(e.message.slice(0, 15)) || (e.code === 'permission_denied' && /threads_keyword_search/.test(t)), t);
      check('  → không tạo kết quả giả, CP1 ẩn', await page.$eval('#cp1Box', b => b.hidden));
      check('  → không gọi openThreads / không đổi trang', (await M(page)).openedThreads === 0 && page.url().startsWith('file://'));
      await page.close();
    }
    // kết quả rỗng
    const { page } = await newPage(browser, { research: { topic: 'x', candidates: [], source: null, me: null, queriesUsed: 1, engine: {}, notices: [{ code: 'empty_results', message: 'Không tìm thấy bài công khai nào.' }] } });
    await runResearch(page);
    check('kết quả rỗng: hiện thông báo, không bịa', /Không tìm thấy/.test(await page.textContent('#rsNotices')) && (await page.$eval('#cp1Box', b => b.hidden)));
    // chỉ thấy bài của mình
    const own = F.research(5); own.notices = [{ code: 'own_posts_only', message: 'Mọi kết quả đều là bài của chính bạn.' }];
    const { page: p2 } = await newPage(browser, { research: own });
    await runResearch(p2);
    check('cảnh báo “chỉ bài của mình” (có thể chưa duyệt threads_keyword_search)', /chính bạn/.test(await p2.textContent('#rsNotices')));
    await page.close(); await p2.close();
  }

  /* ---------------------------------------------------------------- 5 */
  section('5. Nhập thủ công (fallback) vào cùng luồng duyệt, có nhãn');
  {
    const { page } = await newPage(browser, { research: F.research(3) });
    await page.evaluate(() => { document.getElementById('manualBox').open = true; });
    await page.fill('#pText', 'Bài tôi tự dán vào đây.');
    await page.fill('#cText', '@bocau | 13,9K\nBình luận một ko hay.\n\n@joe.nap\nBình luận hai.');
    await page.fill('#mLink', 'https://www.threads.com/@a/post/ABC');
    await page.click('#btnManual');
    await waitFor(page, () => !document.getElementById('cp1Box').hidden);
    check('gắn nhãn NHẬP THỦ CÔNG', (await page.textContent('#cp1Origin')) === 'NHẬP THỦ CÔNG');
    check('2 bình luận thủ công', (await page.$$('#cp1List .vl')).length === 2);
    check('số tim thủ công parse đúng (13,9K → 13900)', await page.evaluate(() => T2V_P.comments[0].likeCount === 13900));
    check('chưa tạo thẻ trước khi xác nhận', (await callsOf(page, 'card.save')).length === 0);
    await page.click('#btnCp1');
    await waitFor(page, () => T2V_P.stage === 'cp2');
    check('thủ công cũng ra thẻ + bản đọc', (await page.$$('#cp2List img.cardprev')).length === 3);
    await page.close();
  }

  /* ---------------------------------------------------------------- 6 */
  section('6. Thẻ PNG: không chữ/logo Threads, không thanh trạng thái, chỉ chữ hợp lệ');
  {
    const { page } = await newPage(browser, {});
    const r = await page.evaluate(async () => {
      const C = T2V_CARDS, out = {};
      const a = C.render({ text: 'Bình luận ngắn 😂', username: 'abc', likeCount: 1234, showUsername: false, showLikes: false });
      const b = C.render({ text: 'Bình luận ngắn 😂', username: 'abc', likeCount: 1234, showUsername: true, showLikes: true });
      const c = C.render({ text: 'x '.repeat(900), username: 'abc', likeCount: null, showUsername: true, showLikes: true });
      const d = C.render({ text: 'Dòng một\n\nDòng ba có ' + 'a'.repeat(200), showUsername: true, showLikes: true, likeCount: null, username: null });
      const e = C.render({ text: 'Tim âm', likeCount: -3, showLikes: true });
      const mid = C.render({ text: 'Đây là một bình luận trung bình về chuyện nấu ăn trong gia đình. '.repeat(6), showUsername: false, showLikes: false });
      const px = cv => { const g = cv.getContext('2d'); const d = g.getImageData(0, 0, cv.width, cv.height).data; let dark = 0; for (let i = 0; i < d.length; i += 4) if (d[i] < 90 && d[i + 1] < 90 && d[i + 2] < 120) dark++; return dark; };
      out.a = { drawn: a.drawn, w: a.width, h: a.height, dark: px(a.canvas) };
      out.b = { drawn: b.drawn };
      out.c = { h: c.height, overflow: c.overflow, fs: c.fontSize };
      out.d = { drawn: d.drawn };
      out.e = { drawn: e.drawn };
      out.mid = { h: mid.height, overflow: mid.overflow, fs: mid.fontSize };
      let err = null; try { C.render({ text: '   ' }); } catch (x) { err = x.message; }
      out.err = err;
      // pixel: dải trên cùng/dưới cùng chỉ gồm nền trắng + vạch màu (không status bar / bottom bar)
      const g = a.canvas.getContext('2d'); const row = y => { const dd = g.getImageData(40, y, a.width - 40, 1).data; for (let i = 0; i < dd.length; i += 4) if (!(dd[i] > 240 && dd[i + 1] > 240 && dd[i + 2] > 240)) return false; return true; };
      out.cleanEdges = row(2) && row(5) && row(a.height - 3) && row(a.height - 6);
      return out;
    });
    check('mặc định: chỉ vẽ nội dung (không username/tim)', JSON.stringify(r.a.drawn) === JSON.stringify(['Bình luận ngắn 😂']), r.a.drawn);
    check('bật username + tim (có số thật): vẽ đúng 3 chuỗi', JSON.stringify(r.b.drawn) === JSON.stringify(['@abc', 'Bình luận ngắn 😂', '1,2K']), r.b.drawn);
    check('không có chuỗi nào chứa “Threads”', !JSON.stringify([r.a, r.b, r.d, r.e]).toLowerCase().includes('threads'));
    check('không có số tim khi API không có (null)', !r.d.drawn.some(s => /^\d/.test(s)) && !r.e.drawn.some(s => /^-?\d/.test(s)), [r.d.drawn, r.e.drawn]);
    check('không username khi không có dữ liệu', !r.d.drawn.some(s => s.startsWith('@')));
    check('thẻ 1080 rộng, nền không rỗng (có chữ)', r.a.w === 1080 && r.a.dark > 200, r.a);
    check('thẻ ngắn có chiều cao tối thiểu', r.a.h >= 420 && r.a.h <= 1220);
    check('văn bản vừa: tự co cỡ chữ, không tràn khung', r.mid.h <= 1220 && !r.mid.overflow, r.mid);
    check('văn bản rất dài: đánh dấu overflow (engine sẽ cuộn)', r.c.overflow === true && r.c.h > 1220 && r.c.fs <= 36, r.c);
    check('đường viền trên/dưới không có thanh nào (sạch)', r.cleanEdges);
    check('text rỗng bị từ chối, không tạo ảnh giả', /Không có nội dung/.test(r.err), r.err);
    await page.close();
  }

  /* ---------------------------------------------------------------- 7 */
  section('7. Lưu trạng thái: đóng/mở lại app không mất lựa chọn và trạng thái duyệt');
  {
    const cfg = { research: F.research(10) };
    const { page } = await newPage(browser, cfg);
    await runResearch(page);
    await page.click('#cp1List .vl:nth-child(1) button:nth-of-type(3)');          // bỏ C1
    await page.click('#btnCp1');
    await waitFor(page, () => T2V_P.stage === 'cp2');
    await page.click('#cp2List .it:nth-child(1) .btns3 button:nth-child(1)');     // duyệt bài gốc
    await page.waitForTimeout(500);
    const saved = (await M(page)).saved.current;
    check('project đã được lưu qua cầu nối', typeof saved === 'string' && saved.length > 100);
    const want = JSON.parse(saved);
    const { page: p2 } = await newPage(browser, { preload: saved });
    await waitFor(p2, () => T2V_P.stage === 'cp2' && !document.getElementById('cp2Box').hidden);
    const got = await p2.evaluate(() => JSON.parse(JSON.stringify(T2V_P)));
    check('khôi phục đúng danh sách đã chọn', JSON.stringify(got.selectedIds) === JSON.stringify(want.selectedIds) && !got.selectedIds.includes('C1'));
    check('khôi phục đúng trạng thái đã xác nhận + đã duyệt', got.cp1Confirmed === true && got.items[0].approvedForVideo === true && got.items[1].approvedForVideo === false);
    check('khôi phục ảnh thẻ', (await p2.$$('#cp2List img.cardprev')).length === got.items.length);
    check('rawText khôi phục nguyên bản', got.items.every(i => i.id === 'P1' ? i.rawText === F.P1.rawText : i.rawText === F.comments.find(c => c.id === i.id).rawText));
    // đổi lựa chọn ⇒ phải xác nhận lại, giữ thẻ theo ID
    await p2.click('#cp1List .vl:nth-child(1) button:nth-of-type(3)');
    check('đổi lựa chọn ⇒ hủy xác nhận, ẩn CP2', (await p2.evaluate(() => T2V_P.cp1Confirmed)) === false && await p2.$eval('#cp2Box', e => e.hidden));
    const before = (await M(p2)).calls.filter(c => c.name === 'card.save').length;
    await p2.click('#btnCp1'); await waitFor(p2, () => T2V_P.stage === 'cp2');
    const after = (await M(p2)).calls.filter(c => c.name === 'card.save').length;
    check('xác nhận lại không dựng lại thẻ đã có (giữ theo ID)', after === before, { before, after });
    check('mục bị bỏ ⇒ yêu cầu xóa thẻ của nó', ((await M(p2)).deleted || []).length >= 1);
    await page.close(); await p2.close();
  }

  /* ---------------------------------------------------------------- 8 */
  section('8. Hồi quy engine video: audio, timeline, preview, export, MediaStore, share');
  {
    const cfg = { research: F.research(4) };
    const { page, errors } = await newPage(browser, cfg);
    // dựng luồng API nhanh: gửi 1 bài + 2 bình luận đã duyệt
    await runResearch(page);
    await page.click('#btnCp1'); await waitFor(page, () => T2V_P.stage === 'cp2');
    await page.evaluate(() => { T2V_P.items.forEach((i, k) => { i.approvedForVideo = k < 3 && !i.needsManualReview; }); });
    await page.evaluate(() => T2V_review.render());
    await page.click('#btnSend'); await waitFor(page, () => window.__t2v.S.api !== null);
    const nSeg = await page.evaluate(() => __t2v.S.api.items.length);
    // 3 file giọng tổng hợp (sóng sin)
    await page.evaluate(async n => {
      const ac = new AudioContext(), rate = 24000;
      function wav(sec, f) {
        const len = Math.round(sec * rate), buf = new ArrayBuffer(44 + len * 2), dv = new DataView(buf);
        const w = (o, s) => { for (let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
        w(0, 'RIFF'); dv.setUint32(4, 36 + len * 2, true); w(8, 'WAVE'); w(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true);
        dv.setUint32(24, rate, true); dv.setUint32(28, rate * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); w(36, 'data'); dv.setUint32(40, len * 2, true);
        for (let i = 0; i < len; i++) dv.setInt16(44 + i * 2, Math.round(Math.sin(i / rate * 2 * Math.PI * f) * 0.4 * 32767), true);
        return buf;
      }
      for (let i = 0; i < n; i++) await __t2v.addVoiceBuffer('0' + (i + 1) + '.wav', wav(0.9 + i * 0.2, 300 + i * 100));
      __t2v.renderVoices();
    }, nSeg);
    await page.evaluate(() => { __t2v.cfg.quality = '720'; document.getElementById('quality').value = '720'; });
    await page.evaluate(() => go(4));
    await page.click('#btnPrep');
    await waitFor(page, () => __t2v.S.ready === true, null, 20000);
    const info = await page.evaluate(() => ({ n: __t2v.S.segs.length, total: __t2v.S.total, voices: __t2v.S.segs.map(s => s.voice), sp: __t2v.S.segs.map(s => s.sp), imgs: __t2v.S.segs.map(s => !!s.img) }));
    check('timeline dựng được từ mục đã duyệt + file giọng', info.n === nSeg && info.total > 3 && info.voices.every(v => v === 'file'), info);
    check('mọi đoạn dùng thẻ ảnh API', info.imgs.every(Boolean));
    check('prepare đã trả RAM model (export.prepare)', (await callsOf(page, 'export.prepare')).length >= 1);
    // số file ≠ số đoạn ⇒ lỗi rõ (hành vi cũ giữ nguyên)
    // preview
    await page.click('#btnPlay');
    await page.waitForTimeout(1500);
    check('preview đang chạy (canvas vẽ + nút Dừng hiện)', (await page.$eval('#btnCancel', b => b.style.display)) === 'block');
    const nonBlank = await page.evaluate(() => { const c = document.getElementById('cv'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let w = 0; for (let i = 0; i < d.length; i += 4) if (d[i] > 235 && d[i + 1] > 235 && d[i + 2] > 235) w++; return w; });
    check('khung preview có thẻ trắng của card', nonBlank > 2000, nonBlank);
    await page.click('#btnCancel');
    await waitFor(page, () => document.getElementById('btnCancel').style.display === 'none');
    // export
    await page.click('#btnExport');
    await waitFor(page, () => !!window.__lastExport, null, 60000);
    const ex = await page.evaluate(() => window.__lastExport);
    const m = await M(page);
    check('export tạo file có dung lượng', ex.size > 5000, ex);
    check('lưu qua MediaStore bridge (beginSave/writeChunk/endSave)', m.saveName && /^Threads2Video_\d+\.(mp4|webm)$/.test(m.saveName) && m.chunks.length >= 1, m.saveName);
    check('nút chia sẻ hiện sau khi lưu', (await page.$eval('#btnShare', b => b.style.display)) === 'block');
    await page.click('#btnShare');
    check('share gọi cầu nối với URI đã lưu', (await M(page)).shares.length === 1 && (await M(page)).shares[0][0] === 'content://mock/video/1');
    check('export cũng trả RAM model', (await callsOf(page, 'export.prepare')).length >= 2);
    check('không lỗi JS trong cả quy trình video', errors.length === 0, errors);
    await page.close();
  }

  section('9. Hồi quy chế độ nhập thủ công CŨ (không qua API) + tách file dài theo khoảng lặng');
  {
    const { page, errors } = await newPage(browser, {});
    const r = await page.evaluate(async () => {
      document.getElementById('btnSample').click();
      __t2v.cfg.aiPick = false; __t2v.cfg.topN = '3';
      document.getElementById('aiPick').checked = false;
      const plan = await __t2v.getPlan(true);
      return { n: plan.length, api: !!__t2v.S.api, types: plan.map(p => p.type), sp0: plan[0].sp.slice(0, 20) };
    });
    check('không có S.api ⇒ dùng luồng cũ (1 bài + Top 3)', r.n === 4 && r.api === false && r.types[0] === 'post', r);
    // một file dài, tách theo khoảng lặng
    const split = await page.evaluate(async () => {
      const rate = 24000, tone = (s, f) => Array.from({ length: Math.round(s * rate) }, (_, i) => Math.sin(i / rate * 2 * Math.PI * f) * 0.4);
      const sil = s => new Array(Math.round(s * rate)).fill(0);
      const all = [].concat(tone(1, 300), sil(1.2), tone(1.2, 400), sil(1.2), tone(0.9, 500), sil(1.2), tone(1, 600));
      const len = all.length, buf = new ArrayBuffer(44 + len * 2), dv = new DataView(buf), w = (o, s) => { for (let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
      w(0, 'RIFF'); dv.setUint32(4, 36 + len * 2, true); w(8, 'WAVE'); w(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true);
      dv.setUint32(24, rate, true); dv.setUint32(28, rate * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); w(36, 'data'); dv.setUint32(40, len * 2, true);
      for (let i = 0; i < len; i++) dv.setInt16(44 + i * 2, Math.round(all[i] * 32767), true);
      __t2v.S.vfiles = []; await __t2v.addVoiceBuffer('long.wav', buf); __t2v.renderVoices();
      __t2v.cfg.importMode = 'split'; __t2v.cfg.voiceSrc = 'file'; document.getElementById('importMode').value = 'split';
      document.getElementById('btnPrep').click();
      await new Promise(res => { const t = setInterval(() => { if (__t2v.S.ready || /Lỗi|Chỉ tìm|file/.test(document.getElementById('plog').textContent) && !__t2v.S.busy) { clearInterval(t); res(); } }, 100); });
      return { ready: __t2v.S.ready, durs: __t2v.S.segs.map(s => +s.audioDur.toFixed(1)), log: document.getElementById('plog').textContent.slice(0, 200) };
    });
    check('tách 1 file dài thành 4 đoạn theo khoảng lặng', split.ready && split.durs.length === 4 && split.durs[0] > 0.9 && split.durs[1] > 1.1, split);
    check('không lỗi JS', errors.length === 0, errors);
    await page.close();
  }

  section('10. Nút Back: lùi đúng bước trong luồng duyệt');
  {
    const { page } = await newPage(browser, { research: F.research(4) });
    await runResearch(page);
    await page.click('#btnCp1'); await waitFor(page, () => T2V_P.stage === 'cp2');
    check('Back ở CP2 → về CP1, không thoát app', (await page.evaluate(() => window.__back())) === false && (await page.evaluate(() => T2V_P.stage)) === 'cp1');
    check('Back lần nữa ở pane 1 → cho phép thoát', (await page.evaluate(() => window.__back())) === true);
    await page.close();
  }

  await browser.close();
  console.log('\n' + pass + ' đạt, ' + fail + ' thất bại');
  if (fail) { console.log('Thất bại:\n - ' + failures.join('\n - ')); process.exit(1); }
})().catch(e => { console.error(e); process.exit(2); });
