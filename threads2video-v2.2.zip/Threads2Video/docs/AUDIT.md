# Báo cáo kiểm toán (trước khi remake) — Threads2Video v2.1

Ngày: 2026-11-15. Nguồn: đọc trực tiếp code (không dựa tên file/README) + tài liệu Meta mở lại ngày này.

## 0. Hiện trạng ZIP khác với tài liệu 01

ZIP không chỉ là v2.1. Ngoài bản gốc (commit `baseline` trong `src/.git`) còn có **hai bản làm dở của lần trước**:
(a) ở gốc ZIP: lớp Kotlin OAuth/token/`NativeApi`/model manager/JNI, chưa nối vào UI; `backend/token-broker/` **rỗng**;
(b) trong `src/`: lõi thuần JVM (workflow/ranker/TTS normalizer) + `docs/AUDIT.md` cũ. Khi chạy thử: biên dịch được nhưng **6/139 test thất bại**
(3 do dữ liệu test sai, 1 do trọng số xếp hạng sai thật, 1 do test phụ thuộc thời gian, 1 do host API). Đã sửa; các ghi chú "đã xác minh" của bản cũ được kiểm lại ở mục 4.
Quyết định: nền = commit baseline v2.1; lõi = (b); OAuth/token/cầu nối = chuyển từ (a) sang kiểu dữ liệu của (b).

## 1. Chức năng hiện có đã xác nhận trong code

| Chức năng | File / hàm |
|---|---|
| Nhập tác giả, bài, bình luận thủ công; mẫu; xóa | `index.html` (#pUser #pText #cText), `app.js: parseComments, updateCount, SAMPLE, init` |
| Video nền, cắt 9:16, điểm bắt đầu, độ tối | `app.js: vidIn.onchange, seekStart, drawFrame` |
| Import audio nhiều file / một file dài tách theo khoảng lặng | `app.js: addVoiceBuffer, renderVoices, splitRanges, attachFiles, trimToBuffer` |
| Nhận file giọng từ VieNeu Studio (Kotlin→JS theo chunk base64) | `StudioActivity.kt`, `MainActivity.deliverVoices`, `app.js: __vcBegin/__vcChunk/__vcEnd` |
| Gemini TTS (online), nghe thử | `app.js: tts, previewVoice, gemRaw` |
| AI cloud chọn Top N / viết lại (OpenAI, Gemini) | `app.js: aiPick, oaText, gemText, llmText` |
| Kế hoạch đọc + cache | `app.js: getPlan, planKeyNow, renderPlan, invalidatePlan` |
| Timeline, preview, pop/slide/fade, neon, tô sáng, SFX, nhạc nền | `app.js: prepare, layout, layoutImg, drawFrame, run, sfxPop` |
| Export 1080×1920 / 720×1280 (Canvas + MediaRecorder) | `app.js: run(true), doExport, pickMime` |
| Lưu `Movies/Threads2Video` (MediaStore), chia sẻ | `MainActivity.Bridge: beginSave/writeChunk/endSave/share` ↔ `app.js: saveBlob, btnShare` |
| Ảnh thủ công + che avatar/tên + OCR **cloud** | `app.js: loadShot, detectRects, buildProc, openEditor, ocrShots, visionText` |
| Caption/hashtag | `app.js: makeCaption` |
| Research Threads bằng **DOM scraping** (phải bỏ) | `ThreadsActivity.kt: SCRAPE_JS`, `research.js`, `MainActivity.Bridge.openThreads`, `deliverThreads`, `window.__thr` |

Lời gọi JS→Kotlin (grep thật): `openStudio, beginSave, writeChunk, endSave, share` (app.js), `openThreads` (research.js). Kotlin→JS: `__vcBegin/__vcChunk/__vcEnd`, `__back`, `__thr`. `exit`, `toast` khai báo nhưng JS không gọi.

## 2. Chỗ phải đổi để đưa phương án A vào

- Xóa `ThreadsActivity` (scraper, cookie, giả UA), `openThreads`, `deliverThreads`, `__thr`, khai báo manifest.
- Viết lại `research.js`; thêm `bridge.js`, `review.js`, `cards.js`; sửa `index.html`.
- `getPlan()` thêm nhánh nhận danh sách đã duyệt (checkpoint 2); `aiPick()` cloud không được ghi đè `rawText`.
- Thêm lớp Kotlin: OAuth + token Keystore, API client, repository/workflow, AI cục bộ, model manager, project/card store, `NativeApi`.
- `AndroidManifest`: deep link OAuth, `allowBackup=false`. `build.gradle.kts`: BuildConfig, test, CMake/NDK tùy chọn. CI chạy test.

## 3. Rủi ro làm hỏng import audio / timeline / canvas / preview / export

1. `attachFiles` yêu cầu số file giọng == số đoạn (`1 + số bình luận`). Đổi/bỏ/xếp lại Top 8 đổi `k` ⇒ bắt buộc `invalidatePlan()`.
2. `getPlan` cache theo `planKeyNow()` (chỉ textarea + cfg) ⇒ nhánh đã duyệt phải vào khóa cache.
3. `layoutImg` cache theo `im.id + im.ver`, giới hạn chiều cao thẻ 56% khung, phần dư cuộn theo giọng ⇒ card cần id duy nhất, tăng `ver` khi dựng lại; tỉ lệ cao/rộng ≤ ~1,13 để không cuộn.
4. `S.shots` giữ canvas full-res; thêm PNG + PCM + MediaRecorder + LLM trên 8 GB ⇒ nhả model trước `prepare/doExport`.
5. `__vcBegin/Chunk/End` chạy trong `onResume` ⇒ giữ nguyên.
6. `window.__back` điều khiển Back theo pane ⇒ màn hình mới phải tôn trọng.
7. `StudioActivity` nhận `plan.map(s => s.sp)` ⇒ `sp` phải là `ttsText`.
8. `allowBackup="true"` + token ⇒ tắt backup.
9. `StudioActivity` bỏ `; wv` khỏi User-Agent cho vieneu.io (không phải Threads). Giữ nguyên.
10. Không có `gradlew`; CI dùng Gradle 8.9.

## 4. Meta API — đã đối chiếu tài liệu chính thức ngày 2026-11-15

- **Keyword search** `GET https://graph.threads.com/v1.0/keyword_search`: cần `threads_basic` + `threads_keyword_search`. Tham số: `q` (bắt buộc), `search_type` `TOP|RECENT` (mặc định TOP), `search_mode` `KEYWORD|TAG`, `media_type` `TEXT|IMAGE|VIDEO`, `since`, `until`, `limit` (25, tối đa 100), `author_username`. Hạn mức 2.200 query/24h/người dùng (query rỗng không tính). Từ nhạy cảm → mảng rỗng. Trang **không mô tả phân trang**. Nguyên văn: chưa được duyệt thì "the search is performed only on posts owned by the authenticated user" — app phải tự phát hiện (không có lỗi).
- **Replies** `GET /{media-id}/replies` (cấp 1), `GET /{media-id}/conversation` (mọi cấp, chỉ dùng trên bài gốc). `reverse` mặc định `true`. Response có `paging.cursors{before,after}`; **trang không nêu cách truyền cursor** (dùng quy ước Graph `after=` + ưu tiên `paging.next`; chưa thể chạy thật). **Không có `like_count`** ở replies. `username`/`permalink` chỉ có với người dùng công khai/chính mình. Trang này **không ghi permission**; trang token liệt kê `threads_read_replies` — dùng và xử lý lỗi quyền.
- **OAuth**: cửa sổ `https://threads.com/oauth/authorize` (`client_id, redirect_uri, scope, response_type=code, state`). Đổi code `POST https://graph.threads.com/oauth/access_token` **bắt buộc `client_secret`**; mã dùng một lần, sống 1 giờ. Đổi sang token dài hạn `GET https://graph.threads.com/access_token?grant_type=th_exchange_token` **bắt buộc `client_secret`, chỉ phía server**. Làm mới `GET …/refresh_access_token?grant_type=th_refresh_token` (không cần secret; token ≥24h tuổi, chưa hết hạn). Token ngắn 1 giờ, dài 60 ngày.
- Danh sách scope ở trang token **không có** `threads_keyword_search` (chỉ trang keyword-search nhắc) ⇒ tên scope này chưa xác nhận được qua trang token; app gửi scope này nhưng ghi chú trong README để chủ app đối chiếu App Dashboard.
- **Hệ quả**: không thể đăng nhập an toàn chỉ bằng APK ⇒ cần backend broker (đã viết bản tham chiếu `backend/token-broker`, chưa triển khai thật). Có đường dự phòng "dán token" cho người thử.
- **Chưa xác minh được**: hành vi thật khi gọi bằng app/token thật (không có credentials Meta); replies của bài người khác có đọc được không.

## 5. Giới hạn môi trường làm việc

Shell không có mạng tới Maven/Google, không có Android SDK/NDK ⇒ **không build APK, không biên dịch JNI/llama.cpp được ở đây**.
Kiểm chứng được: Kotlin thuần JVM (biên dịch + test), web trong Chromium (Playwright) với cầu nối giả, broker Node với Meta giả.
