'use strict';
/*
 * Phương án A: dựng "thẻ bình luận" PNG từ DỮ LIỆU CÓ CẤU TRÚC (không phải ảnh chụp màn hình).
 *
 * Quy tắc cứng (xem tài liệu mục C/8):
 *  - Chỉ vẽ: nội dung bình luận (rawText), @username (nếu người dùng bật), số tim (nếu API có thật và người dùng bật).
 *  - KHÔNG vẽ: chữ/logo Threads, status bar, top bar, bottom bar, khung trình duyệt, avatar, watermark.
 *  - KHÔNG chụp WebView/DOM, KHÔNG dùng MediaProjection, KHÔNG OCR.
 *  - Mỗi lần gọi render() tạo đúng MỘT ảnh cho MỘT mục.
 *  Hàm render() trả kèm `drawn` = mọi chuỗi đã vẽ, để kiểm thử xác nhận không có chữ nào ngoài các nguồn trên.
 */
(function () {
  const FONT = '"Noto Sans","Roboto","Segoe UI",system-ui,sans-serif';
  const W = 1080;
  /* Engine video (layoutImg) hiện thẻ cao tối đa 56% khung hình; thẻ rộng 88% ⇒ cao/rộng ≤ ~1,131 thì không phải cuộn. */
  const MAX_H = 1220, MIN_H = 420, PAD = 72, ACCENT_W = 14, HARD_MAX_H = 3600;

  const fmtCount = n => n >= 1e6 ? (n / 1e6).toFixed(1).replace('.', ',') + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1).replace('.', ',') + 'K' : String(n);

  function wrapLines(g, text, maxW) {
    const lines = [];
    const paras = String(text).replace(/\r\n?/g, '\n').split('\n');
    for (const para of paras) {
      if (!para.trim()) { lines.push(''); continue; }
      let cur = '';
      for (const word of para.split(/\s+/).filter(Boolean)) {
        const t = cur ? cur + ' ' + word : word;
        if (g.measureText(t).width <= maxW) { cur = t; continue; }
        if (cur) { lines.push(cur); cur = ''; }
        if (g.measureText(word).width <= maxW) { cur = word; continue; }
        // từ dài hơn một dòng (URL, chuỗi ký tự): cắt theo ký tự (Array.from để không tách emoji)
        let piece = '';
        for (const ch of Array.from(word)) {
          if (piece && g.measureText(piece + ch).width > maxW) { lines.push(piece); piece = ''; }
          piece += ch;
        }
        cur = piece;
      }
      if (cur) lines.push(cur);
    }
    while (lines.length && lines[lines.length - 1] === '') lines.pop();
    return lines;
  }

  function heart(g, cx, cy, s, color) {
    g.save(); g.fillStyle = color; g.beginPath();
    g.moveTo(cx, cy + s * 0.9);
    g.bezierCurveTo(cx - s * 1.3, cy + s * 0.1, cx - s * 0.9, cy - s * 0.9, cx, cy - s * 0.35);
    g.bezierCurveTo(cx + s * 0.9, cy - s * 0.9, cx + s * 1.3, cy + s * 0.1, cx, cy + s * 0.9);
    g.fill(); g.restore();
  }

  /**
   * opts: { text (bắt buộc), username, likeCount, showUsername, showLikes, accent }
   * Trả { canvas, width, height, fontSize, overflow, drawn }.
   */
  function render(opts) {
    const text = String(opts.text == null ? '' : opts.text);
    if (!text.trim()) throw new Error('Không có nội dung để dựng thẻ');
    const showUser = !!(opts.showUsername && opts.username);
    const showLikes = !!(opts.showLikes && typeof opts.likeCount === 'number' && isFinite(opts.likeCount) && opts.likeCount >= 0);
    const accent = opts.accent || '#22d3ee';
    const drawn = [];

    const probe = document.createElement('canvas').getContext('2d');
    const maxW = W - 2 * PAD - ACCENT_W;
    const headH = (showUser ? 70 : 0);
    const footH = (showLikes ? 84 : 0);
    let fs = 58, lines, lh;
    for (;;) {
      probe.font = '500 ' + fs + 'px ' + FONT;
      lines = wrapLines(probe, text, maxW);
      lh = Math.round(fs * 1.38);
      if (PAD * 2 + headH + footH + lines.length * lh <= MAX_H || fs <= 34) break;
      fs -= 2;
    }
    const bodyH = lines.length * lh;
    let H = Math.max(MIN_H, PAD * 2 + headH + footH + bodyH);
    const overflow = H > MAX_H;
    H = Math.min(H, HARD_MAX_H);

    const cv = document.createElement('canvas');
    cv.width = W; cv.height = H;
    const g = cv.getContext('2d');
    const put = (s, x, y) => { drawn.push(s); g.fillText(s, x, y); };

    g.fillStyle = '#ffffff'; g.fillRect(0, 0, W, H);
    g.fillStyle = accent; g.fillRect(0, 0, ACCENT_W, H);

    const x0 = ACCENT_W + PAD;
    let y = PAD;
    if (showUser) {
      g.font = '700 36px ' + FONT; g.fillStyle = '#475569'; g.textBaseline = 'alphabetic';
      put('@' + String(opts.username).replace(/^@/, ''), x0, y + 34);
      y += headH;
    }
    // nội dung được căn giữa theo chiều dọc khi thẻ ngắn
    const free = H - 2 * PAD - headH - footH - bodyH;
    if (free > 0) y += Math.round(free / 2);
    g.font = '500 ' + fs + 'px ' + FONT; g.fillStyle = '#0f172a'; g.textBaseline = 'alphabetic';
    for (let i = 0; i < lines.length; i++) if (lines[i]) put(lines[i], x0, y + i * lh + Math.round(fs * 0.98));

    if (showLikes) {
      const fy = H - PAD + 4;
      heart(g, x0 + 18, fy - 14, 15, '#e11d48');
      g.font = '600 34px ' + FONT; g.fillStyle = '#475569'; g.textBaseline = 'alphabetic';
      put(fmtCount(opts.likeCount), x0 + 52, fy - 2);
    }
    return { canvas: cv, width: W, height: H, fontSize: fs, overflow, drawn };
  }

  function toPngBase64(canvas) {
    return new Promise((resolve, reject) => {
      canvas.toBlob(b => {
        if (!b) { reject(new Error('Không tạo được PNG')); return; }
        const r = new FileReader();
        r.onload = () => resolve(String(r.result).split(',')[1]);
        r.onerror = () => reject(new Error('Không đọc được PNG'));
        r.readAsDataURL(b);
      }, 'image/png');
    });
  }

  /** Giải mã một thẻ đã lưu về canvas để engine video dùng (cùng origin nên không bị "tainted"). */
  function loadImage(url) {
    return new Promise((resolve, reject) => {
      const im = new Image();
      im.onload = () => {
        const c = document.createElement('canvas');
        c.width = im.naturalWidth; c.height = im.naturalHeight;
        c.getContext('2d').drawImage(im, 0, 0);
        resolve(c);
      };
      im.onerror = () => reject(new Error('Không đọc được ảnh thẻ đã lưu'));
      im.src = url;
    });
  }

  window.T2V_CARDS = { render, toPngBase64, loadImage, fmtCount, WIDTH: W, MAX_H };
})();
