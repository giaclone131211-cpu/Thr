'use strict';
/*
 * Research Threads qua API CHÍNH THỨC (Kotlin: ThreadsApiClient/ThreadsRepository) + Checkpoint 1.
 * Thay thế hoàn toàn bản cũ dùng WebView DOM scraping. Không có nhánh nào tự quay về cào trang:
 * khi thiếu quyền/lỗi/rỗng, UI báo đúng nguyên nhân và đề nghị dùng nhập thủ công (do người dùng chọn).
 *
 * Trạng thái dùng chung: window.T2V_P (project). review.js lo bước tạo thẻ + Checkpoint 2.
 */
(function () {
  const $ = id => document.getElementById(id);
  const B = window.T2V_BRIDGE;
  const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  const fmt = n => window.T2V_CARDS.fmtCount(n);
  const MAX_SELECT = 20;

  /* ---------- trạng thái project ---------- */
  const P = {
    v: 1, id: 'current', topic: '', criteria: 'mix', topN: 8, origin: 'api',
    stage: 'research',            // research | cp1 | cards | cp2
    candidates: [], source: null, comments: [], selectedIds: [], dropped: [], notices: [], engine: null,
    cp1Confirmed: false,
    cardOpts: { showUsername: false, showLikes: true },
    items: []                     // do review.js quản lý
  };
  window.T2V_P = P;

  let saveT = 0;
  function persist() {
    if (!B.available()) return;
    clearTimeout(saveT);
    saveT = setTimeout(() => {
      B.call('project.save', { id: P.id, json: JSON.stringify(P) }).catch(() => { /* lưu lỗi không chặn thao tác */ });
    }, 250);
  }
  window.T2V_persist = persist;

  /* ---------- thông báo / lỗi ---------- */
  function describeError(e) {
    if (!e) return 'Có lỗi không rõ.';
    const m = e.message || 'Có lỗi.';
    switch (e.code) {
      case 'no_native': return m;
      case 'not_configured': return m;
      case 'not_authorized': return m + ' (mở “Kết nối Threads” để đăng nhập)';
      case 'consent_denied': return 'Bạn đã từ chối cấp quyền. Hãy đăng nhập lại và bấm đồng ý nếu muốn dùng tìm kiếm tự động.';
      case 'permission_denied': return 'Chưa được Meta cấp quyền' + (e.permission ? ' ' + e.permission : '') + '. ' + m + ' Bạn có thể dùng “Nhập thủ công” bên dưới.';
      case 'rate_limited': return m + (e.retryAfterSec ? ' (thử lại sau ~' + e.retryAfterSec + ' giây)' : '');
      case 'network': return m;
      default: return m;
    }
  }
  window.T2V_describeError = describeError;

  function showNotices(list) {
    const box = $('rsNotices'); box.innerHTML = '';
    (list || []).forEach(n => {
      const d = el('div', 'notice ' + (n.code === 'own_posts_only' || n.code === 'empty_results' ? 'warn' : 'info'), n.message);
      box.appendChild(d);
    });
  }
  function setStatus(msg, cls) { const s = $('rsStatus'); s.textContent = msg || ''; s.className = 'hint' + (cls ? ' ' + cls : ''); }

  /* ---------- kết nối Threads ---------- */
  function renderAuth(st) {
    const line = $('thrState');
    if (!st) { line.textContent = 'Không đọc được trạng thái đăng nhập.'; return; }
    if (st.loggedIn) {
      const exp = st.expiresAt ? ' · hết hạn ' + new Date(st.expiresAt).toLocaleDateString('vi-VN') : '';
      line.textContent = 'Đã đăng nhập' + (st.username ? ' @' + st.username : '') + (st.source === 'manual' ? ' (token dán tay)' : '') + exp;
      line.className = 'hint ok';
    } else {
      line.textContent = st.configured ? 'Chưa đăng nhập. Bấm “Đăng nhập Threads”.' : 'Chưa cấu hình App ID và backend. Hoặc dán token để thử.';
      line.className = 'hint';
    }
    if (document.activeElement !== $('thrAppId')) $('thrAppId').value = st.appId || '';
    if (document.activeElement !== $('thrBroker')) $('thrBroker').value = st.brokerUrl || '';
    $('btnThrOut').style.display = st.loggedIn ? '' : 'none';
  }
  async function refreshAuth() {
    if (!B.available()) { renderAuth({ configured: false, loggedIn: false }); $('thrState').textContent = 'Chỉ chạy trong app Android.'; return; }
    try { renderAuth(await B.call('auth.status', {})); } catch (e) { $('thrState').textContent = describeError(e); }
  }
  B.on('auth.result', p => {
    if (p && p.ok) { renderAuth(p.status); toast('Đăng nhập Threads thành công'); }
    else toast(describeError(p && p.error));
    refreshAuth();
  });

  function bindSettings() {
    $('btnThrSave').onclick = async () => {
      try {
        renderAuth(await B.call('config.set', { appId: $('thrAppId').value, brokerUrl: $('thrBroker').value }));
        toast('Đã lưu cấu hình');
      } catch (e) { toast(describeError(e)); }
    };
    $('btnThrIn').onclick = async () => {
      try {
        await B.call('config.set', { appId: $('thrAppId').value, brokerUrl: $('thrBroker').value });
        await B.call('auth.begin', {});
        toast('Đang mở trình duyệt để đăng nhập…');
      } catch (e) { toast(describeError(e)); }
    };
    $('btnThrOut').onclick = async () => {
      try { renderAuth(await B.call('auth.logout', {})); toast('Đã đăng xuất và xóa token'); } catch (e) { toast(describeError(e)); }
    };
    $('btnThrTok').onclick = async () => {
      const t = $('thrToken').value.trim();
      if (!t) { toast('Dán access token trước'); return; }
      try {
        renderAuth(await B.call('auth.manualToken', { token: t, expiresInSec: null }));
        $('thrToken').value = '';
        toast('Token hợp lệ, đã lưu an toàn');
      } catch (e) { toast(describeError(e)); }
    };
  }

  /* ---------- chạy research ---------- */
  let running = false;
  B.on('research.progress', p => { if (running && p) setStatus(p.message); });

  function setRunning(v) {
    running = v;
    $('btnRs').disabled = v;
    $('btnRsCancel').style.display = v ? '' : 'none';
    $('btnManual').disabled = v;
  }

  function resetForNewSource() {
    P.cp1Confirmed = false;
    P.items = [];
    P.stage = 'cp1';
  }

  function applySource(src, keepOrigin) {
    P.source = src.post;
    P.comments = src.comments || [];
    P.selectedIds = (src.topIds || []).slice(0, MAX_SELECT);
    P.dropped = src.dropped || [];
    P.engine = src.engine || null;
    if (!keepOrigin) P.origin = 'api';
    resetForNewSource();
  }

  async function runResearch() {
    const topic = $('rsTopic').value.trim();
    if (!topic) { toast('Nhập chủ đề trước'); return; }
    if (!B.available()) { setStatus('Tính năng này chỉ chạy trong app Android.', 'err'); return; }
    P.topic = topic; P.criteria = $('rsCrit').value; P.topN = +$('rsN').value || 8;
    setRunning(true); setStatus('Đang bắt đầu…'); showNotices([]);
    try {
      const r = await B.call('research.run', { topic, criteria: P.criteria, topN: P.topN });
      P.candidates = r.candidates || [];
      P.notices = r.notices || [];
      showNotices(P.notices);
      if (r.source) {
        applySource(r.source);
        P.notices = P.notices.concat(r.source.notices || []);
        showNotices(P.notices);
        setStatus('Đã tìm ' + P.candidates.length + ' bài, lấy ' + P.comments.length + ' bình luận hợp lệ.', 'ok');
      } else {
        P.source = null; P.comments = []; P.selectedIds = []; P.stage = 'research';
        setStatus(P.candidates.length ? 'Chưa lấy được bình luận. Chọn bài khác bên dưới hoặc dùng nhập thủ công.' : 'Không có kết quả để tiếp tục.', 'warn');
      }
      persist(); renderAll();
    } catch (e) {
      if (e && e.code === 'cancelled') setStatus('Đã dừng.', 'warn');
      else { setStatus(describeError(e), 'err'); if (e && (e.code === 'not_configured' || e.code === 'not_authorized')) $('thrSet').open = true; }
    } finally { setRunning(false); }
  }

  async function pickCandidate(post) {
    if (running) return;
    setRunning(true); setStatus('Đang đọc bình luận của bài đã chọn…');
    try {
      const src = await B.call('research.source', { post, topic: P.topic, criteria: P.criteria, topN: P.topN });
      applySource(src);
      P.notices = (src.notices || []);
      showNotices(P.notices);
      setStatus('Đã lấy ' + P.comments.length + ' bình luận hợp lệ.', 'ok');
      persist(); renderAll();
    } catch (e) { setStatus(describeError(e), 'err'); }
    finally { setRunning(false); }
  }

  /* ---------- nhập thủ công (fallback do người dùng chọn, ghi rõ nguồn) ---------- */
  function parseLikes(s) {
    if (!s) return null;
    const m = String(s).trim().replace(/\s/g, '').match(/^([\d.,]+)([KkMm]?)$/);
    if (!m) return null;
    let v = parseFloat(m[1].replace(/\./g, '').replace(',', '.'));
    if (/^\d{1,3}(\.\d{3})+$/.test(m[1])) v = parseFloat(m[1].replace(/\./g, ''));
    if (!isFinite(v)) return null;
    if (/k/i.test(m[2])) v *= 1e3; else if (/m/i.test(m[2])) v *= 1e6;
    return Math.round(v);
  }

  async function useManual() {
    const text = $('pText').value.trim();
    if (!text) { toast('Nhập nội dung bài viết ở ô “Nội dung bài viết” trước'); return; }
    const cms = window.__t2v.parseComments($('cText').value);
    if (!cms.length) { toast('Nhập ít nhất một bình luận'); return; }
    const url = $('mLink').value.trim();
    const user = $('pUser').value.trim().replace(/^@/, '');
    const post = {
      id: 'manual-post', sourceUrl: url || null, authorUsername: user && user !== 'tacgia' ? user : null, rawText: text.replace(/\s+/g, ' ').trim(),
      createdAt: null, likeCount: null, hasReplies: true, isReply: false, relevanceScore: null, rankReasons: [], origin: 'manual'
    };
    const comments = cms.map((c, i) => ({
      id: 'manual-' + (i + 1), sourcePostId: post.id, sourceUrl: null,
      authorUsername: /^@nguoi_dung\d+$/.test(c.user) ? null : c.user.replace(/^@/, ''),
      rawText: c.text, ttsText: null, likeCount: parseLikes(c.likes), createdAt: null, rankScore: null, rankReasons: [],
      cardImageUri: null, ocrRequired: false, needsManualReview: false, approvedForVideo: false, origin: 'manual'
    }));
    P.topic = $('rsTopic').value.trim() || ''; P.criteria = $('rsCrit').value; P.topN = +$('rsN').value || 8;
    let ranked = null;
    if (B.available()) {
      try { ranked = await B.call('research.rank', { post, comments, topic: P.topic, criteria: P.criteria, topN: Math.min(MAX_SELECT, comments.length) }); }
      catch (e) { /* xếp hạng lỗi: giữ nguyên thứ tự người dùng nhập */ }
    }
    P.origin = 'manual'; P.candidates = [];
    P.source = post;
    P.comments = ranked ? ranked.comments : comments;
    P.selectedIds = (ranked ? ranked.topIds : comments.map(c => c.id)).slice(0, Math.min(P.topN, MAX_SELECT));
    P.dropped = ranked ? ranked.dropped : [];
    P.notices = [{ code: 'manual', message: 'Nội dung NHẬP THỦ CÔNG (không lấy từ Threads API). Hãy chắc bạn có quyền sử dụng nội dung này.' }];
    showNotices(P.notices);
    resetForNewSource(); persist(); renderAll();
    $('cp1Box').scrollIntoView();
  }

  /* ---------- Checkpoint 1 ---------- */
  const byId = id => P.comments.find(c => c.id === id);

  function metricLine(c) {
    const parts = [];
    if (c.likeCount != null) parts.push(fmt(c.likeCount) + ' tim (API)');
    if (c.authorUsername) parts.push('@' + c.authorUsername);
    if (c.rankScore != null) parts.push('điểm nội bộ ' + c.rankScore.toFixed(2));
    return parts.join(' · ');
  }

  function selectionChanged() {
    // đổi lựa chọn sau khi đã xác nhận ⇒ phải xác nhận lại; mục đã có thẻ/TTS được giữ theo ID
    P.cp1Confirmed = false;
    if (P.stage === 'cards' || P.stage === 'cp2') P.stage = 'cp1';
    persist(); renderCp1(); if (window.T2V_review) window.T2V_review.render();
  }

  function row(c, idx, selected) {
    const d = el('div', 'vl cm');
    d.appendChild(el('span', 'n', selected ? String(idx + 1) : '+'));
    const t = el('span', 't');
    const body = el('div', 'cmtxt', c.rawText);
    t.appendChild(body);
    const m = metricLine(c);
    const em = el('em', '', (m ? m + ' · ' : '') + (c.rankReasons && c.rankReasons.length ? c.rankReasons.join(', ') : ''));
    t.appendChild(em);
    t.onclick = () => { d.classList.toggle('open'); };
    d.appendChild(t);
    const mk = (lab, fn, cls) => { const b = el('button', cls || 'ghost', lab); b.onclick = e => { e.stopPropagation(); fn(); }; d.appendChild(b); return b; };
    if (selected) {
      mk('▲', () => { if (idx > 0) { const a = P.selectedIds; [a[idx - 1], a[idx]] = [a[idx], a[idx - 1]]; selectionChanged(); } });
      mk('▼', () => { const a = P.selectedIds; if (idx < a.length - 1) { [a[idx + 1], a[idx]] = [a[idx], a[idx + 1]]; selectionChanged(); } });
      mk('✕', () => { P.selectedIds.splice(idx, 1); selectionChanged(); });
    } else {
      mk('Thêm', () => {
        if (P.selectedIds.length >= MAX_SELECT) { toast('Tối đa ' + MAX_SELECT + ' bình luận'); return; }
        P.selectedIds.push(c.id); selectionChanged();
      }, 'pri');
    }
    return d;
  }

  function renderCp1() {
    const box = $('cp1Box');
    const show = !!P.source;
    box.hidden = !show;
    if (!show) return;
    $('cp1Origin').textContent = P.origin === 'manual' ? 'NHẬP THỦ CÔNG' : 'Threads API';
    $('cp1Origin').className = 'tag ' + (P.origin === 'manual' ? 'warn' : 'ok');
    const s = P.source;
    $('cp1Author').textContent = s.authorUsername ? '@' + s.authorUsername : '(không có tên tác giả từ API)';
    $('cp1Post').textContent = s.rawText;
    const link = $('cp1Link');
    if (s.sourceUrl && /^https:\/\//.test(s.sourceUrl)) { link.href = s.sourceUrl; link.textContent = s.sourceUrl; link.style.display = ''; }
    else { link.removeAttribute('href'); link.textContent = s.sourceUrl ? s.sourceUrl : '(không có permalink)'; link.style.display = ''; }

    // danh sách bài ứng viên (chỉ khi từ API)
    const cb = $('cp1Cands'); cb.innerHTML = '';
    const cands = (P.candidates || []).filter(p => p.id !== s.id);
    $('cp1CandsWrap').hidden = !cands.length;
    cands.forEach((p, i) => {
      const d = el('div', 'vl');
      d.appendChild(el('span', 'n', String(i + 1)));
      const t = el('span', 't', (p.authorUsername ? '@' + p.authorUsername + ' · ' : '') + (p.rawText.length > 100 ? p.rawText.slice(0, 100) + '…' : p.rawText));
      if (p.rankReasons && p.rankReasons.length) t.appendChild(el('em', '', p.rankReasons.join(', ')));
      d.appendChild(t);
      const b = el('button', 'ghost', 'Dùng bài này'); b.onclick = () => pickCandidate(p); d.appendChild(b);
      cb.appendChild(d);
    });

    // Top
    const list = $('cp1List'); list.innerHTML = '';
    const sel = P.selectedIds.map(byId).filter(Boolean);
    sel.forEach((c, i) => list.appendChild(row(c, i, true)));
    const rest = P.comments.filter(c => !P.selectedIds.includes(c.id));
    const rl = $('cp1Rest'); rl.innerHTML = '';
    rest.forEach(c => rl.appendChild(row(c, 0, false)));
    $('cp1RestWrap').hidden = !rest.length;

    const want = P.topN;
    const n = sel.length;
    let info = 'Đã chọn ' + n + ' bình luận.';
    if (P.comments.length < want) info += ' API chỉ có ' + P.comments.length + ' bình luận hợp lệ (mục tiêu ' + want + ') — không ép cho đủ.';
    if (!P.comments.some(c => c.likeCount != null)) info += ' API không trả số tim nên xếp hạng chỉ dựa trên nội dung.';
    $('cp1Info').textContent = info;
    if (P.dropped && P.dropped.length) {
      $('cp1Dropped').hidden = false;
      $('cp1DroppedTxt').textContent = P.dropped.length + ' bình luận bị loại tự động (spam/trùng/rác): ' + P.dropped.slice(0, 6).map(d => d.reason).join('; ') + (P.dropped.length > 6 ? '…' : '');
    } else $('cp1Dropped').hidden = true;

    const ok = $('btnCp1');
    ok.disabled = n === 0;
    ok.textContent = P.cp1Confirmed ? 'Đã xác nhận ' + n + ' bình luận ✓ (bấm để tạo lại)' : 'Xác nhận Top ' + n;
    $('cp1Box').classList.toggle('done', P.cp1Confirmed);
  }

  function renderAll() {
    // danh sách ứng viên khi CHƯA có nguồn (tìm thấy bài nhưng chưa lấy được bình luận)
    const w = $('rsCandsOnly'); w.innerHTML = '';
    if (!P.source && P.candidates.length) {
      P.candidates.forEach((p, i) => {
        const d = el('div', 'vl');
        d.appendChild(el('span', 'n', String(i + 1)));
        d.appendChild(el('span', 't', (p.authorUsername ? '@' + p.authorUsername + ' · ' : '') + (p.rawText.length > 100 ? p.rawText.slice(0, 100) + '…' : p.rawText)));
        const b = el('button', 'ghost', 'Dùng'); b.onclick = () => pickCandidate(p); d.appendChild(b);
        w.appendChild(d);
      });
    }
    renderCp1();
    if (window.T2V_review) window.T2V_review.render();
  }

  function confirmCp1() {
    if (!P.selectedIds.length) return;
    P.cp1Confirmed = true; P.stage = 'cards';
    persist(); renderCp1();
    window.T2V_review.start();
  }

  /** Back của Android: lùi một bước trong luồng nếu đang ở giữa luồng. */
  function back() {
    if (curPane !== 1) return false;
    if (P.stage === 'cp2' || P.stage === 'cards') { P.stage = 'cp1'; persist(); if (window.T2V_review) window.T2V_review.render(); renderCp1(); return true; }
    return false;
  }

  function restore(saved) {
    if (!saved || typeof saved !== 'object' || saved.v !== 1) return false;
    Object.assign(P, saved, { id: 'current' });
    $('rsTopic').value = P.topic || '';
    $('rsCrit').value = P.criteria || 'mix';
    $('rsN').value = String(P.topN || 8);
    $('optUser').checked = !!P.cardOpts.showUsername;
    $('optLikes').checked = !!P.cardOpts.showLikes;
    showNotices(P.notices);
    return true;
  }

  async function init() {
    ['tâm sự công sở', 'hài hước', 'tình yêu', 'gia đình', 'bạn bè'].forEach(t => {
      const b = el('button', 'ghost', t); b.onclick = () => { $('rsTopic').value = t; }; $('rsChips').appendChild(b);
    });
    bindSettings();
    $('btnRs').onclick = runResearch;
    $('btnRsCancel').onclick = () => { B.call('research.cancel', {}).catch(() => {}); };
    $('btnManual').onclick = useManual;
    $('btnCp1').onclick = confirmCp1;
    $('optUser').onchange = () => { P.cardOpts.showUsername = $('optUser').checked; persist(); };
    $('optLikes').onchange = () => { P.cardOpts.showLikes = $('optLikes').checked; persist(); };
    $('rsTopic').addEventListener('keydown', e => { if (e.key === 'Enter') runResearch(); });
    $('btnWipe').onclick = async () => {
      if (!confirm('Xóa toàn bộ dữ liệu project (danh sách, thẻ, bản đọc)? Token đăng nhập không bị xóa.')) return;
      try { await B.call('project.deleteAll', {}); } catch (e) { /* không có native */ }
      Object.assign(P, { source: null, comments: [], selectedIds: [], candidates: [], items: [], stage: 'research', cp1Confirmed: false, dropped: [], notices: [] });
      window.__t2v.clearApproved && window.__t2v.clearApproved();
      showNotices([]); setStatus('Đã xóa dữ liệu project.'); renderAll(); toast('Đã xóa dữ liệu project');
    };
    refreshAuth();
    if (B.available()) {
      try {
        const r = await B.call('project.load', { id: 'current' });
        if (r && r.json && restore(JSON.parse(r.json))) {
          renderAll();
          if (P.stage === 'cards' && window.T2V_review) window.T2V_review.start(true);
        }
      } catch (e) { /* chưa có project */ }
    }
    renderAll();
  }

  window.T2V_RS = { back, renderAll, selectionChanged, P, byId, restore };
  init();
})();
