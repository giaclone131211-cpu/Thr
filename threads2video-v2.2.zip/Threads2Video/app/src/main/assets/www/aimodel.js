'use strict';
/*
 * Quản lý model AI cục bộ (GGUF): tải có tiếp tục/hủy, nhập file, kiểm SHA-256 (Kotlin làm), nạp/giải phóng, xóa.
 * Giao diện chỉ nói chuyện với bridge/NativeDispatcher.kt; không biết JNI. Không hardcode link: danh mục do Kotlin cung cấp.
 */
(function () {
  const $ = id => document.getElementById(id);
  const B = window.T2V_BRIDGE;
  const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  const mb = n => n == null ? '?' : (n >= 1e9 ? (n / 1e9).toFixed(2).replace('.', ',') + ' GB' : Math.round(n / 1048576) + ' MB');
  let state = null, working = false;

  function bar(done, total) { $('aiBar').style.width = total > 0 ? Math.min(100, done / total * 100).toFixed(1) + '%' : '0%'; }

  async function refresh() {
    if (!B.available()) { $('aiStatus').textContent = 'Chỉ chạy trong app Android.'; return; }
    try {
      const [st, cat] = await Promise.all([B.call('ai.status', {}), B.call('model.catalog', {})]);
      state = cat;
      const kindTxt = st.kind === 'llm' ? 'Đang dùng model ' + (st.modelName || '') : 'Đang dùng luật xác định (không cần model, không phải AI sinh văn bản)';
      $('aiStatus').textContent = kindTxt + (st.nativeAvailable ? '' : ' · APK này không kèm llama.cpp') + (st.note ? ' — ' + st.note : '');
      $('aiSpace').textContent = 'Đã dùng ' + mb(cat.usedBytes) + ' · trống ' + mb(cat.freeBytes) + ' trong bộ nhớ app.';
      render(cat, st);
    } catch (e) { $('aiStatus').textContent = window.T2V_describeError(e); }
  }

  function render(cat, st) {
    const box = $('aiProfiles'); box.innerHTML = '';
    const mk = (lab, fn, cls) => { const b = el('button', cls || 'ghost', lab); b.onclick = fn; return b; };
    (cat.profiles || []).forEach(p => {
      const d = el('div', 'vl');
      const t = el('span', 't', p.label);
      let s = p.installed ? (p.verified ? 'Đã cài, SHA-256 đúng' : 'Đã cài (chưa xác minh)') : (p.partialBytes > 0 ? 'Đang dở ' + mb(p.partialBytes) : 'Chưa cài');
      if (p.loaded) s += ' · ĐANG NẠP';
      t.appendChild(el('em', p.installed ? 'ok' : '', s + ' · ' + p.license));
      if (p.note) t.appendChild(el('em', '', p.note));
      d.appendChild(t);
      if (!p.installed) {
        if (p.downloadable) d.appendChild(mk(p.partialBytes > 0 ? 'Tiếp tục tải' : 'Tải', () => download(p), 'pri'));
      } else {
        d.appendChild(p.loaded ? mk('Giải phóng', () => act('ai.unload', {})) : mk('Nạp', () => act('ai.load', { fileName: p.fileName }), 'pri'));
        d.appendChild(mk('Xóa', () => del(p.fileName)));
      }
      box.appendChild(d);
    });
    // file nhập tay không thuộc danh mục
    const known = new Set((cat.profiles || []).map(p => p.fileName));
    (cat.installed || []).filter(m => !known.has(m.fileName)).forEach(m => {
      const d = el('div', 'vl');
      const t = el('span', 't', m.fileName); t.appendChild(el('em', m.verified ? 'ok' : 'warn', mb(m.sizeBytes) + (m.verified ? ' · SHA-256 đúng' : ' · chưa xác minh SHA-256') + (m.loaded ? ' · ĐANG NẠP' : '')));
      d.appendChild(t);
      d.appendChild(m.loaded ? mk('Giải phóng', () => act('ai.unload', {})) : mk('Nạp', () => act('ai.load', { fileName: m.fileName }), 'pri'));
      d.appendChild(mk('Xóa', () => del(m.fileName)));
      box.appendChild(d);
    });
  }

  async function act(name, args) {
    if (working) return;
    working = true;
    try { await B.call(name, args); await refresh(); toast(name === 'ai.load' ? 'Đã nạp model' : 'Xong'); }
    catch (e) { toast(window.T2V_describeError(e)); }
    finally { working = false; }
  }
  async function download(p) {
    if (working) return;
    if (p.approxBytes && state && state.freeBytes && p.approxBytes > state.freeBytes) { toast('Không đủ dung lượng trống để tải model này'); return; }
    working = true; $('aiProg').textContent = 'Đang tải ' + p.fileName + '…';
    try { await B.call('model.download', { id: p.id }); $('aiProg').textContent = 'Tải xong và đã kiểm SHA-256.'; await refresh(); }
    catch (e) { $('aiProg').textContent = window.T2V_describeError(e); }
    finally { working = false; bar(0, 0); }
  }
  async function del(fileName) {
    if (!confirm('Xóa model ' + fileName + ' khỏi máy?')) return;
    await act('model.delete', { fileName });
  }

  B.on('model.progress', p => {
    if (!p) return;
    bar(p.done, p.total);
    $('aiProg').textContent = (p.phase === 'import' ? 'Đang nhập ' : p.phase === 'verify' ? 'Đang kiểm SHA-256 ' : 'Đang tải ') + p.fileName + ': ' + mb(p.done) + (p.total > 0 ? ' / ' + mb(p.total) : '');
  });
  B.on('model.done', p => {
    bar(0, 0);
    if (p && p.ok) { $('aiProg').textContent = 'Đã nhập ' + p.fileName + '.'; toast('Đã nhập model'); }
    else $('aiProg').textContent = window.T2V_describeError(p && p.error);
    refresh();
  });

  function init() {
    $('btnAiImport').onclick = async () => {
      const sha = $('aiSha').value.trim().toLowerCase();
      if (sha && !/^[0-9a-f]{64}$/.test(sha)) { toast('SHA-256 phải gồm 64 ký tự hex'); return; }
      try { await B.call('model.import', { sha256: sha }); } catch (e) { toast(window.T2V_describeError(e)); }
    };
    $('btnAiCancel').onclick = () => { B.call('model.cancel', {}).catch(() => {}); };
    $('aiModelBox').addEventListener('toggle', () => { if ($('aiModelBox').open) refresh(); });
  }
  init();
  window.T2V_AI = { refresh };
})();
