'use strict';
/*
 * Cầu nối bất đồng bộ JS <-> Kotlin cho các tính năng mới (Threads API, AI cục bộ, model, project, card).
 * Khớp với MainActivity.Bridge.call / NativeApi.submit / bridge/NativeDispatcher.kt.
 *
 *   T2V_BRIDGE.call('research.run', {...}) -> Promise (lỗi: object {code, message, ...})
 *   T2V_BRIDGE.on('research.progress', fn)  <- sự kiện Kotlin đẩy lên
 *
 * Các cầu nối cũ (beginSave/writeChunk/endSave/share/openStudio) vẫn dùng trực tiếp trong app.js.
 * Không có hàm nào ở đây đọc DOM/cookie của Threads: dữ liệu Threads chỉ đến từ API chính thức qua Kotlin.
 */
(function () {
  let seq = 0;
  const pend = new Map();
  const subs = new Map();
  const hasNative = () => !!(window.Android && typeof window.Android.call !== 'undefined');

  window.__native = (id, ok, json) => {
    const p = pend.get(id);
    if (!p) return false;
    pend.delete(id);
    let v;
    try { v = JSON.parse(json); } catch (e) { p.reject({ code: 'bad_response', message: 'Phản hồi từ ứng dụng không đọc được.' }); return true; }
    if (ok) p.resolve(v); else p.reject(v && typeof v === 'object' ? v : { code: 'internal', message: String(v) });
    return true;
  };

  window.__nativeEvent = (name, json) => {
    let v = null;
    try { v = JSON.parse(json); } catch (e) { /* bỏ qua */ }
    (subs.get(name) || []).slice().forEach(fn => { try { fn(v); } catch (e) { /* một listener lỗi không làm hỏng listener khác */ } });
    return true;
  };

  function call(name, args) {
    if (!hasNative()) {
      return Promise.reject({ code: 'no_native', message: 'Tính năng này chỉ chạy trong app Android.' });
    }
    return new Promise((resolve, reject) => {
      const id = 'c' + (++seq);
      pend.set(id, { resolve, reject });
      try { window.Android.call(id, name, JSON.stringify(args || {})); }
      catch (e) { pend.delete(id); reject({ code: 'bridge', message: 'Không gọi được ứng dụng: ' + e }); }
    });
  }

  function on(name, fn) {
    if (!subs.has(name)) subs.set(name, []);
    subs.get(name).push(fn);
    return () => { const a = subs.get(name) || []; const i = a.indexOf(fn); if (i >= 0) a.splice(i, 1); };
  }

  /** Trả RAM (model AI) trước khi dựng/export video. Không ném lỗi. */
  async function releaseForExport() {
    if (!hasNative()) return;
    try { await call('export.prepare', {}); } catch (e) { /* không chặn việc dựng video */ }
  }

  window.T2V_BRIDGE = { available: hasNative, call, on, releaseForExport };
})();
