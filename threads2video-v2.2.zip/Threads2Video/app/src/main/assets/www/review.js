'use strict';
/*
 * Sau Checkpoint 1: tạo bản đọc (ttsText) + một thẻ PNG riêng cho mỗi mục, rồi Checkpoint 2 (duyệt từng mục).
 *
 * Bất biến dữ liệu (kiểm thử trong tests/e2e):
 *  - item.rawText KHÔNG BAO GIỜ bị ghi đè: chuẩn hóa chỉ ghi vào item.ttsText.
 *  - Sửa ttsText KHÔNG đổi ảnh thẻ. Đổi chữ HIỂN THỊ trên thẻ là thao tác riêng (item.cardText) và bắt duyệt lại.
 *  - Chỉ mục có approvedForVideo=true mới được đưa sang timeline (window.__t2v.useApproved).
 *  - Thẻ lỗi hiện lỗi đúng thẻ và cho thử lại; không thay bằng ảnh giả.
 */
(function () {
  const $ = id => document.getElementById(id);
  const B = window.T2V_BRIDGE;
  const P = window.T2V_P;
  const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  const stripEmoji = s => String(s || '').replace(/[\p{Extended_Pictographic}‍️]/gu, '').replace(/\s+/g, ' ').trim();
  const persist = () => window.T2V_persist && window.T2V_persist();
  let busy = false;
  const openCardEdit = new Set();

  /* ---------- đồng bộ danh sách mục với lựa chọn đã xác nhận ---------- */
  function newItem(kind, rec) {
    return {
      kind, id: rec.id, rawText: rec.rawText, authorUsername: rec.authorUsername || null,
      likeCount: typeof rec.likeCount === 'number' ? rec.likeCount : null,
      ttsText: null, needsManualReview: false, flags: [], engine: null,
      cardUri: null, cardVer: 0, cardText: null, cardError: null, cardOverflow: false,
      approvedForVideo: false
    };
  }

  function syncItems() {
    const wanted = [];
    if (P.source) wanted.push({ kind: 'post', rec: P.source });
    P.selectedIds.forEach(id => { const c = window.T2V_RS.byId(id); if (c) wanted.push({ kind: 'comment', rec: c }); });
    const old = new Map((P.items || []).map(i => [i.id, i]));
    const next = wanted.map(w => {
      const prev = old.get(w.rec.id);
      // giữ thẻ/bản đọc/duyệt theo ID khi rawText không đổi; sắp xếp lại không làm đảo ảnh
      if (prev && prev.rawText === w.rec.rawText) { prev.kind = w.kind; return prev; }
      return newItem(w.kind, w.rec);
    });
    const keep = new Set(next.map(i => i.id));
    (P.items || []).filter(i => !keep.has(i.id)).forEach(i => { if (B.available()) B.call('card.delete', { commentId: i.id }).catch(() => {}); });
    P.items = next;
  }

  /* ---------- tạo bản đọc + thẻ ---------- */
  function setProg(msg, cls) { const p = $('cp2Prog'); p.textContent = msg || ''; p.className = 'hint' + (cls ? ' ' + cls : ''); }

  async function normalizeMissing() {
    const need = P.items.filter(i => i.ttsText == null);
    if (!need.length) return;
    setProg('Đang chuẩn hóa bản đọc bằng AI trên máy…');
    const out = await B.call('tts.normalize', { items: need.map(i => ({ id: i.id, rawText: i.rawText })) });
    const m = new Map((out || []).map(o => [o.id, o]));
    need.forEach(i => {
      const o = m.get(i.id);
      if (!o) { i.ttsText = ''; i.needsManualReview = true; i.flags = ['Không có kết quả chuẩn hóa — hãy tự nhập bản đọc']; return; }
      i.ttsText = stripEmoji(o.ttsText);          // chỉ ghi vào ttsText; rawText giữ nguyên
      i.flags = o.flags || [];
      i.needsManualReview = !!o.needsManualReview || !i.ttsText;
      i.engine = o.engine || null;
    });
  }

  async function renderCard(item) {
    try {
      const rec = window.T2V_CARDS.render({
        text: item.cardText != null ? item.cardText : item.rawText,
        username: item.authorUsername, likeCount: item.likeCount,
        showUsername: P.cardOpts.showUsername, showLikes: P.cardOpts.showLikes
      });
      const b64 = await window.T2V_CARDS.toPngBase64(rec.canvas);
      const r = await B.call('card.save', { commentId: item.id, pngBase64: b64 });
      item.cardUri = r.uri; item.cardVer = (item.cardVer || 0) + 1; item.cardError = null; item.cardOverflow = rec.overflow;
      item.approvedForVideo = false;               // ảnh mới ⇒ phải duyệt lại
    } catch (e) {
      item.cardUri = null; item.cardError = (e && e.message) || 'Không dựng được thẻ';
    }
  }

  async function start(resume) {
    if (busy) return;
    if (!B.available()) { setProg('Cần chạy trong app Android để tạo thẻ và bản đọc.', 'err'); return; }
    busy = true; P.stage = 'cards'; syncItems(); render();
    try {
      await normalizeMissing(); persist(); render();
      const todo = P.items.filter(i => !i.cardUri);
      for (let k = 0; k < todo.length; k++) {
        setProg('Đang dựng thẻ ' + (k + 1) + '/' + todo.length + '…');
        await renderCard(todo[k]); render();
      }
      P.stage = 'cp2'; persist();
      const bad = P.items.filter(i => i.cardError).length;
      setProg(bad ? bad + ' thẻ lỗi — bấm “Thử lại” ở thẻ đó.' : 'Xong. Hãy xem từng thẻ và bản đọc rồi bấm Duyệt.', bad ? 'warn' : 'ok');
    } catch (e) {
      P.stage = 'cp1'; setProg(window.T2V_describeError(e), 'err');
    } finally { busy = false; render(); }
  }

  /* ---------- Checkpoint 2 ---------- */
  function canApprove(i) { return !i.cardError && !!i.cardUri && !!(i.ttsText || '').trim(); }

  function itemView(i, n) {
    const d = el('div', 'it' + (i.approvedForVideo ? ' ok' : '') + (i.needsManualReview && !i.approvedForVideo ? ' review' : ''));
    const h = el('div', 'ith');
    h.appendChild(el('b', '', i.kind === 'post' ? 'Bài gốc' : 'Bình luận ' + n));
    if (i.approvedForVideo) h.appendChild(el('span', 'tag ok', 'Đã duyệt'));
    else if (i.needsManualReview) h.appendChild(el('span', 'tag warn', 'Cần xem lại'));
    if (i.cardText != null) h.appendChild(el('span', 'tag warn', 'Chữ thẻ đã sửa'));
    d.appendChild(h);

    if (i.cardError) {
      d.appendChild(el('div', 'notice warn', 'Lỗi dựng thẻ: ' + i.cardError));
      const rb = el('button', 'pri', 'Thử lại'); rb.onclick = async () => { await renderCard(i); persist(); render(); }; d.appendChild(rb);
    } else if (i.cardUri) {
      const im = el('img', 'cardprev'); im.alt = 'Thẻ ' + (i.kind === 'post' ? 'bài gốc' : 'bình luận ' + n); im.src = i.cardUri; d.appendChild(im);
      if (i.cardOverflow) d.appendChild(el('div', 'hint warn', 'Văn bản dài: thẻ cao hơn khung, video sẽ cuộn thẻ theo giọng đọc.'));
    } else d.appendChild(el('div', 'hint', 'Đang chờ dựng thẻ…'));

    d.appendChild(el('label', 'l', 'Nguyên bản (chỉ đọc, không bị sửa)'));
    d.appendChild(el('div', 'raw', i.rawText));
    d.appendChild(el('label', 'l', 'Bản đọc thành tiếng (sửa được — không đổi ảnh thẻ)'));
    const ta = el('textarea', 'tts'); ta.value = i.ttsText || ''; ta.rows = 3;
    ta.oninput = () => {
      i.ttsText = ta.value;
      if (i.approvedForVideo) { i.approvedForVideo = false; d.classList.remove('ok'); updateSummary(); }
      persist();
    };
    d.appendChild(ta);
    (i.flags || []).forEach(f => d.appendChild(el('div', 'hint warn', '⚠ ' + f)));
    if (i.engine) d.appendChild(el('div', 'hint', 'Chuẩn hóa bằng: ' + (i.engine === 'rules' ? 'luật xác định (không phải model AI)' : i.engine)));

    const row = el('div', 'btns3');
    const ap = el('button', i.approvedForVideo ? 'ghost' : 'pri', i.approvedForVideo ? 'Bỏ duyệt' : 'Duyệt');
    ap.onclick = () => {
      if (!i.approvedForVideo && !canApprove(i)) { toast(i.cardError ? 'Thẻ đang lỗi, hãy thử lại' : 'Bản đọc đang trống, hãy nhập bản đọc'); return; }
      i.approvedForVideo = !i.approvedForVideo; persist(); render();
    };
    row.appendChild(ap);
    const rd = el('button', 'ghost', 'Dựng lại thẻ'); rd.onclick = async () => { await renderCard(i); persist(); render(); }; row.appendChild(rd);
    const ce = el('button', 'ghost', 'Sửa chữ trên thẻ');
    ce.onclick = () => { if (openCardEdit.has(i.id)) openCardEdit.delete(i.id); else openCardEdit.add(i.id); render(); };
    row.appendChild(ce);
    d.appendChild(row);

    if (openCardEdit.has(i.id)) {
      const w = el('div', 'cardedit');
      w.appendChild(el('div', 'hint', 'Chỉ đổi chữ HIỂN THỊ trên ảnh; nguyên bản vẫn giữ nguyên. Sau khi áp dụng bạn phải duyệt lại.'));
      const t2 = el('textarea'); t2.value = i.cardText != null ? i.cardText : i.rawText; t2.rows = 4; w.appendChild(t2);
      const r2 = el('div', 'btns3');
      const ok = el('button', 'pri', 'Áp dụng'); ok.onclick = async () => {
        const v = t2.value.trim();
        if (!v) { toast('Chữ trên thẻ không được để trống'); return; }
        i.cardText = (v === i.rawText) ? null : v;
        openCardEdit.delete(i.id); await renderCard(i); persist(); render();
      };
      const rv = el('button', 'ghost', 'Hoàn nguyên'); rv.onclick = async () => { i.cardText = null; openCardEdit.delete(i.id); await renderCard(i); persist(); render(); };
      r2.appendChild(ok); r2.appendChild(rv); w.appendChild(r2); d.appendChild(w);
    }
    return d;
  }

  function updateSummary() {
    const total = P.items.length, ok = P.items.filter(i => i.approvedForVideo).length;
    const postOk = P.items.length && P.items[0].kind === 'post' && P.items[0].approvedForVideo;
    const review = P.items.filter(i => i.needsManualReview && !i.approvedForVideo).length;
    $('cp2Sum').textContent = 'Đã duyệt ' + ok + '/' + total + (review ? ' · ' + review + ' mục cần xem lại' : '') + (postOk ? '' : ' · cần duyệt bài gốc');
    $('btnSend').disabled = busy || !postOk;
    $('btnSend').textContent = 'Gửi ' + ok + ' mục đã duyệt sang video';
    $('btnApproveAll').disabled = busy;
  }

  function render() {
    const show = !!P.source && P.cp1Confirmed && (P.stage === 'cards' || P.stage === 'cp2');
    $('cp2Box').hidden = !show;
    if (!show) return;
    const list = $('cp2List'); list.innerHTML = '';
    let n = 0;
    P.items.forEach(i => { if (i.kind === 'comment') n++; list.appendChild(itemView(i, n)); });
    updateSummary();
  }

  function approveAll() {
    let skipped = 0;
    P.items.forEach(i => {
      if (i.approvedForVideo) return;
      if (!canApprove(i) || i.needsManualReview) { skipped++; return; }
      i.approvedForVideo = true;
    });
    persist(); render();
    toast(skipped ? 'Còn ' + skipped + ' mục cần xem lại hoặc đang lỗi, hãy duyệt riêng' : 'Đã duyệt tất cả');
  }

  async function rebuildAll() {
    if (busy) return;
    busy = true; render();
    try {
      for (let k = 0; k < P.items.length; k++) { setProg('Đang dựng lại thẻ ' + (k + 1) + '/' + P.items.length + '…'); await renderCard(P.items[k]); render(); }
      persist(); setProg('Đã dựng lại thẻ. Hãy duyệt lại.', 'ok');
    } finally { busy = false; render(); }
  }

  async function send() {
    const ok = P.items.filter(i => i.approvedForVideo);
    if (!ok.length || ok[0].kind !== 'post') { toast('Cần duyệt bài gốc trước'); return; }
    if (ok.some(i => !canApprove(i))) { toast('Có mục đã duyệt nhưng thiếu thẻ hoặc bản đọc'); return; }
    $('btnSend').disabled = true;
    try {
      const list = [];
      for (const i of ok) {
        const proc = await window.T2V_CARDS.loadImage(i.cardUri);
        list.push({ type: i.kind, id: i.id, rawText: i.rawText, ttsText: i.ttsText, img: { id: 'api:' + i.id, ver: i.cardVer || 1, proc } });
      }
      window.__t2v.useApproved(list);
      toast('Đã gửi ' + list.length + ' mục sang video');
      go(2);
    } catch (e) { toast(e.message || 'Không nạp được thẻ'); }
    finally { updateSummary(); }
  }

  function init() {
    $('btnApproveAll').onclick = approveAll;
    $('btnRebuild').onclick = rebuildAll;
    $('btnSend').onclick = send;
    $('btnBack1').onclick = () => { P.stage = 'cp1'; persist(); render(); window.T2V_RS.renderAll(); $('cp1Box').scrollIntoView(); };
  }

  window.T2V_review = { start, render, syncItems };
  init();
})();
