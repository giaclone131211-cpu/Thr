package com.threads2video.data.threads

import com.threads2video.core.Json
import com.threads2video.core.long
import com.threads2video.core.str
import java.io.IOException
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

data class StoredToken(
    val token: String,
    val expiresAtMs: Long?,
    val obtainedAtMs: Long,
    val userId: String?,
    val username: String?,
    /** "oauth" (qua backend) hoặc "manual" (người dùng dán token) */
    val source: String
)

interface TokenStore {
    fun load(): StoredToken?
    fun save(t: StoredToken)
    fun clear()
}

/** Cấu hình KHÔNG bí mật: App ID công khai của Meta app và URL backend đổi token. */
data class ThreadsConfig(val appId: String, val brokerUrl: String) {
    val configured: Boolean get() = appId.isNotBlank() && brokerUrl.startsWith("https://")
}

interface ConfigStore {
    fun load(): ThreadsConfig
    fun save(c: ThreadsConfig)
}

/** Trạng thái OAuth đang chờ (state + verifier) để chống CSRF và chống app khác chặn deep link. */
interface PendingStore {
    fun put(state: String, verifier: String, createdAtMs: Long)
    /** Lấy và xóa (dùng một lần). */
    fun take(): Triple<String, String, Long>?
}

/**
 * Luồng OAuth chính thức của Threads CÓ backend đổi token (xem backend/token-broker và README):
 *
 *  1. App mở https://threads.com/oauth/authorize?client_id&redirect_uri=<broker>/threads/callback&scope&response_type=code&state
 *  2. Meta chuyển về backend (HTTPS) kèm `code`. Backend giữ `client_secret`, đổi code → token ngắn hạn → token dài hạn.
 *     Meta BẮT BUỘC client_secret cho cả hai bước và cấm đặt secret ở client ⇒ không có cách đổi token an toàn chỉ bằng APK.
 *  3. Backend mở lại app bằng threads2video://oauth?ticket=…&state=… (vé dùng một lần, hết hạn nhanh).
 *  4. App kiểm tra state, rồi POST {ticket, verifier} tới backend để nhận token. `verifier` chỉ app biết
 *     (state chứa sha256(verifier)), nên app khác chặn được deep link cũng không đổi được vé.
 */
class ThreadsOAuth(
    private val config: ConfigStore,
    private val tokens: TokenStore,
    private val pending: PendingStore,
    private val transport: HttpTransport = UrlConnectionTransport(),
    private val now: () -> Long = { System.currentTimeMillis() },
    private val random: SecureRandom = SecureRandom(),
    private val graphHost: String = "https://graph.threads.com"
) {
    companion object {
        const val AUTHORIZE_URL = "https://threads.com/oauth/authorize"
        /** threads_keyword_search chưa có trong danh sách scope ở trang token của Meta (chỉ ở trang keyword-search): chủ app cần đối chiếu. */
        const val SCOPES = "threads_basic,threads_read_replies,threads_keyword_search"
        const val STATE_TTL_MS = 10 * 60 * 1000L
        const val REFRESH_WINDOW_MS = 7L * 24 * 3600 * 1000
        const val MIN_TOKEN_AGE_MS = 24L * 3600 * 1000
        const val TIMEOUT_MS = 20000

        fun sha256Base64Url(s: String): String {
            val d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
            return Base64.getUrlEncoder().withoutPadding().encodeToString(d)
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun redirectUri(c: ThreadsConfig = config.load()): String = c.brokerUrl.trimEnd('/') + "/threads/callback"

    /** Tạo URL cấp quyền và ghi nhận state đang chờ. */
    fun beginAuthorization(): String {
        val c = config.load()
        if (!c.configured) {
            throw ThreadsError.NotConfigured(
                "Chưa cấu hình Threads App ID và địa chỉ backend đổi token (HTTPS). Xem README mục “Cấu hình Meta Developer App”."
            )
        }
        val nonce = randomHex(16)
        val verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(ByteArray(32).also { random.nextBytes(it) })
        val state = nonce + "." + sha256Base64Url(verifier)
        pending.put(state, verifier, now())
        return AUTHORIZE_URL +
            "?client_id=" + enc(c.appId.trim()) +
            "&redirect_uri=" + enc(redirectUri(c)) +
            "&scope=" + enc(SCOPES) +
            "&response_type=code" +
            "&state=" + enc(state)
    }

    /** Xử lý tham số trả về trên deep link threads2video://oauth?… Ném ThreadsError khi thất bại. */
    fun handleCallback(params: Map<String, String>): StoredToken {
        val (state, verifier, createdAt) = pending.take()
            ?: throw ThreadsError.NotAuthorized("Không có phiên đăng nhập nào đang chờ. Hãy bấm đăng nhập lại.")
        if (now() - createdAt > STATE_TTL_MS) throw ThreadsError.NotAuthorized("Phiên đăng nhập đã quá hạn. Hãy đăng nhập lại.")
        if (params["state"] != state) {
            throw ThreadsError.NotAuthorized("Dữ liệu trả về không khớp phiên đăng nhập (state). Đã hủy để an toàn.")
        }
        val err = params["error"]
        if (!err.isNullOrEmpty()) {
            if (err == "access_denied") throw ThreadsError.ConsentDenied()
            throw ThreadsError.NotAuthorized("Đăng nhập Threads thất bại (" + err.take(40).filter { it.isLetterOrDigit() || it == '_' } + ").")
        }
        val ticket = params["ticket"]
        if (ticket.isNullOrEmpty()) throw ThreadsError.NotAuthorized("Backend không trả về vé đăng nhập.")
        val c = config.load()
        val body = Json.stringify(mapOf("ticket" to ticket, "verifier" to verifier))
        val res = try {
            transport.postJson(c.brokerUrl.trimEnd('/') + "/threads/redeem", body, TIMEOUT_MS)
        } catch (e: IOException) {
            throw ThreadsError.Network("Không kết nối được backend đăng nhập. Kiểm tra mạng và địa chỉ backend.")
        }
        if (res.status !in 200..299) throw ThreadsError.NotAuthorized("Backend từ chối đổi vé đăng nhập (HTTP ${res.status}).")
        val o = try { Json.parseObject(res.body) } catch (e: Exception) {
            throw ThreadsError.BadResponse("Phản hồi từ backend không đọc được.")
        }
        val token = o.str("access_token") ?: throw ThreadsError.NotAuthorized("Backend không trả về access_token.")
        val exp = o.long("expires_in") ?: 0L
        val t = StoredToken(token, if (exp > 0) now() + exp * 1000 else null, now(), o.str("user_id"), null, "oauth")
        tokens.save(t)
        return t
    }

    /** Đường dự phòng không cần backend: người dùng dán access token tự tạo trong App Dashboard. */
    fun saveManualToken(token: String, expiresInSec: Long?): StoredToken {
        val tk = token.trim()
        if (tk.length < 20 || tk.any { it.isWhitespace() }) throw ThreadsError.NotAuthorized("Access token không hợp lệ.")
        val t = StoredToken(tk, expiresInSec?.takeIf { it > 0 }?.let { now() + it * 1000 }, now(), null, null, "manual")
        tokens.save(t)
        return t
    }

    fun setUsername(username: String?, userId: String?) {
        val cur = tokens.load() ?: return
        tokens.save(cur.copy(username = username ?: cur.username, userId = userId ?: cur.userId))
    }

    /** Token còn dùng được hay null. Không tự gia hạn (xem [freshToken]). */
    fun currentToken(): String? {
        val t = tokens.load() ?: return null
        val exp = t.expiresAtMs
        if (exp != null && now() >= exp) return null
        return t.token
    }

    /**
     * Trả token dùng được; gia hạn khi gần hết hạn (refresh không cần client_secret theo tài liệu Meta,
     * nhưng token phải ≥ 24 giờ tuổi và chưa hết hạn). Hết hạn → xóa token và ném NotAuthorized.
     */
    fun freshToken(): String {
        val t = tokens.load() ?: throw ThreadsError.NotAuthorized("Chưa đăng nhập Threads.")
        val exp = t.expiresAtMs
        if (exp != null && now() >= exp) {
            tokens.clear()
            throw ThreadsError.NotAuthorized("Phiên đăng nhập Threads đã hết hạn. Hãy đăng nhập lại.")
        }
        if (exp != null && exp - now() < REFRESH_WINDOW_MS && now() - t.obtainedAtMs > MIN_TOKEN_AGE_MS) {
            try {
                refresh(t)
            } catch (e: ThreadsError.NotAuthorized) {
                tokens.clear(); throw e
            } catch (e: ThreadsError) {
                // lỗi mạng/khác khi gia hạn: vẫn dùng token hiện tại, lần sau thử lại
            }
        }
        return tokens.load()?.token ?: throw ThreadsError.NotAuthorized("Chưa đăng nhập Threads.")
    }

    private fun refresh(t: StoredToken) {
        val url = "$graphHost/refresh_access_token?grant_type=th_refresh_token&access_token=" + enc(t.token)
        val r = try { transport.get(url, TIMEOUT_MS) } catch (e: IOException) { throw ThreadsError.Network("Không gia hạn được token (mạng).") }
        if (r.status == 400 || r.status == 401 || r.status == 403) throw ThreadsError.NotAuthorized("Token không còn gia hạn được. Hãy đăng nhập lại.")
        if (r.status !in 200..299) throw ThreadsError.BadResponse("Gia hạn token thất bại (HTTP ${r.status}).")
        val o = try { Json.parseObject(r.body) } catch (e: Exception) { throw ThreadsError.BadResponse("Phản hồi gia hạn không đọc được.") }
        val nt = o.str("access_token") ?: throw ThreadsError.BadResponse("Phản hồi gia hạn thiếu access_token.")
        val sec = o.long("expires_in") ?: 0L
        tokens.save(t.copy(token = nt, obtainedAtMs = now(), expiresAtMs = if (sec > 0) now() + sec * 1000 else t.expiresAtMs))
    }

    fun logout() {
        tokens.clear()
        pending.take()
    }

    private fun randomHex(bytes: Int): String {
        val b = ByteArray(bytes)
        random.nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }
}
