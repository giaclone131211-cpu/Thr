package com.threads2video.bridge

import com.threads2video.ai.AiCancelled
import com.threads2video.ai.AiService
import com.threads2video.ai.AiUnavailable
import com.threads2video.ai.CancelToken
import com.threads2video.ai.Criteria
import com.threads2video.ai.LocalModelManager
import com.threads2video.ai.ModelCatalog
import com.threads2video.ai.ModelError
import com.threads2video.ai.RankRequest
import com.threads2video.ai.TtsInput
import com.threads2video.core.Json
import com.threads2video.core.bool
import com.threads2video.core.long
import com.threads2video.core.str
import com.threads2video.data.CommentRecord
import com.threads2video.data.PostRecord
import com.threads2video.data.local.CardStore
import com.threads2video.data.local.ProjectStore
import com.threads2video.data.threads.Notice
import com.threads2video.data.threads.ThreadsConfig
import com.threads2video.data.threads.ThreadsDataSource
import com.threads2video.data.threads.ThreadsError
import com.threads2video.data.threads.ThreadsOAuth
import com.threads2video.workflow.ResearchOptions
import com.threads2video.workflow.ResearchResult
import com.threads2video.workflow.ResearchWorkflow
import com.threads2video.workflow.SourceResult
import java.io.InputStream
import java.util.Base64

/** Phần phụ thuộc Android, được hiện thực ở lớp Android (xem NativeApi.kt) và bản giả khi test. */
interface Platform {
    fun sysInfo(): Map<String, Any?>
    fun availMemBytes(): Long
    fun freeDiskBytes(): Long
    /** Mở trình duyệt hệ thống tới URL (đăng nhập Threads). */
    fun openBrowser(url: String)
    /** Mở bộ chọn file .gguf; kết quả quay lại qua [NativeDispatcher.importModel]. */
    fun pickModelFile()
    /** URL để WebView tải ảnh card đã lưu. */
    fun cardUri(commentId: String, version: Long): String
}

/** Lỗi của yêu cầu cầu nối (tham số sai…). */
class BridgeError(val code: String, message: String) : Exception(message)

/**
 * Điểm vào DUY NHẤT cho mọi lệnh JS → Kotlin: dispatch(name, args) → giá trị JSON-hóa được (Map/List/số/chuỗi/bool/null).
 * Thuần JVM để kiểm thử được mà không cần Android. Mọi lệnh chạy ở luồng nền (do lớp Android quản lý).
 * Không có lệnh nào đọc DOM/cookie/trang Threads: dữ liệu Threads chỉ đi qua [ThreadsDataSource] (API chính thức).
 */
class NativeDispatcher(
    private val platform: Platform,
    private val oauth: ThreadsOAuth,
    private val configStore: com.threads2video.data.threads.ConfigStore,
    private val tokenStore: com.threads2video.data.threads.TokenStore,
    private val data: ThreadsDataSource,
    private val ai: AiService,
    private val models: LocalModelManager,
    private val projects: ProjectStore,
    private val cards: CardStore,
    private val emit: (event: String, payload: Map<String, Any?>) -> Unit
) {
    private val workflow = ResearchWorkflow(data, ai.engine)
    @Volatile private var opCancel = CancelToken()
    @Volatile private var modelCancel = CancelToken()
    @Volatile private var pendingImportSha: String? = null

    private fun newOp(): CancelToken { val c = CancelToken(); opCancel = c; return c }

    // ---------- lỗi → JSON ----------
    fun errorMap(e: Throwable): Map<String, Any?> = when (e) {
        is ThreadsError.PermissionDenied -> linkedMapOf("code" to e.code, "message" to e.message, "permission" to e.permission)
        is ThreadsError.RateLimited -> linkedMapOf("code" to e.code, "message" to e.message, "retryAfterSec" to e.retryAfterSec)
        is ThreadsError -> linkedMapOf("code" to e.code, "message" to e.message)
        is AiCancelled -> linkedMapOf("code" to "cancelled", "message" to "Đã hủy")
        is AiUnavailable -> linkedMapOf("code" to "ai_unavailable", "message" to e.message)
        is ModelError -> linkedMapOf("code" to "model_" + e.code, "message" to e.message)
        is BridgeError -> linkedMapOf("code" to e.code, "message" to e.message)
        is IllegalArgumentException -> linkedMapOf("code" to "bad_request", "message" to (e.message ?: "Tham số không hợp lệ"))
        else -> linkedMapOf("code" to "internal", "message" to "Có lỗi không mong đợi. Hãy thử lại.")
    }

    // ---------- trạng thái đăng nhập ----------
    private fun authStatus(): Map<String, Any?> {
        val c = configStore.load()
        val t = tokenStore.load()
        val o = linkedMapOf<String, Any?>(
            "configured" to c.configured, "appId" to c.appId, "brokerUrl" to c.brokerUrl,
            "loggedIn" to (t != null && oauth.currentToken() != null)
        )
        if (t != null) {
            o["source"] = t.source
            o["username"] = t.username
            o["expiresAt"] = t.expiresAtMs
        }
        return o
    }

    /** Hoàn tất đăng nhập từ deep link threads2video://oauth?…; luôn đẩy sự kiện `auth.result` về JS. */
    fun finishAuth(params: Map<String, String>) {
        val payload: Map<String, Any?> = try {
            oauth.handleCallback(params)
            try { val me = data.me(); oauth.setUsername(me.username, me.id) } catch (_: ThreadsError) {}
            linkedMapOf("ok" to true, "status" to authStatus())
        } catch (e: Throwable) {
            linkedMapOf("ok" to false, "error" to errorMap(e))
        }
        emit("auth.result", payload)
    }

    // ---------- chuyển record <-> map ----------
    private fun postOf(a: Map<String, Any?>): PostRecord =
        PostRecord.fromMap(Json.asMap(a["post"]) ?: throw BridgeError("bad_request", "Thiếu post")) ?: throw BridgeError("bad_request", "post không hợp lệ")

    private fun commentsOf(a: Map<String, Any?>): List<CommentRecord> =
        (Json.asList(a["comments"]) ?: throw BridgeError("bad_request", "Thiếu comments"))
            .mapNotNull { Json.asMap(it) }.mapNotNull { CommentRecord.fromMap(it) }

    private fun noticeMap(n: Notice) = linkedMapOf<String, Any?>("code" to n.code, "message" to n.message)

    private fun sourceMap(s: SourceResult): Map<String, Any?> = linkedMapOf(
        "post" to s.source.toMap(),
        "comments" to s.comments.map { it.toMap() },
        "topIds" to s.topIds,
        "dropped" to s.dropped.map { linkedMapOf<String, Any?>("id" to it.id, "reason" to it.reason) },
        "notices" to s.notices.map { noticeMap(it) },
        "engine" to s.engine
    )

    private fun researchMap(r: ResearchResult): Map<String, Any?> = linkedMapOf(
        "topic" to r.topic,
        "candidates" to r.candidates.map { it.toMap() },
        "source" to r.source?.let { sourceMap(it) },
        "notices" to r.notices.map { noticeMap(it) },
        "me" to r.me?.let { linkedMapOf<String, Any?>("id" to it.id, "username" to it.username) },
        "queriesUsed" to r.queriesUsed,
        "engine" to ai.status()
    )

    private fun opts(a: Map<String, Any?>) = ResearchOptions(
        topic = a.str("topic") ?: "",
        criteria = Criteria.parse(a.str("criteria")),
        topN = (a.long("topN") ?: 8L).toInt().coerceIn(1, 20)
    )

    // ---------- model ----------
    private fun modelState(): Map<String, Any?> {
        val installed = models.installed()
        return linkedMapOf(
            "profiles" to ModelCatalog.PROFILES.map { p ->
                val inst = installed.firstOrNull { it.fileName == p.fileName }
                linkedMapOf<String, Any?>(
                    "id" to p.id, "label" to p.label, "fileName" to p.fileName, "approxBytes" to p.approxBytes,
                    "license" to p.license, "note" to p.note, "downloadable" to (p.url != null && p.sha256 != null),
                    "installed" to (inst != null), "verified" to (inst?.verified == true),
                    "partialBytes" to models.partialBytes(p.fileName), "loaded" to ai.isLoaded(p.fileName)
                )
            },
            "installed" to installed.map {
                linkedMapOf<String, Any?>("fileName" to it.fileName, "sizeBytes" to it.sizeBytes, "sha256" to it.sha256, "verified" to it.verified, "loaded" to ai.isLoaded(it.fileName))
            },
            "usedBytes" to installed.sumOf { it.sizeBytes },
            "freeBytes" to platform.freeDiskBytes()
        )
    }

    private fun progress(file: String, done: Long, total: Long, phase: String) =
        emit("model.progress", linkedMapOf("fileName" to file, "done" to done, "total" to total, "phase" to phase))

    /** Gọi từ Activity sau khi người dùng chọn file .gguf (SAF). Chạy ở luồng nền. */
    fun importModel(input: InputStream, fileName: String, totalBytes: Long) {
        val c = CancelToken(); modelCancel = c
        val sha = pendingImportSha; pendingImportSha = null
        try {
            val inst = models.import(input, fileName, totalBytes, sha, c) { d, t -> progress(fileName, d, t, "import") }
            emit("model.done", linkedMapOf("ok" to true, "fileName" to inst.fileName, "state" to modelState()))
        } catch (e: Throwable) {
            emit("model.done", linkedMapOf("ok" to false, "error" to errorMap(e), "state" to modelState()))
        }
    }

    // ---------- điều phối ----------
    fun dispatch(name: String, a: Map<String, Any?>): Any? = when (name) {
        // cấu hình & đăng nhập
        "config.get", "auth.status" -> authStatus()
        "config.set" -> {
            val appId = (a.str("appId") ?: "").trim()
            val broker = (a.str("brokerUrl") ?: "").trim()
            if (broker.isNotEmpty() && !broker.startsWith("https://")) throw BridgeError("bad_request", "Địa chỉ backend phải bắt đầu bằng https://")
            if (appId.isNotEmpty() && !Regex("^[0-9]{5,24}$").matches(appId)) throw BridgeError("bad_request", "Threads App ID chỉ gồm chữ số.")
            configStore.save(ThreadsConfig(appId, broker))
            authStatus()
        }
        "auth.begin" -> { val url = oauth.beginAuthorization(); platform.openBrowser(url); linkedMapOf("started" to true) }
        "auth.manualToken" -> {
            oauth.saveManualToken(a.str("token") ?: "", a.long("expiresInSec"))
            try { val me = data.me(); oauth.setUsername(me.username, me.id) } catch (e: ThreadsError) {
                oauth.logout() // token sai/thiếu quyền: không giữ token hỏng
                throw e
            }
            authStatus()
        }
        "auth.logout" -> { oauth.logout(); authStatus() }

        // research (chỉ API chính thức)
        "research.run" -> {
            val c = newOp()
            researchMap(workflow.research(opts(a), c) { m -> emit("research.progress", linkedMapOf("message" to m)) })
        }
        "research.source" -> {
            val c = newOp()
            val o = opts(a)
            sourceMap(workflow.loadSource(postOf(a), o.topic, o.criteria, o.topN, o.maxReplyPages, c))
        }
        // xếp hạng danh sách bất kỳ (API hoặc nhập thủ công); không gọi mạng
        "research.rank" -> {
            val c = newOp()
            val o = opts(a)
            val post = postOf(a)
            val rr = ai.engine.rankComments(RankRequest(o.topic, post.rawText, commentsOf(a), o.criteria, o.topN), c)
            linkedMapOf(
                "comments" to rr.ranked.map { it.toMap() }, "topIds" to rr.topIds,
                "dropped" to rr.dropped.map { linkedMapOf<String, Any?>("id" to it.id, "reason" to it.reason) }, "engine" to rr.engine
            )
        }
        "research.cancel", "ai.cancel" -> { opCancel.cancel(); linkedMapOf("ok" to true) }

        // chuẩn hóa TTS (rawText không bao giờ bị đổi: chỉ trả ttsText riêng)
        "tts.normalize" -> {
            val c = newOp()
            val items = (Json.asList(a["items"]) ?: throw BridgeError("bad_request", "Thiếu items")).mapNotNull { Json.asMap(it) }
                .map { TtsInput(it.str("id") ?: throw BridgeError("bad_request", "item thiếu id"), it.str("rawText") ?: "") }
            ai.engine.normalizeTts(items, c).map {
                linkedMapOf<String, Any?>("id" to it.id, "ttsText" to it.ttsText, "needsManualReview" to it.needsManualReview, "flags" to it.flags, "engine" to it.engine)
            }
        }
        "caption.make" -> {
            val c = newOp()
            val cm = (Json.asList(a["comments"]) ?: emptyList<Any?>()).mapNotNull { it as? String }
            linkedMapOf("text" to ai.engine.caption(a.str("postText") ?: "", cm, c), "engine" to ai.status())
        }

        // AI cục bộ & model
        "ai.status" -> ai.status()
        "ai.load" -> { ai.load(a.str("fileName") ?: throw BridgeError("bad_request", "Thiếu fileName")); ai.status() }
        "ai.unload", "ai.release" -> { ai.unload(); ai.status() }
        "model.catalog" -> modelState()
        "model.download" -> {
            val id = a.str("id") ?: throw BridgeError("bad_request", "Thiếu id model")
            val p = ModelCatalog.byId(id) ?: throw BridgeError("bad_request", "Model không có trong danh mục")
            val url = p.url
            val sha = p.sha256
            if (url == null || sha == null) throw BridgeError("bad_request", "Model này chưa có liên kết tải đã xác minh. Hãy dùng “Nhập file”.")
            val c = CancelToken(); modelCancel = c
            models.download(url, p.fileName, sha, c) { d, t -> progress(p.fileName, d, t, "download") }
            modelState()
        }
        "model.import" -> { pendingImportSha = a.str("sha256")?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }; platform.pickModelFile(); linkedMapOf("started" to true) }
        "model.cancel" -> { modelCancel.cancel(); linkedMapOf("ok" to true) }
        "model.delete" -> {
            val f = a.str("fileName") ?: throw BridgeError("bad_request", "Thiếu fileName")
            if (ai.isLoaded(f)) ai.unload()
            models.delete(f)
            modelState()
        }

        // project + card
        "project.list" -> projects.list()
        "project.load" -> linkedMapOf("json" to projects.load(a.str("id") ?: throw BridgeError("bad_request", "Thiếu id")))
        "project.save" -> { projects.save(a.str("id") ?: throw BridgeError("bad_request", "Thiếu id"), a.str("json") ?: throw BridgeError("bad_request", "Thiếu json")); linkedMapOf("ok" to true) }
        "project.delete" -> { projects.delete(a.str("id") ?: ""); linkedMapOf("ok" to true) }
        "project.deleteAll" -> { projects.deleteAll(); cards.deleteAll(); linkedMapOf("ok" to true) }
        "card.save" -> {
            val id = a.str("commentId") ?: throw BridgeError("bad_request", "Thiếu commentId")
            val png = try { Base64.getDecoder().decode((a.str("pngBase64") ?: "").substringAfter("base64,")) }
            catch (e: IllegalArgumentException) { throw BridgeError("bad_request", "Ảnh thẻ không giải mã được.") }
            val f = cards.save(id, png)
            linkedMapOf("uri" to platform.cardUri(id, f.lastModified()), "bytes" to png.size)
        }
        "card.delete" -> { cards.delete(a.str("commentId") ?: ""); linkedMapOf("ok" to true) }

        // xuất video: trả RAM trước khi dựng
        "export.prepare" -> { ai.releaseForExport(); linkedMapOf("ok" to true, "ai" to ai.status()) }
        "sys.info" -> platform.sysInfo()
        else -> throw BridgeError("bad_request", "Lệnh không hợp lệ: $name")
    }

    /** Chạy dispatch và trả (ok, json) — dùng chung cho lớp Android và test. */
    fun invoke(name: String, argsJson: String): Pair<Boolean, String> = try {
        val args = if (argsJson.isBlank()) emptyMap() else Json.parseObject(argsJson)
        true to Json.stringify(dispatch(name, args))
    } catch (e: Throwable) {
        false to Json.stringify(errorMap(e))
    }
}
