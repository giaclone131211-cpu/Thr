package com.threads2video.data.threads

import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException

data class HttpResult(val status: Int, val body: String, val retryAfterSec: Int? = null)

/** Tách tầng mạng để test bằng transport giả. KHÔNG được log URL (chứa access_token). */
interface HttpTransport {
    @Throws(IOException::class)
    fun get(url: String, timeoutMs: Int): HttpResult

    @Throws(IOException::class)
    fun postJson(url: String, json: String, timeoutMs: Int): HttpResult
}

class UrlConnectionTransport : HttpTransport {
    override fun get(url: String, timeoutMs: Int): HttpResult = exec(url, "GET", null, timeoutMs)
    override fun postJson(url: String, json: String, timeoutMs: Int): HttpResult = exec(url, "POST", json, timeoutMs)

    private fun exec(url: String, method: String, body: String?, timeoutMs: Int): HttpResult {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = false
            c.setRequestProperty("Accept", "application/json")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val status = c.responseCode
            val stream = if (status in 200..299) c.inputStream else (c.errorStream ?: c.inputStream)
            val text = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val ra = c.getHeaderField("Retry-After")?.toIntOrNull()
            return HttpResult(status, text, ra)
        } finally {
            c.disconnect()
        }
    }
}

/** Phần dữ liệu Threads mà workflow cần; ThreadsApiClient là bản thật. */
interface ThreadsDataSource {
    fun me(): MeInfo
    fun keywordSearch(q: String, searchType: String, searchMode: String, limit: Int): List<ApiItem>
    /** Replies cấp 1 của một bài, tối đa [maxPages] trang. */
    fun replies(postId: String, maxPages: Int): List<ApiItem>
}

/**
 * Client Threads API chính thức. Endpoint/tham số/field theo tài liệu Meta (xem docs/AUDIT.md mục 4).
 * Token lấy qua [tokenProvider] mỗi lần gọi; không bao giờ ghi log URL hay body.
 */
class ThreadsApiClient(
    private val transport: HttpTransport,
    private val tokenProvider: () -> String?,
    private val graphBase: String = "https://graph.threads.com/v1.0",
    private val timeoutMs: Int = 20000
) : ThreadsDataSource {

    companion object {
        const val POST_FIELDS = "id,text,media_type,permalink,timestamp,username,has_replies,is_quote_post,is_reply"
        const val POST_FIELDS_MIN = "id,text,permalink,timestamp,username"
        const val REPLY_FIELDS = "id,text,username,permalink,timestamp,media_type,has_replies,is_reply,hide_status"
        const val REPLY_FIELDS_MIN = "id,text,username,permalink,timestamp"
        val VALID_SEARCH_TYPES = setOf("TOP", "RECENT")
        val VALID_SEARCH_MODES = setOf("KEYWORD", "TAG")
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun token(): String =
        tokenProvider()?.takeIf { it.isNotBlank() } ?: throw ThreadsError.NotAuthorized()

    private fun call(path: String, params: List<Pair<String, String>>): String {
        val sb = StringBuilder(graphBase).append(path)
        var sep = '?'
        for ((k, v) in params) { sb.append(sep).append(enc(k)).append('=').append(enc(v)); sep = '&' }
        sb.append(sep).append("access_token=").append(enc(token()))
        val r = try {
            transport.get(sb.toString(), timeoutMs)
        } catch (e: SocketTimeoutException) {
            throw ThreadsError.Network("Hết thời gian chờ Threads. Kiểm tra mạng rồi thử lại.")
        } catch (e: UnknownHostException) {
            throw ThreadsError.Network("Không kết nối được tới Threads. Kiểm tra mạng.")
        } catch (e: IOException) {
            throw ThreadsError.Network("Lỗi mạng khi gọi Threads.")
        }
        if (r.status !in 200..299) throw ThreadsDtos.parseError(r.status, r.body, r.retryAfterSec)
        return r.body
    }

    override fun me(): MeInfo = ThreadsDtos.parseMe(call("/me", listOf("fields" to "id,username")))

    override fun keywordSearch(q: String, searchType: String, searchMode: String, limit: Int): List<ApiItem> {
        require(q.isNotBlank()) { "q trống" }
        require(searchType in VALID_SEARCH_TYPES) { "search_type không hợp lệ" }
        require(searchMode in VALID_SEARCH_MODES) { "search_mode không hợp lệ" }
        val lim = limit.coerceIn(1, 100)
        fun run(fields: String) = ThreadsDtos.parseItems(
            call(
                "/keyword_search",
                listOf("q" to q, "search_type" to searchType, "search_mode" to searchMode, "limit" to lim.toString(), "fields" to fields)
            )
        ).items
        return try {
            run(POST_FIELDS)
        } catch (e: ThreadsError.BadField) {
            run(POST_FIELDS_MIN)  // một field bị từ chối → thử bộ field tối thiểu, không đoán thêm
        }
    }

    override fun replies(postId: String, maxPages: Int): List<ApiItem> {
        require(postId.isNotBlank()) { "postId trống" }
        val out = ArrayList<ApiItem>()
        var after: String? = null
        var fields = REPLY_FIELDS
        var page = 0
        val seenCursor = HashSet<String>()
        while (page < maxPages.coerceAtLeast(1)) {
            val params = ArrayList<Pair<String, String>>()
            params += "fields" to fields
            params += "reverse" to "false"
            if (after != null) params += "after" to after
            val body = try {
                call("/" + enc(postId) + "/replies", params)
            } catch (e: ThreadsError.BadField) {
                if (fields == REPLY_FIELDS_MIN) throw e
                fields = REPLY_FIELDS_MIN
                continue
            }
            val p = ThreadsDtos.parseItems(body)
            out += p.items
            page++
            val next = p.nextCursor
            if (next == null || !seenCursor.add(next)) break
            after = next
        }
        return out
    }
}
