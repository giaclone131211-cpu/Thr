package com.threads2video.data.threads

import com.threads2video.core.Json
import com.threads2video.core.bool
import com.threads2video.core.long
import com.threads2video.core.str
import com.threads2video.data.CommentRecord
import com.threads2video.data.PostRecord

/** Thông tin người dùng đang đăng nhập (GET /me). */
data class MeInfo(val id: String, val username: String?)

/** Một trang kết quả kèm con trỏ trang kế (nếu API trả về). */
data class Page<T>(val items: List<T>, val nextCursor: String?)

/** Raw item thô từ API, trước khi biến thành PostRecord/CommentRecord. */
data class ApiItem(
    val id: String,
    val text: String?,
    val username: String?,
    val permalink: String?,
    val timestamp: String?,
    val mediaType: String?,
    val hasReplies: Boolean?,
    val isReply: Boolean?,
    val isQuotePost: Boolean?,
    val hideStatus: String?,
    val likeCount: Long?
)

object ThreadsDtos {
    fun parseMe(body: String): MeInfo {
        val m = Json.parseObject(body)
        val id = m.str("id") ?: throw ThreadsError.BadResponse("Phản hồi /me không có id")
        return MeInfo(id, m.str("username"))
    }

    /** Trả về trang item + cursor `after` nếu có `paging.next`. Bỏ qua phần tử thiếu id. */
    fun parseItems(body: String): Page<ApiItem> {
        val root = try {
            Json.parseObject(body)
        } catch (e: Json.JsonException) {
            throw ThreadsError.BadResponse("Phản hồi từ Threads không đọc được")
        }
        val data = Json.asList(root["data"]) ?: throw ThreadsError.BadResponse("Phản hồi thiếu mảng data")
        val items = data.mapNotNull { Json.asMap(it) }.mapNotNull { m ->
            val id = m.str("id") ?: return@mapNotNull null
            ApiItem(
                id = id,
                text = m.str("text"),
                username = m.str("username"),
                permalink = m.str("permalink"),
                timestamp = m.str("timestamp"),
                mediaType = m.str("media_type"),
                hasReplies = m.bool("has_replies"),
                isReply = m.bool("is_reply"),
                isQuotePost = m.bool("is_quote_post"),
                hideStatus = m.str("hide_status"),
                // like_count KHÔNG có trong tài liệu replies/keyword_search; chỉ đọc nếu response thật sự có.
                likeCount = m.long("like_count")
            )
        }
        val paging = Json.asMap(root["paging"])
        val after = if (paging != null && paging["next"] != null)
            Json.asMap(paging["cursors"])?.str("after") else null
        return Page(items, after)
    }

    fun toPost(it: ApiItem): PostRecord? {
        val t = it.text?.trim().orEmpty()
        if (t.isEmpty()) return null
        return PostRecord(
            id = it.id, sourceUrl = it.permalink, authorUsername = it.username, rawText = it.text!!,
            createdAt = it.timestamp, likeCount = it.likeCount, hasReplies = it.hasReplies, isReply = it.isReply,
            relevanceScore = null, rankReasons = emptyList()
        )
    }

    fun toComment(it: ApiItem, postId: String): CommentRecord? {
        val t = it.text?.trim().orEmpty()
        if (t.isEmpty()) return null
        return CommentRecord(
            id = it.id, sourcePostId = postId, sourceUrl = it.permalink, authorUsername = it.username,
            rawText = it.text!!, ttsText = null, likeCount = it.likeCount, createdAt = it.timestamp,
            rankScore = null, rankReasons = emptyList(), cardImageUri = null, ocrRequired = false,
            needsManualReview = false, approvedForVideo = false
        )
    }

    /** Phân tích body lỗi Graph API: {"error":{"message","type","code","error_subcode"}}. */
    fun parseError(status: Int, body: String, retryAfterHeader: Int?): ThreadsError {
        var code: Int? = null
        var msg = ""
        try {
            val e = Json.asMap(Json.parseObject(body)["error"])
            if (e != null) {
                code = e.long("code")?.toInt()
                msg = e.str("message") ?: ""
            }
        } catch (_: Exception) {
        }
        val shortMsg = msg.take(200)
        return when {
            status == 429 || code in setOf(4, 17, 32, 613, 80001, 80002) ->
                ThreadsError.RateLimited(retryAfterHeader)
            status == 401 || code == 190 ->
                ThreadsError.NotAuthorized()
            status == 403 || code == 10 || (code != null && code in 200..299) || code == 3 ->
                ThreadsError.PermissionDenied(
                    guessPermission(msg),
                    "Threads từ chối quyền truy cập" + (if (shortMsg.isNotEmpty()) ": $shortMsg" else "") +
                        ". Kiểm tra app đã được cấp quyền tương ứng và bạn đã đồng ý đủ quyền."
                )
            code == 100 && msg.contains("field", ignoreCase = true) ->
                ThreadsError.BadField(shortMsg)
            status >= 500 -> ThreadsError.Network("Máy chủ Threads đang lỗi ($status). Thử lại sau.")
            else -> ThreadsError.BadResponse("Threads trả lỗi $status" + (if (code != null) " (mã $code)" else "") +
                (if (shortMsg.isNotEmpty()) ": $shortMsg" else ""))
        }
    }

    private fun guessPermission(msg: String): String? {
        val m = Regex("threads_[a-z_]+").find(msg)
        return m?.value
    }
}
