package com.threads2video.core

import java.text.Normalizer

/** Tiện ích chữ tiếng Việt / emoji dùng chung cho ranker và chuẩn hóa TTS. */
object Vn {
    private val MARKS = Regex("\\p{Mn}+")

    /** Bỏ dấu, hạ chữ thường, đ→d. Dùng để so khớp lỏng. */
    fun fold(s: String): String =
        MARKS.replace(Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD), "")
            .replace('đ', 'd')

    fun nfc(s: String): String = Normalizer.normalize(s, Normalizer.Form.NFC)

    /** Từ (chữ + số) đã bỏ dấu, dùng cho trùng lặp/độ liên quan. */
    fun tokens(s: String): List<String> =
        Regex("[a-z0-9]+").findAll(fold(s)).map { it.value }.toList()

    private fun isEmojiLike(cp: Int): Boolean = when {
        cp in 0x1F300..0x1FAFF -> true        // biểu tượng, mặt cười, vật thể, cờ, v.v.
        cp in 0x1F000..0x1F2FF -> true        // mahjong, domino, ô chữ cái khoanh vùng
        cp in 0x2600..0x27BF -> true          // ký hiệu linh tinh + dingbats
        cp in 0x2300..0x23FF -> true          // kỹ thuật linh tinh (⌚⏰…)
        cp in 0x2B00..0x2BFF -> true          // mũi tên/hình (⭐⬆…)
        cp in 0x2190..0x21FF -> true          // mũi tên
        cp in 0x2900..0x297F -> true
        cp in 0x1F900..0x1F9FF -> true
        cp == 0x00A9 || cp == 0x00AE || cp == 0x203C || cp == 0x2049 || cp == 0x2122 || cp == 0x2139 -> true
        cp in 0x25A0..0x25FF -> true          // hình học
        cp in 0x3030..0x303D -> true
        cp == 0x3297 || cp == 0x3299 -> true
        cp in 0xE0020..0xE007F -> true        // tag (cờ vùng)
        cp == 0x200D || cp == 0x20E3 -> true  // ZWJ, keycap
        cp in 0xFE00..0xFE0F -> true          // variation selectors
        cp in 0x1F3FB..0x1F3FF -> true        // skin tone
        cp in 0x1F1E6..0x1F1FF -> true        // regional indicators
        else -> false
    }

    /** Bỏ mọi emoji/ký hiệu hình; KHÔNG chạm vào chữ, số, dấu câu thường. */
    fun stripEmoji(s: String): String {
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            val n = Character.charCount(cp)
            if (!isEmojiLike(cp)) sb.appendCodePoint(cp)
            i += n
        }
        return sb.toString()
    }

    fun hasEmoji(s: String): Boolean {
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            if (isEmojiLike(cp)) return true
            i += Character.charCount(cp)
        }
        return false
    }

    /** Có emoji cười (😂🤣😆😹😅) — tín hiệu "hài" cho ranker. */
    fun hasLaughEmoji(s: String): Boolean {
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            if (cp == 0x1F602 || cp == 0x1F923 || cp == 0x1F606 || cp == 0x1F639 || cp == 0x1F605) return true
            i += Character.charCount(cp)
        }
        return false
    }

    fun countEmoji(s: String): Int {
        var i = 0
        var n = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            if (isEmojiLike(cp) && cp != 0x200D && cp !in 0xFE00..0xFE0F) n++
            i += Character.charCount(cp)
        }
        return n
    }

    /** Số ký tự chữ/số (bất kể ngôn ngữ). */
    fun letterDigitCount(s: String): Int = s.count { it.isLetterOrDigit() }

    fun collapseSpaces(s: String): String = s.replace(Regex("\\s+"), " ").trim()
}
