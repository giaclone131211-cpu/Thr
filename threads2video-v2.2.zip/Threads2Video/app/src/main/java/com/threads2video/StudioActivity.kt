package com.threads2video

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.util.Base64
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

/** Hộp thư chứa các file giọng tải từ Studio, MainActivity sẽ lấy khi quay lại. */
object VoiceInbox {
    val files = CopyOnWriteArrayList<File>()
}

class StudioActivity : ComponentActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var web: WebView
    private lateinit var info: TextView
    private lateinit var scriptView: TextView
    private var scripts: List<String> = emptyList()
    private var idx = 0
    private val seq = AtomicInteger(0)
    private val got = AtomicInteger(0)
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var curOut: FileOutputStream? = null
    private var curFile: File? = null

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val cb = fileCallback
        fileCallback = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun styled(b: Button, primary: Boolean): Button {
        b.setTextColor(if (primary) Color.parseColor("#04202A") else Color.WHITE)
        b.setBackgroundColor(Color.parseColor(if (primary) "#22D3EE" else "#1B2850"))
        b.setAllCaps(false)
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scripts = (intent.getStringArrayExtra("scripts") ?: emptyArray<String>()).toList()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0A1022"))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(8), dp(6), dp(8), dp(6))
        val back = styled(Button(this), true)
        back.text = "Về app"
        back.setOnClickListener { finish() }
        info = TextView(this)
        info.setTextColor(Color.WHITE)
        info.textSize = 14f
        info.text = "Đã nhận 0 file giọng"
        info.setPadding(dp(12), 0, 0, 0)
        top.addView(back, LinearLayout.LayoutParams(WRAP, WRAP))
        top.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setPadding(dp(10), dp(8), dp(10), dp(10))
        bottom.setBackgroundColor(Color.parseColor("#0F1830"))
        scriptView = TextView(this)
        scriptView.setTextColor(Color.WHITE)
        scriptView.textSize = 13f
        scriptView.maxLines = 3
        scriptView.ellipsize = TextUtils.TruncateAt.END
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val prev = styled(Button(this), false)
        prev.text = "◀"
        prev.setOnClickListener { move(-1) }
        val copy = styled(Button(this), true)
        copy.text = "Chép đoạn này"
        copy.setOnClickListener { copyCurrent() }
        val next = styled(Button(this), false)
        next.text = "▶"
        next.setOnClickListener { move(1) }
        row.addView(prev, LinearLayout.LayoutParams(dp(56), WRAP))
        row.addView(copy, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(next, LinearLayout.LayoutParams(dp(56), WRAP))
        bottom.addView(scriptView, LinearLayout.LayoutParams(MATCH, WRAP))
        bottom.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))

        setContentView(root)
        showScript()
        setupWeb()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        web.loadUrl("https://www.vieneu.io/#/studio")
    }

    private fun showScript() {
        scriptView.text = if (scripts.isEmpty()) {
            "Chưa có kịch bản. Về app và bấm “Lấy kịch bản từ nội dung”."
        } else {
            "Đoạn ${idx + 1}/${scripts.size}: ${scripts[idx]}"
        }
    }

    private fun move(d: Int) {
        if (scripts.isEmpty()) return
        idx = (idx + d + scripts.size) % scripts.size
        showScript()
    }

    private fun copyCurrent() {
        if (scripts.isEmpty()) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("script", scripts[idx]))
        Toast.makeText(this, "Đã chép đoạn ${idx + 1}. Bấm giữ ô nhập trong Studio để dán.", Toast.LENGTH_SHORT).show()
    }

    private fun setupWeb() {
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        val st = web.settings
        st.javaScriptEnabled = true
        st.domStorageEnabled = true
        st.mediaPlaybackRequiresUserGesture = false
        st.javaScriptCanOpenWindowsAutomatically = true
        st.allowContentAccess = true
        st.userAgentString = st.userAgentString.replace("; wv", "")

        web.addJavascriptInterface(StudioBridge(), "Studio")
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    picker.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }
        web.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            when {
                url.startsWith("blob:") -> fetchBlob(url, mimetype)
                url.startsWith("data:") -> saveDataUrl(url, mimetype)
                else -> downloadHttp(url, userAgent, contentDisposition, mimetype)
            }
        }
    }

    private fun voicesDir(): File {
        val d = File(cacheDir, "voices")
        d.mkdirs()
        return d
    }

    private fun extFor(mime: String?, url: String?): String {
        val m = (mime ?: "").lowercase()
        return when {
            m.contains("wav") -> "wav"
            m.contains("mpeg") || m.contains("mp3") -> "mp3"
            m.contains("ogg") -> "ogg"
            m.contains("webm") -> "webm"
            m.contains("mp4") || m.contains("m4a") || m.contains("aac") -> "m4a"
            else -> {
                val g = if (url != null) URLUtil.guessFileName(url, null, mime).substringAfterLast('.', "") else ""
                if (g.isNotEmpty() && g.length <= 4) g else "mp3"
            }
        }
    }

    private fun nextName(mime: String?, url: String?): String {
        val n = seq.incrementAndGet().toString().padStart(2, '0')
        return n + "_giong." + extFor(mime, url)
    }

    private fun fetchBlob(url: String, mime: String?) {
        val name = nextName(mime, null)
        val js = "(async function(){try{var r=await fetch(" + JSONObject.quote(url) + ");var b=await r.blob();" +
            "Studio.begin(" + JSONObject.quote(name) + ");var CH=700000;" +
            "for(var o=0;o<b.size;o+=CH){var s=await new Promise(function(res){var fr=new FileReader();" +
            "fr.onload=function(){res(String(fr.result).split(',')[1]);};fr.readAsDataURL(b.slice(o,o+CH));});Studio.chunk(s);}" +
            "Studio.end();}catch(e){Studio.fail(String(e));}})();"
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    private fun saveDataUrl(url: String, mime: String?) {
        Thread {
            try {
                val comma = url.indexOf(',')
                val bytes = Base64.decode(url.substring(comma + 1), Base64.DEFAULT)
                val f = File(voicesDir(), nextName(mime, null))
                f.writeBytes(bytes)
                done(f)
            } catch (e: Exception) {
                failMsg("Không lưu được file tải về")
            }
        }.start()
    }

    private fun downloadHttp(url: String, ua: String?, cd: String?, mime: String?) {
        Thread {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 20000
                c.readTimeout = 60000
                if (!ua.isNullOrEmpty()) c.setRequestProperty("User-Agent", ua)
                val ck = CookieManager.getInstance().getCookie(url)
                if (!ck.isNullOrEmpty()) c.setRequestProperty("Cookie", ck)
                val f = File(voicesDir(), nextName(mime ?: c.contentType, url))
                c.inputStream.use { inp ->
                    FileOutputStream(f).use { out -> inp.copyTo(out) }
                }
                done(f)
            } catch (e: Exception) {
                failMsg("Tải file lỗi: " + e.message)
            }
        }.start()
    }

    private fun done(f: File) {
        if (f.length() <= 0L) {
            failMsg("File tải về bị rỗng")
            return
        }
        VoiceInbox.files.add(f)
        val n = got.incrementAndGet()
        runOnUiThread {
            info.text = "Đã nhận $n file giọng"
            Toast.makeText(this, "Đã nhận file giọng thứ $n", Toast.LENGTH_SHORT).show()
        }
    }

    private fun failMsg(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        try { curOut?.close() } catch (_: Exception) {}
        web.destroy()
        super.onDestroy()
    }

    inner class StudioBridge {
        @JavascriptInterface
        fun begin(name: String) {
            try { curOut?.close() } catch (_: Exception) {}
            val f = File(voicesDir(), name)
            curFile = f
            curOut = FileOutputStream(f)
        }

        @JavascriptInterface
        fun chunk(b64: String) {
            try { curOut?.write(Base64.decode(b64, Base64.DEFAULT)) } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun end() {
            try { curOut?.close() } catch (_: Exception) {}
            curOut = null
            val f = curFile
            curFile = null
            if (f != null) done(f)
        }

        @JavascriptInterface
        fun fail(msg: String) {
            try { curOut?.close() } catch (_: Exception) {}
            curOut = null
            failMsg("Không lấy được file: $msg")
        }
    }
}
