package com.threads2video.workflow

import com.threads2video.ai.CancelToken
import com.threads2video.ai.Criteria
import com.threads2video.ai.Dropped
import com.threads2video.ai.LocalAiEngine
import com.threads2video.ai.RankRequest
import com.threads2video.data.CommentRecord
import com.threads2video.data.PostRecord
import com.threads2video.data.threads.ApiItem
import com.threads2video.data.threads.MeInfo
import com.threads2video.data.threads.Notice
import com.threads2video.data.threads.Notices
import com.threads2video.data.threads.ThreadsDataSource
import com.threads2video.data.threads.ThreadsDtos
import com.threads2video.data.threads.ThreadsError

data class ResearchOptions(
    val topic: String,
    val criteria: Criteria = Criteria.MIX,
    val topN: Int = 8,
    val extraKeywords: List<String> = emptyList(),
    val maxQueries: Int = 4,
    val searchLimit: Int = 50,
    val maxCandidates: Int = 15,
    val repliesProbe: Int = 3,
    val maxReplyPages: Int = 5
)

/** Kết quả đọc replies + xếp hạng cho một bài nguồn. */
data class SourceResult(
    val source: PostRecord,
    /** Toàn bộ bình luận hợp lệ đã xếp hạng (để người dùng chọn thêm ở checkpoint 1). */
    val comments: List<CommentRecord>,
    val topIds: List<String>,
    val dropped: List<Dropped>,
    val notices: List<Notice>,
    val engine: String
)

data class ResearchResult(
    val topic: String,
    val candidates: List<PostRecord>,
    val source: SourceResult?,
    val notices: List<Notice>,
    val me: MeInfo?,
    val queriesUsed: Int
)

/**
 * Luồng research tự động: tìm bài → xếp hạng bài → lấy replies → xếp hạng bình luận.
 * Chỉ dùng [ThreadsDataSource] (API chính thức). Không có nhánh nào rơi về scraping:
 * lỗi quyền/mạng/token được ném ra dưới dạng [ThreadsError] để UI hiển thị hướng dẫn.
 */
class ResearchWorkflow(private val data: ThreadsDataSource, private val ai: LocalAiEngine) {

    fun research(opt: ResearchOptions, cancel: CancelToken, progress: (String) -> Unit = {}): ResearchResult {
        val topic = opt.topic.trim()
        if (topic.isEmpty()) throw IllegalArgumentException("Chưa nhập chủ đề")
        val notices = ArrayList<Notice>()

        progress("Đang kiểm tra tài khoản Threads…")
        var me: MeInfo? = null
        try {
            me = data.me()
        } catch (e: ThreadsError.NotAuthorized) {
            throw e
        } catch (e: ThreadsError.RateLimited) {
            throw e
        } catch (e: ThreadsError) {
            // /me lỗi nhẹ không chặn tìm kiếm; chỉ mất khả năng phát hiện "chỉ thấy bài của mình"
        }

        val queries = buildQueries(topic, opt.extraKeywords, opt.maxQueries)
        val items = ArrayList<ApiItem>()
        var used = 0
        for ((i, q) in queries.withIndex()) {
            if (cancel.cancelled) throw ThreadsError.Cancelled()
            progress("Tìm bài (${i + 1}/${queries.size}): ${q.third}")
            try {
                items += data.keywordSearch(q.first, q.second, q.third, opt.searchLimit)
                used++
            } catch (e: ThreadsError.RateLimited) {
                if (i == 0) throw e
                notices += Notice("rate_limited_partial", "Threads giới hạn lượt gọi, chỉ dùng ${used} truy vấn đầu.")
                break
            } catch (e: ThreadsError.PermissionDenied) {
                if (i == 0) throw e else break
            } catch (e: ThreadsError.BadField) {
                if (i == 0) throw e else break
            }
        }

        val posts = items.mapNotNull { ThreadsDtos.toPost(it) }
        if (posts.isNotEmpty() && me?.username != null &&
            posts.all { it.authorUsername?.equals(me.username, ignoreCase = true) == true }
        ) {
            notices += Notice(
                Notices.OWN_POSTS_ONLY,
                "Mọi kết quả đều là bài của chính bạn. Nếu app chưa được Meta duyệt quyền threads_keyword_search, " +
                    "Threads chỉ cho tìm trong bài của bạn (không báo lỗi). Hãy xin duyệt quyền hoặc dùng nhập thủ công."
            )
        }
        progress("Đang xếp hạng ${posts.size} bài…")
        val ranked = ai.rankPosts(topic, posts, cancel).take(opt.maxCandidates)
        if (ranked.isEmpty()) {
            notices += Notice(
                Notices.EMPTY,
                if (posts.isEmpty())
                    "Không tìm thấy bài công khai nào. Có thể do chưa được duyệt quyền tìm kiếm, từ khóa bị Threads coi là nhạy cảm, hoặc thật sự không có bài. Hãy đổi từ khóa hoặc dùng nhập thủ công."
                else
                    "Có ${posts.size} bài nhưng không bài nào đủ dài/phù hợp (đã loại bài quá ngắn, reply, spam). Thử từ khóa khác."
            )
            return ResearchResult(topic, emptyList(), null, notices, me, used)
        }

        // Dò replies của vài bài tốt nhất, chọn bài có bình luận tốt nhất làm nguồn mặc định.
        var best: SourceResult? = null
        var bestQ = -1.0
        var failed = 0
        for ((i, p) in ranked.filter { it.hasReplies != false }.take(opt.repliesProbe).withIndex()) {
            if (cancel.cancelled) throw ThreadsError.Cancelled()
            progress("Đọc bình luận bài ${i + 1}…")
            try {
                val sr = loadSource(p, topic, opt.criteria, opt.topN, opt.maxReplyPages, cancel)
                val q = sr.topIds.sumOf { id -> (sr.comments.firstOrNull { it.id == id }?.rankScore ?: 0f).toDouble() }
                if (q > bestQ) { bestQ = q; best = sr }
            } catch (e: ThreadsError.Cancelled) {
                throw e
            } catch (e: ThreadsError.NotAuthorized) {
                throw e
            } catch (e: ThreadsError.RateLimited) {
                notices += Notice(Notices.REPLY_FETCH_FAILED, e.message); failed++; break
            } catch (e: ThreadsError.PermissionDenied) {
                notices += Notice(Notices.REPLY_FETCH_FAILED, "Không đọc được bình luận: ${e.message}"); failed++; break
            } catch (e: ThreadsError) {
                failed++
            }
        }
        if (best == null) {
            notices += Notice(
                Notices.NO_REPLIES,
                "Chưa lấy được bình luận hợp lệ cho các bài tìm thấy. Bạn có thể chọn bài khác trong danh sách hoặc nhập thủ công."
            )
        }
        return ResearchResult(topic, ranked, best, notices, me, used)
    }

    /** Lấy replies của một bài và xếp hạng. Dùng cả khi người dùng chọn lại bài nguồn. */
    fun loadSource(
        post: PostRecord, topic: String, criteria: Criteria, topN: Int, maxPages: Int, cancel: CancelToken
    ): SourceResult {
        val raw = data.replies(post.id, maxPages)
        val comments = raw.filter { it.isReply != false && !it.hideStatus.equals("HIDDEN", ignoreCase = true) }
            .mapNotNull { ThreadsDtos.toComment(it, post.id) }
        val notices = ArrayList<Notice>()
        if (comments.isEmpty()) {
            notices += Notice(Notices.NO_REPLIES, "Bài này chưa có bình luận hợp lệ qua API (hoặc API không trả về).")
            return SourceResult(post, emptyList(), emptyList(), emptyList(), notices, "none")
        }
        val rr = ai.rankComments(RankRequest(topic, post.rawText, comments, criteria, topN), cancel)
        if (rr.ranked.none { it.likeCount != null }) {
            notices += Notice(Notices.NO_LIKES, "API không trả số tim của bình luận. Xếp hạng chỉ dựa trên nội dung; card sẽ không hiện số tim.")
        }
        if (rr.topIds.size < topN) {
            notices += Notice(
                Notices.FEWER_THAN_TARGET,
                "Chỉ có ${rr.topIds.size} bình luận hợp lệ (mục tiêu $topN). Đã loại ${rr.dropped.size} bình luận (spam/trùng/rác)."
            )
        }
        return SourceResult(post, rr.ranked, rr.topIds, rr.dropped, notices, rr.engine)
    }

    /** Tối đa [maxQ] truy vấn: TOP, RECENT, (TAG nếu chủ đề 1 từ), rồi từ khóa phụ. */
    internal fun buildQueries(topic: String, extra: List<String>, maxQ: Int): List<Triple<String, String, String>> {
        val out = ArrayList<Triple<String, String, String>>()
        out += Triple(topic, "TOP", "KEYWORD")
        out += Triple(topic, "RECENT", "KEYWORD")
        if (!topic.contains(' ') && topic.length <= 40) out += Triple(topic.trimStart('#'), "TOP", "TAG")
        for (e in extra.map { it.trim() }.filter { it.isNotEmpty() && !it.equals(topic, true) }.distinct()) out += Triple(e, "TOP", "KEYWORD")
        return out.take(maxQ.coerceIn(1, 6))
    }
}
