package com.threads2video.data.local

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.threads2video.core.Json
import com.threads2video.core.long
import com.threads2video.core.str
import com.threads2video.data.threads.ConfigStore
import com.threads2video.data.threads.PendingStore
import com.threads2video.data.threads.StoredToken
import com.threads2video.data.threads.ThreadsConfig
import com.threads2video.data.threads.TokenStore
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Token Threads được mã hóa AES-256-GCM bằng khóa nằm trong Android Keystore (không xuất ra được).
 * Giải mã lỗi (đổi thiết bị, mất khóa…) ⇒ coi như chưa đăng nhập và xóa dữ liệu hỏng.
 * Token không bao giờ được ghi vào Logcat.
 */
class SecureTokenStore(ctx: Context) : TokenStore {
    private val prefs = ctx.applicationContext.getSharedPreferences("t2v_secure", Context.MODE_PRIVATE)

    companion object {
        private const val ALIAS = "t2v_token_key_v1"
        private const val KEY_BLOB = "token_blob"
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    @Synchronized
    override fun save(t: StoredToken) {
        val m = linkedMapOf<String, Any?>("token" to t.token, "obtainedAtMs" to t.obtainedAtMs, "source" to t.source)
        t.expiresAtMs?.let { m["expiresAtMs"] = it }
        t.userId?.let { m["userId"] = it }
        t.username?.let { m["username"] = it }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(Json.stringify(m).toByteArray(Charsets.UTF_8))
        val blob = Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
        prefs.edit().putString(KEY_BLOB, blob).apply()
    }

    @Synchronized
    override fun load(): StoredToken? {
        val blob = prefs.getString(KEY_BLOB, null) ?: return null
        return try {
            val parts = blob.split(":")
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val ct = Base64.decode(parts[1], Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            val o = Json.parseObject(String(c.doFinal(ct), Charsets.UTF_8))
            StoredToken(
                token = o.str("token") ?: return clearAndNull(),
                expiresAtMs = o.long("expiresAtMs"),
                obtainedAtMs = o.long("obtainedAtMs") ?: 0L,
                userId = o.str("userId"),
                username = o.str("username"),
                source = o.str("source") ?: "manual"
            )
        } catch (_: Exception) {
            clearAndNull()
        }
    }

    private fun clearAndNull(): StoredToken? { clear(); return null }

    @Synchronized
    override fun clear() {
        prefs.edit().remove(KEY_BLOB).apply()
    }
}

/** App ID công khai + URL backend: không bí mật nên để SharedPreferences thường. */
class PrefsConfigStore(ctx: Context) : ConfigStore {
    private val prefs = ctx.applicationContext.getSharedPreferences("t2v_config", Context.MODE_PRIVATE)
    override fun load() = ThreadsConfig(prefs.getString("appId", "") ?: "", prefs.getString("brokerUrl", "") ?: "")
    override fun save(c: ThreadsConfig) {
        prefs.edit().putString("appId", c.appId.trim()).putString("brokerUrl", c.brokerUrl.trim()).apply()
    }
}

class PrefsPendingStore(ctx: Context) : PendingStore {
    private val prefs = ctx.applicationContext.getSharedPreferences("t2v_oauth_pending", Context.MODE_PRIVATE)
    @Synchronized
    override fun put(state: String, verifier: String, createdAtMs: Long) {
        prefs.edit().putString("state", state).putString("verifier", verifier).putLong("ts", createdAtMs).apply()
    }
    @Synchronized
    override fun take(): Triple<String, String, Long>? {
        val s = prefs.getString("state", null)
        val v = prefs.getString("verifier", null)
        val ts = prefs.getLong("ts", 0L)
        prefs.edit().clear().commit()
        return if (s != null && v != null) Triple(s, v, ts) else null
    }
}
