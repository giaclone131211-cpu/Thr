package com.threads2video.core

/**
 * JSON tối giản, không phụ thuộc Android (org.json không có trên JVM thuần).
 * Giá trị: Map<String, Any?>, List<Any?>, String, Long, Double, Boolean, null.
 */
object Json {
    class JsonException(msg: String) : Exception(msg)

    fun parse(s: String): Any? {
        val p = Parser(s)
        p.ws()
        val v = p.value()
        p.ws()
        if (p.i != s.length) throw JsonException("Dữ liệu thừa sau JSON tại vị trí ${p.i}")
        return v
    }

    fun parseObject(s: String): Map<String, Any?> =
        asMap(parse(s)) ?: throw JsonException("Không phải JSON object")

    fun stringify(v: Any?): String {
        val sb = StringBuilder()
        write(sb, v)
        return sb.toString()
    }

    @Suppress("UNCHECKED_CAST")
    fun asMap(v: Any?): Map<String, Any?>? = v as? Map<String, Any?>

    @Suppress("UNCHECKED_CAST")
    fun asList(v: Any?): List<Any?>? = v as? List<Any?>

    private fun write(sb: StringBuilder, v: Any?) {
        when (v) {
            null -> sb.append("null")
            is String -> quote(sb, v)
            is Boolean -> sb.append(if (v) "true" else "false")
            is Int, is Long, is Short, is Byte -> sb.append(v.toString())
            is Float -> if (v.isNaN() || v.isInfinite()) sb.append("null") else sb.append(v.toString())
            is Double -> if (v.isNaN() || v.isInfinite()) sb.append("null") else sb.append(v.toString())
            is Map<*, *> -> {
                sb.append('{')
                var first = true
                for ((k, x) in v) {
                    if (!first) sb.append(',')
                    first = false
                    quote(sb, k.toString())
                    sb.append(':')
                    write(sb, x)
                }
                sb.append('}')
            }
            is Iterable<*> -> {
                sb.append('[')
                var first = true
                for (x in v) {
                    if (!first) sb.append(',')
                    first = false
                    write(sb, x)
                }
                sb.append(']')
            }
            else -> quote(sb, v.toString())
        }
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                ' ' -> sb.append("\\u2028")
                ' ' -> sb.append("\\u2029")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        sb.append('"')
    }

    private class Parser(val s: String) {
        var i = 0

        fun ws() {
            while (i < s.length && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')) i++
        }

        fun fail(m: String): Nothing = throw JsonException("$m tại vị trí $i")

        fun value(): Any? {
            if (i >= s.length) fail("JSON bị cụt")
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c in '0'..'9') num() else fail("Ký tự không hợp lệ '$c'")
            }
        }

        fun lit(w: String, v: Any?): Any? {
            if (!s.startsWith(w, i)) fail("Giá trị không hợp lệ")
            i += w.length
            return v
        }

        fun obj(): Map<String, Any?> {
            val m = LinkedHashMap<String, Any?>()
            i++
            ws()
            if (i < s.length && s[i] == '}') { i++; return m }
            while (true) {
                ws()
                if (i >= s.length || s[i] != '"') fail("Thiếu khóa")
                val k = str()
                ws()
                if (i >= s.length || s[i] != ':') fail("Thiếu ':'")
                i++
                ws()
                m[k] = value()
                ws()
                if (i >= s.length) fail("Object bị cụt")
                if (s[i] == ',') { i++; continue }
                if (s[i] == '}') { i++; return m }
                fail("Mong ',' hoặc '}'")
            }
        }

        fun arr(): List<Any?> {
            val l = ArrayList<Any?>()
            i++
            ws()
            if (i < s.length && s[i] == ']') { i++; return l }
            while (true) {
                ws()
                l.add(value())
                ws()
                if (i >= s.length) fail("Mảng bị cụt")
                if (s[i] == ',') { i++; continue }
                if (s[i] == ']') { i++; return l }
                fail("Mong ',' hoặc ']'")
            }
        }

        fun str(): String {
            val sb = StringBuilder()
            i++
            while (true) {
                if (i >= s.length) fail("Chuỗi bị cụt")
                val c = s[i++]
                when {
                    c == '"' -> return sb.toString()
                    c == '\\' -> {
                        if (i >= s.length) fail("Escape bị cụt")
                        when (val e = s[i++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000c')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (i + 4 > s.length) fail("Escape \\u bị cụt")
                                val h = s.substring(i, i + 4).toIntOrNull(16) ?: fail("Escape \\u sai")
                                sb.append(h.toChar())
                                i += 4
                            }
                            else -> fail("Escape không hợp lệ '$e'")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        fun num(): Any {
            val st = i
            if (s[i] == '-') i++
            while (i < s.length && s[i] in '0'..'9') i++
            var isD = false
            if (i < s.length && s[i] == '.') { isD = true; i++; while (i < s.length && s[i] in '0'..'9') i++ }
            if (i < s.length && (s[i] == 'e' || s[i] == 'E')) {
                isD = true; i++
                if (i < s.length && (s[i] == '+' || s[i] == '-')) i++
                while (i < s.length && s[i] in '0'..'9') i++
            }
            val t = s.substring(st, i)
            return if (isD) (t.toDoubleOrNull() ?: fail("Số sai")) else (t.toLongOrNull() ?: t.toDoubleOrNull() ?: fail("Số sai"))
        }
    }
}

fun Map<String, Any?>.str(k: String): String? = (this[k] as? String)
fun Map<String, Any?>.bool(k: String): Boolean? = (this[k] as? Boolean)
fun Map<String, Any?>.long(k: String): Long? = when (val v = this[k]) {
    is Long -> v
    is Double -> v.toLong()
    is Int -> v.toLong()
    else -> null
}
fun Map<String, Any?>.dbl(k: String): Double? = when (val v = this[k]) {
    is Long -> v.toDouble()
    is Double -> v
    is Int -> v.toDouble()
    else -> null
}
