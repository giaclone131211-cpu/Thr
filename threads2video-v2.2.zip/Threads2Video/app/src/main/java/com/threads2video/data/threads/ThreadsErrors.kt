package com.threads2video.data.threads

/**
 * Lỗi nghiệp vụ Threads, mỗi lỗi có `code` ổn định để UI hiển thị hướng dẫn đúng.
 * Không có lỗi nào được phép dẫn tới "tự quay về scraping".
 */
sealed class ThreadsError(val code: String, override val message: String) : Exception(message) {
    class NotConfigured(detail: String) : ThreadsError("not_configured", detail)
    class NotAuthorized(detail: String = "Chưa đăng nhập Threads hoặc token đã hết hạn. Hãy đăng nhập lại.") :
        ThreadsError("not_authorized", detail)
    class ConsentDenied(detail: String = "Bạn đã từ chối cấp quyền cho ứng dụng.") : ThreadsError("consent_denied", detail)
    class PermissionDenied(val permission: String?, detail: String) : ThreadsError("permission_denied", detail)
    class RateLimited(val retryAfterSec: Int?, detail: String = "Threads đang giới hạn số lượt gọi. Hãy thử lại sau.") :
        ThreadsError("rate_limited", detail)
    class Network(detail: String) : ThreadsError("network", detail)
    class BadResponse(detail: String) : ThreadsError("bad_response", detail)
    class BadField(detail: String) : ThreadsError("bad_field", detail)
    class Cancelled : ThreadsError("cancelled", "Đã hủy")
}

/**
 * Thông báo không phải lỗi nhưng người dùng cần biết (vd: app chưa được Meta duyệt tìm kiếm công khai).
 */
data class Notice(val code: String, val message: String)

object Notices {
    const val OWN_POSTS_ONLY = "own_posts_only"
    const val EMPTY = "empty_results"
    const val NO_REPLIES = "no_replies"
    const val NO_LIKES = "no_like_data"
    const val FEWER_THAN_TARGET = "fewer_than_target"
    const val REPLY_FETCH_FAILED = "reply_fetch_failed"
}
