package com.threads2video.ai

/**
 * Prompt cho model cục bộ. Chuỗi "/no_think" tắt chế độ suy nghĩ của Qwen3 (model khác bỏ qua).
 * Template chat thật do chính model áp dụng (llama_chat_apply_template), không hardcode ChatML.
 */
object PromptTemplates {

    const val TTS_SYSTEM =
        "Bạn là bộ chuẩn hóa văn bản tiếng Việt cho giọng đọc (TTS).\n" +
            "CHỈ được sửa: teencode, viết tắt, lỗi dấu câu, ký hiệu khó đọc, cách ngắt câu; và bỏ emoji.\n" +
            "TUYỆT ĐỐI giữ nguyên ý, lập trường, thông tin và sắc thái (mỉa mai, hài hước, gay gắt). " +
            "Không thêm ý, không bớt ý, không đảo nghĩa, không làm nhẹ hay nặng hơn, không giải thích, không rút gọn.\n" +
            "Từ hoặc viết tắt nào bạn không chắc: để nguyên và đặt \"unsure\": true.\n" +
            "Chỉ trả về đúng MỘT JSON: {\"t\":\"văn bản đã chuẩn hóa\",\"unsure\":false,\"why\":\"\"} /no_think"

    fun ttsUser(raw: String, baseline: String): String =
        "Văn bản gốc:\n\"\"\"\n$raw\n\"\"\"\nBản tham khảo đã xử lý bằng luật (có thể còn sót):\n\"\"\"\n$baseline\n\"\"\""

    const val RANK_SYSTEM =
        "Bạn là biên tập viên video TikTok tiếng Việt. Chấm điểm từng bình luận từ 0 đến 10 theo tiêu chí được nêu. " +
            "Không loại bỏ ý kiến trái chiều chỉ vì trái chiều. Chỉ trả về JSON dạng " +
            "[{\"i\":số thứ tự,\"s\":điểm 0-10,\"r\":\"lý do ngắn dưới 60 ký tự\"}] /no_think"

    fun rankUser(criteria: Criteria, topic: String, post: String, comments: List<String>): String {
        val crit = when (criteria) {
            Criteria.MIX -> "cân bằng: cuốn, đa dạng, giữ người xem tới cuối video"
            Criteria.FUNNY -> "hài hước, bá đạo, dễ viral"
            Criteria.DRAMA -> "gây tranh luận, drama, nhiều cảm xúc"
            Criteria.DEEP -> "sâu sắc, ý nghĩa, dễ đồng cảm"
        }
        val sb = StringBuilder()
        sb.append("Chủ đề: ").append(topic).append("\nBài gốc: \"\"\"").append(post.take(600)).append("\"\"\"\n")
        sb.append("Tiêu chí: ").append(crit).append("\nBình luận:\n")
        comments.forEachIndexed { i, c -> sb.append(i + 1).append(". ").append(c.take(280).replace('\n', ' ')).append('\n') }
        return sb.toString()
    }

    const val CAPTION_SYSTEM =
        "Viết caption TikTok tiếng Việt: 1 dòng mở đầu gây tò mò dưới 90 ký tự, 1 câu kêu gọi bình luận, " +
            "rồi 6 đến 8 hashtag. Không giải thích, không markdown. /no_think"

    fun captionUser(post: String, comments: List<String>): String =
        "Bài viết: \"\"\"${post.take(600)}\"\"\"\nBình luận trong video:\n" +
            (if (comments.isEmpty()) "(không có)" else comments.joinToString("\n") { "- " + it.take(200) })
}
