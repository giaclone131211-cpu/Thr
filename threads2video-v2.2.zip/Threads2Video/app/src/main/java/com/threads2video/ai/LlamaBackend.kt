package com.threads2video.ai

import java.io.ByteArrayOutputStream

/**
 * Cầu nối JNI tới llama.cpp. CHỈ có hiệu lực khi APK được build với `-Pt2v.llama=true`
 * (xem app/build.gradle.kts và README). Mọi chuỗi đi qua JNI dưới dạng byte UTF-8 để tránh lỗi
 * "modified UTF-8" với emoji/ký tự ngoài BMP.
 */
object LlamaNative {
    @JvmStatic external fun nativeLoad(path: ByteArray, nCtx: Int, nThreads: Int): Long
    @JvmStatic external fun nativeApplyTemplate(h: Long, system: ByteArray, user: ByteArray): ByteArray?
    @JvmStatic external fun nativeStart(h: Long, prompt: ByteArray, maxTokens: Int): Boolean
    @JvmStatic external fun nativeNext(h: Long): ByteArray?
    @JvmStatic external fun nativeFinish(h: Long)
    @JvmStatic external fun nativeFree(h: Long)
    @JvmStatic external fun nativeLastError(): ByteArray?

    @Volatile private var state = 0 // 0 chưa thử, 1 có, -1 không có

    fun available(): Boolean {
        if (state == 0) {
            state = try { System.loadLibrary("t2vllama"); 1 } catch (e: Throwable) { -1 }
        }
        return state == 1
    }

    fun lastError(): String = nativeLastError()?.toString(Charsets.UTF_8) ?: "lỗi không rõ"
}

class LlamaBackend private constructor(
    private var handle: Long,
    override val modelName: String
) : LlmBackend {

    private val lock = Any()

    companion object {
        const val NOT_BUILT = "Bản APK này không kèm runtime llama.cpp (build với -Pt2v.llama=true để bật). Đang dùng luật xác định."

        fun open(path: String, modelName: String, nCtx: Int = 2048, nThreads: Int = 4): LlamaBackend {
            if (!LlamaNative.available()) throw AiUnavailable(NOT_BUILT)
            val h = LlamaNative.nativeLoad(path.toByteArray(Charsets.UTF_8), nCtx, nThreads)
            if (h == 0L) throw AiUnavailable("Không nạp được model: " + LlamaNative.lastError())
            return LlamaBackend(h, modelName)
        }
    }

    override fun complete(system: String, user: String, maxTokens: Int, cancel: CancelToken): String =
        synchronized(lock) {
            check(handle != 0L) { "Model đã được giải phóng" }
            cancel.check()
            val prompt = LlamaNative.nativeApplyTemplate(handle, system.toByteArray(Charsets.UTF_8), user.toByteArray(Charsets.UTF_8))
                ?: throw AiUnavailable("Không áp dụng được chat template của model: " + LlamaNative.lastError())
            if (!LlamaNative.nativeStart(handle, prompt, maxTokens)) throw AiUnavailable("Không bắt đầu suy luận: " + LlamaNative.lastError())
            val out = ByteArrayOutputStream()
            try {
                while (true) {
                    cancel.check()
                    val piece = LlamaNative.nativeNext(handle) ?: break
                    out.write(piece)
                }
            } finally {
                LlamaNative.nativeFinish(handle)
            }
            out.toString(Charsets.UTF_8.name())
        }

    override fun close() {
        synchronized(lock) {
            if (handle != 0L) {
                LlamaNative.nativeFree(handle)
                handle = 0L
            }
        }
    }
}
