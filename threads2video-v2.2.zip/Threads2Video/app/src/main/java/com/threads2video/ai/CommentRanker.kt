package com.threads2video.ai

import com.threads2video.core.Vn
import com.threads2video.data.CommentRecord
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Xếp hạng bình luận bằng đặc trưng nội dung (xác định, chạy offline, không cần model).
 * - likes chỉ là tín hiệu phụ và chỉ dùng khi API thật sự trả về.
 * - Ý kiến trái chiều KHÔNG bị loại; chỉ loại spam, trùng, rác.
 * - rankScore là điểm NỘI BỘ của Threads2Video, không phải số liệu của Threads.
 */
object CommentRanker {

    private val STOP: Set<String> = setOf(
        "la", "va", "cua", "nhung", "co", "khong", "cho", "cac", "mot", "nay", "do", "thi", "ma", "duoc", "nhieu",
        "rat", "cung", "voi", "em", "anh", "chi", "toi", "minh", "ban", "ay", "lai", "di", "den", "khi", "neu", "vi",
        "nen", "de", "tu", "o", "trong", "ra", "vao", "nua", "hay", "con", "cai", "nguoi", "gi", "sao", "the", "roi",
        "da", "se", "dang", "bi", "phai", "nhu", "tren", "duoi", "qua", "ko", "dc", "k", "r", "z", "j"
    )

    private val SPAM = listOf(
        "inbox", "ib minh", "ib me", "lien he", "zalo", "telegram", "t.me", "kiem tien", "link bio", "xem bio",
        "check bio", "follow back", "f4f", "theo doi lai", "ship cod", "nap tien", "ca cuoc", "casino", "dang ky ngay",
        "click vao", "giam gia soc", "tuyen ctv", "tuyen cong tac vien"
    )
    private val PHONE = Regex("(?:\\+?84|0)[\\s.\\-]?\\d{2,3}[\\s.\\-]?\\d{3}[\\s.\\-]?\\d{3,4}")
    private val URLRE = Regex("(?i)(https?://|www\\.)\\S+")

    private val FUNNY = listOf(
        "haha", "hihi", "hehe", "lol", "cuoi", "xiu", "ba dao", "tau hai", "bat on", "troll", "cuoi bo", "ao that", "hai vl", "hai huoc"
    )
    private val LAUGH_K = Regex("(?<![a-z0-9])k{3,}(?![a-z0-9])")
    private val DRAMA = listOf(
        "nhung", "tuy nhien", "thuc ra", "khong dong y", "sai roi", "sai bet", "cai nhau", "tranh luan", "drama",
        "toxic", "lua", "phan boi", "boc phot", "mat day", "bat cong", "tai sao", "vo ly", "that vong", "to cao",
        "xin loi", "nguoi thu ba", "ngoai tinh", "bi lua", "do loi"
    )
    private val DEEP = listOf(
        "toi tung", "minh tung", "cam thay", "tra qua", "bai hoc", "cuoc song", "y nghia", "that su", "ky niem",
        "thuong", "me toi", "ba toi", "gia dinh", "truong thanh", "mat mat", "hieu ra", "nghi lai", "lon len",
        "doi nguoi", "tinh yeu", "biet on", "nho nhung"
    )

    data class Features(val len: Double, val rel: Double, val funny: Double, val drama: Double, val deep: Double)

    fun spamReason(text: String): String? {
        val f = Vn.fold(text)
        if (URLRE.containsMatchIn(text)) return "Chứa liên kết (nghi spam)"
        if (PHONE.containsMatchIn(text.replace(" ", ""))) return "Chứa số điện thoại (nghi spam)"
        val padded = " " + Vn.tokens(f).joinToString(" ") + " "
        for (s in SPAM) if (padded.contains(" " + s.replace(".", " ") + " ")) return "Nghi spam quảng cáo: \"$s\""
        return null
    }

    fun junkReason(text: String): String? {
        val noEmoji = Vn.stripEmoji(text)
        if (Vn.letterDigitCount(noEmoji) < 2) return "Chỉ có emoji hoặc ký tự rác"
        val toks = Vn.tokens(text)
        if (toks.size >= 4 && toks.toSet().size <= 1) return "Lặp một từ nhiều lần"
        if (Regex("(.)\\1{7,}").containsMatchIn(text)) return "Lặp ký tự bất thường"
        return null
    }

    private fun contentTokens(s: String): Set<String> = Vn.tokens(s).filter { it.length >= 2 && it !in STOP }.toSet()

    private fun jaccard(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val inter = a.count { it in b }
        return inter.toDouble() / (a.size + b.size - inter)
    }

    private fun lenScore(n: Int): Double = when {
        n < 15 -> 0.1
        n < 40 -> 0.1 + 0.7 * (n - 15) / 25.0
        n <= 60 -> 0.9
        n <= 200 -> 1.0
        n <= 260 -> 0.85
        n <= 600 -> 0.8 - 0.4 * (n - 260) / 340.0
        else -> 0.3
    }

    /** Khớp theo từ/cụm từ nguyên vẹn (đệm khoảng trắng) để "hai" không khớp nhầm trong "chai". */
    private fun hits(f: String, list: List<String>): Int {
        val padded = " " + Vn.tokens(f).joinToString(" ") + " "
        return list.count { padded.contains(" $it ") }
    }

    fun features(text: String, topicTokens: Set<String>, postTokens: Set<String>): Features {
        val f = Vn.fold(text)
        val ct = contentTokens(text)
        val n = Vn.stripEmoji(text).trim().length
        val relTopic = if (topicTokens.isEmpty()) 0.0 else min(1.0, ct.count { it in topicTokens }.toDouble() / topicTokens.size)
        val relPost = min(1.0, ct.count { it in postTokens }.toDouble() / 3.0)
        val rel = max(relTopic, relPost * 0.8)
        val laughEmoji = if (Vn.hasLaughEmoji(text)) 1 else 0
        val laughK = if (LAUGH_K.containsMatchIn(f)) 1 else 0
        val funny = min(1.0, 0.35 * (hits(f, FUNNY) + laughK) + (if (n in 5..140) 0.25 else 0.0) + (if (laughEmoji > 0) 0.2 else 0.0) +
            (if (text.contains("!") || text.contains("?")) 0.1 else 0.0))
        val drama = min(1.0, 0.3 * hits(f, DRAMA) + 0.12 * min(3, text.count { it == '?' }) + (if (text.contains("!")) 0.1 else 0.0))
        val deep = min(1.0, 0.5 * min(1.0, n / 200.0) + 0.5 * min(1.0, hits(f, DEEP) / 2.0))
        return Features(lenScore(n), rel, funny, drama, deep)
    }

    private fun critScore(f: Features, c: Criteria): Double = when (c) {
        Criteria.FUNNY -> f.funny
        Criteria.DRAMA -> f.drama
        Criteria.DEEP -> f.deep
        Criteria.MIX -> 0.5 * max(f.funny, max(f.drama, f.deep)) + 0.5 * ((f.funny + f.drama + f.deep) / 3.0)
    }

    private fun reasons(f: Features, c: Criteria, likes: Long?): List<String> {
        val r = ArrayList<String>()
        if (f.len >= 0.85) r += "Độ dài phù hợp để đọc"
        if (f.rel >= 0.34) r += "Liên quan chủ đề/bài gốc"
        if (c == Criteria.FUNNY && f.funny >= 0.4) r += "Có yếu tố hài hước"
        if (c == Criteria.DRAMA && f.drama >= 0.3) r += "Có yếu tố tranh luận/drama"
        if (c == Criteria.DEEP && f.deep >= 0.4) r += "Sâu sắc, dễ đồng cảm"
        if (c == Criteria.MIX) {
            if (f.funny >= 0.5) r += "Có yếu tố hài hước"
            if (f.drama >= 0.4) r += "Có yếu tố tranh luận"
            if (f.deep >= 0.5) r += "Có chiều sâu"
        }
        if (likes != null) r += "Số tim API: $likes (tín hiệu phụ)"
        if (r.isEmpty()) r += "Nội dung bình thường, điểm thấp"
        return r
    }

    /** Điểm nội dung + chỉ báo liên quan, dùng chung cho bài viết và bình luận. */
    fun score(text: String, likes: Long?, c: Criteria, topicTokens: Set<String>, postTokens: Set<String>): Pair<Double, Features> {
        val f = features(text, topicTokens, postTokens)
        val like = if (likes != null && likes > 0) min(1.0, ln(1.0 + likes) / ln(1001.0)) else 0.0
        // Khi người dùng chọn một tiêu chí cụ thể (hài/drama/sâu sắc), tiêu chí phải là yếu tố chi phối;
        // độ dài và độ liên quan chỉ là phụ, nếu không bình luận dài sẽ luôn thắng bình luận đúng tiêu chí.
        val s = if (c == Criteria.MIX) 0.30 * f.len + 0.20 * f.rel + 0.40 * critScore(f, c) + 0.10 * like
        else 0.25 * f.len + 0.15 * f.rel + 0.55 * critScore(f, c) + 0.05 * like
        return Pair(min(1.0, max(0.0, s)), f)
    }

    fun rank(req: RankRequest): RankResult {
        val topicTokens = contentTokens(req.topic)
        val postTokens = contentTokens(req.postText)
        val dropped = ArrayList<Dropped>()
        val kept = ArrayList<CommentRecord>()
        val seenIds = HashSet<String>()
        val seenPermalink = HashSet<String>()
        val keptTokens = ArrayList<Set<String>>()
        val keptKeys = HashSet<String>()

        for (c in req.comments) {
            if (!seenIds.add(c.id)) { dropped += Dropped(c.id, "Trùng ID"); continue }
            val pl = c.sourceUrl
            if (pl != null && !seenPermalink.add(pl)) { dropped += Dropped(c.id, "Trùng permalink"); continue }
            val junk = junkReason(c.rawText)
            if (junk != null) { dropped += Dropped(c.id, junk); continue }
            val spam = spamReason(c.rawText)
            if (spam != null) { dropped += Dropped(c.id, spam); continue }
            val key = Vn.tokens(c.rawText).joinToString(" ")
            val toks = Vn.tokens(c.rawText).toSet()
            if (!keptKeys.add(key) || keptTokens.any { it.size >= 4 && toks.size >= 4 && jaccard(it, toks) >= 0.8 }) {
                dropped += Dropped(c.id, "Trùng nội dung với bình luận khác"); continue
            }
            keptTokens += toks
            kept += c
        }

        val scored = kept.map { c ->
            val (s, f) = score(c.rawText, c.likeCount, req.criteria, topicTokens, postTokens)
            Triple(c, s, f)
        }.sortedWith(compareByDescending<Triple<CommentRecord, Double, Features>> { it.second }.thenBy { it.first.id })

        val ranked = scored.map { (c, s, f) ->
            c.copy(rankScore = s.toFloat(), rankReasons = reasons(f, req.criteria, c.likeCount))
        }

        // Chọn Top N có tránh trùng ý (MMR nhẹ): trừ điểm theo độ giống với bình luận đã chọn.
        val picked = ArrayList<CommentRecord>()
        val pool = ArrayList(ranked)
        val n = min(req.topN, pool.size)
        while (picked.size < n && pool.isNotEmpty()) {
            var bestI = 0
            var bestV = -1.0
            for ((i, c) in pool.withIndex()) {
                val toks = Vn.tokens(c.rawText).toSet()
                val sim = picked.maxOfOrNull { jaccard(toks, Vn.tokens(it.rawText).toSet()) } ?: 0.0
                val v = (c.rankScore ?: 0f).toDouble() - 0.25 * sim
                if (v > bestV) { bestV = v; bestI = i }
            }
            picked += pool.removeAt(bestI)
        }
        return RankResult(ranked, picked.map { it.id }, dropped, "rules")
    }

    fun topicTokens(topic: String) = contentTokens(topic)
}
