package com.threads2video.ai

import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Mô tả một model có thể tải. url/sha256 chỉ điền khi đã đối chiếu với trang model chính thức. */
data class ModelProfile(
    val id: String,
    val label: String,
    val fileName: String,
    val url: String?,
    val sha256: String?,
    val approxBytes: Long?,
    val license: String,
    val note: String
)

data class InstalledModel(val fileName: String, val sizeBytes: Long, val sha256: String?, val verified: Boolean)

class ModelError(val code: String, message: String) : Exception(message)

/** Hai profile đã đối chiếu trên trang Hugging Face của Qwen ngày 2026-11-14 (xem README). */
object ModelCatalog {
    val PROFILES = listOf(
        ModelProfile(
            id = "qwen3-1.7b-q8", label = "Nhẹ — Qwen3 1.7B Q8_0 (~1,8 GB)",
            fileName = "Qwen3-1.7B-Q8_0.gguf",
            url = "https://huggingface.co/Qwen/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q8_0.gguf",
            sha256 = "061b54daade076b5d3362dac252678d17da8c68f07560be70818cace6590cb1a",
            approxBytes = 1_830_000_000L, license = "Apache-2.0",
            note = "Repo chính thức Qwen chỉ có bản Q8_0 cho 1.7B. Cần đo thực tế trên máy."
        ),
        ModelProfile(
            id = "qwen3-4b-q4km", label = "Chất lượng — Qwen3 4B Q4_K_M (~2,5 GB)",
            fileName = "Qwen3-4B-Q4_K_M.gguf",
            url = "https://huggingface.co/Qwen/Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q4_K_M.gguf",
            sha256 = "7485fe6f11af29433bc51cab58009521f205840f5b4ae3a32fa7f92e8534fdf5",
            approxBytes = 2_500_000_000L, license = "Apache-2.0",
            note = "Chưa chắc mượt trên Galaxy A15 8 GB; chỉ dùng sau khi benchmark. Có thể chậm và nóng máy."
        )
    )

    fun byId(id: String) = PROFILES.firstOrNull { it.id == id }
}

/**
 * Quản lý file model GGUF trong vùng riêng của app: tải (có resume/cancel/progress), import từ SAF,
 * kiểm tra SHA-256, kiểm tra dung lượng trống, xóa. Chỉ dùng java.io/java.net (kiểm thử được trên JVM).
 */
class LocalModelManager(
    private val dir: File,
    private val allowInsecureHttp: Boolean = false,
    private val freeSpace: (File) -> Long = { it.usableSpace },
    private val marginBytes: Long = 200L * 1024 * 1024
) {
    init { dir.mkdirs() }

    fun file(name: String) = File(dir, safeName(name))

    private fun safeName(n: String): String {
        val s = n.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[^A-Za-z0-9._\\-]"), "_")
        if (s.isEmpty() || s.startsWith(".")) throw ModelError("bad_name", "Tên file model không hợp lệ")
        return s
    }

    fun installed(): List<InstalledModel> =
        dir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", ignoreCase = true) }
            ?.sortedBy { it.name }
            ?.map { f ->
                val meta = File(dir, f.name + ".sha256")
                val sha = meta.takeIf { it.isFile }?.readText()?.trim()?.takeIf { it.isNotEmpty() }
                InstalledModel(f.name, f.length(), sha, sha != null)
            } ?: emptyList()

    fun partialBytes(name: String): Long = File(dir, safeName(name) + ".part").takeIf { it.isFile }?.length() ?: 0L

    fun delete(name: String): Boolean {
        val f = file(name)
        File(dir, f.name + ".sha256").delete()
        File(dir, f.name + ".part").delete()
        return f.delete()
    }

    fun deleteAll() { dir.listFiles()?.forEach { it.delete() } }

    fun sha256(f: File, cancel: CancelToken? = null): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(1 shl 20)
            while (true) {
                cancel?.check()
                val n = ins.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun requireSpace(need: Long) {
        val free = freeSpace(dir)
        if (free < need + marginBytes) {
            throw ModelError("no_space", "Không đủ dung lượng: cần khoảng ${(need + marginBytes) / 1048576} MB, còn ${free / 1048576} MB.")
        }
    }

    /**
     * Tải về `<fileName>.part` rồi đổi tên khi xong. Hủy giữa chừng giữ nguyên .part để tải tiếp.
     * @param expectedSha256 nếu có, sai checksum → xóa file và báo lỗi.
     */
    fun download(
        url: String, fileName: String, expectedSha256: String?, cancel: CancelToken,
        progress: (done: Long, total: Long) -> Unit
    ): InstalledModel {
        val name = safeName(fileName)
        if (!url.startsWith("https://") && !(allowInsecureHttp && url.startsWith("http://")))
            throw ModelError("insecure", "Chỉ cho phép tải model qua HTTPS.")
        val part = File(dir, "$name.part")
        val final = File(dir, name)
        var have = if (part.isFile) part.length() else 0L

        var conn: HttpURLConnection? = null
        var cur = url
        var redirects = 0
        try {
            while (true) {
                cancel.check()
                val c = URL(cur).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 20000
                c.readTimeout = 30000
                c.setRequestProperty("User-Agent", "Threads2Video")
                if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
                val code = c.responseCode
                if (code in 301..303 || code == 307 || code == 308) {
                    val loc = c.getHeaderField("Location") ?: throw ModelError("net", "Chuyển hướng thiếu Location")
                    c.disconnect()
                    cur = URL(URL(cur), loc).toString()
                    if (!cur.startsWith("https://") && !(allowInsecureHttp && cur.startsWith("http://")))
                        throw ModelError("insecure", "Máy chủ chuyển hướng sang kết nối không an toàn.")
                    if (++redirects > 6) throw ModelError("net", "Quá nhiều lần chuyển hướng")
                    continue
                }
                conn = c
                break
            }
            val c = conn!!
            val code = c.responseCode
            if (code == 416) {
                // đã có đủ (hoặc .part lỗi): thử xác minh file hiện có
                c.disconnect()
                if (part.isFile && part.length() > 0) { part.renameTo(final) } else throw ModelError("net", "Máy chủ từ chối tải tiếp (416)")
            } else {
                if (code != 200 && code != 206) throw ModelError("http_$code", "Máy chủ trả mã $code khi tải model")
                val resumed = code == 206 && have > 0
                if (!resumed) have = 0L
                val remaining = c.getHeaderFieldLong("Content-Length", -1L)
                val total = if (remaining >= 0) remaining + have else -1L
                if (total > 0) requireSpace(total - have)
                RandomAccessFile(part, "rw").use { raf ->
                    if (resumed) raf.seek(have) else raf.setLength(0)
                    c.inputStream.use { ins ->
                        val buf = ByteArray(1 shl 16)
                        var done = have
                        var lastReport = 0L
                        while (true) {
                            cancel.check()
                            val n = ins.read(buf)
                            if (n < 0) break
                            raf.write(buf, 0, n)
                            done += n
                            val now = System.nanoTime()
                            if (now - lastReport > 200_000_000L) { lastReport = now; progress(done, total) }
                        }
                        progress(done, total)
                        if (total > 0 && done != total) throw ModelError("incomplete", "Tải chưa đủ (${done}/${total}). Bấm tải lại để tiếp tục.")
                    }
                }
                if (final.exists()) final.delete()
                if (!part.renameTo(final)) throw ModelError("io", "Không đổi tên được file model")
            }
        } catch (e: AiCancelled) {
            throw e
        } catch (e: ModelError) {
            throw e
        } catch (e: IOException) {
            throw ModelError("net", "Lỗi mạng khi tải model (" + (e.message ?: "IO") + "). File dở được giữ để tải tiếp.")
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
        return finalize(final, expectedSha256, cancel)
    }

    /** Import từ luồng đọc (SAF). */
    fun import(
        input: InputStream, fileName: String, totalBytes: Long, expectedSha256: String?, cancel: CancelToken,
        progress: (done: Long, total: Long) -> Unit
    ): InstalledModel {
        val name = safeName(fileName)
        if (!name.endsWith(".gguf", ignoreCase = true)) throw ModelError("not_gguf", "Chỉ nhận file .gguf")
        if (totalBytes > 0) requireSpace(totalBytes)
        val tmp = File(dir, "$name.part")
        try {
            tmp.outputStream().use { out ->
                val buf = ByteArray(1 shl 18)
                var done = 0L
                while (true) {
                    cancel.check()
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    progress(done, totalBytes)
                }
            }
        } catch (e: AiCancelled) {
            tmp.delete(); throw e
        } catch (e: IOException) {
            tmp.delete()
            throw ModelError("io", "Không chép được file model (" + (e.message ?: "IO") + "). Kiểm tra dung lượng.")
        }
        val final = File(dir, name)
        if (final.exists()) final.delete()
        if (!tmp.renameTo(final)) throw ModelError("io", "Không đổi tên được file model")
        return finalize(final, expectedSha256, cancel)
    }

    private fun finalize(f: File, expected: String?, cancel: CancelToken): InstalledModel {
        // magic "GGUF" để phát hiện file sai định dạng
        val magic = ByteArray(4)
        f.inputStream().use { it.read(magic) }
        if (String(magic, Charsets.ISO_8859_1) != "GGUF") {
            f.delete()
            throw ModelError("not_gguf", "File tải về không phải định dạng GGUF.")
        }
        val sha = sha256(f, cancel)
        if (expected != null && !expected.equals(sha, ignoreCase = true)) {
            f.delete()
            throw ModelError("sha_mismatch", "Sai checksum SHA-256 (nhận $sha). File đã bị xóa; không dùng model không xác minh được.")
        }
        // "verified" chỉ true nếu đã đối chiếu với checksum kỳ vọng; file không có checksum thì không ghi .sha256
        if (expected != null) File(dir, f.name + ".sha256").writeText(sha, Charsets.UTF_8)
        else File(dir, f.name + ".sha256").delete()
        return InstalledModel(f.name, f.length(), sha, expected != null)
    }
}
