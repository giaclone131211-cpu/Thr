package com.threads2video.ai

import com.threads2video.data.CommentRecord
import com.threads2video.data.PostRecord

enum class Criteria {
    MIX, FUNNY, DRAMA, DEEP;

    companion object {
        fun parse(s: String?): Criteria = when (s?.lowercase()) {
            "funny" -> FUNNY
            "drama" -> DRAMA
            "deep" -> DEEP
            else -> MIX
        }
    }
}

/** Hủy tác vụ AI từ luồng khác. */
class CancelToken {
    @Volatile var cancelled = false
        private set
    fun cancel() { cancelled = true }
    fun check() { if (cancelled) throw AiCancelled() }
}

class AiCancelled : RuntimeException("Đã hủy tác vụ AI")

class AiUnavailable(msg: String) : RuntimeException(msg)

data class RankRequest(
    val topic: String,
    val postText: String,
    val comments: List<CommentRecord>,
    val criteria: Criteria,
    val topN: Int
)

data class Dropped(val id: String, val reason: String)

data class RankResult(
    /** Mọi bình luận hợp lệ, đã gán rankScore/rankReasons, sắp xếp giảm dần. */
    val ranked: List<CommentRecord>,
    /** id các bình luận được chọn vào Top N, theo thứ tự xếp hạng. */
    val topIds: List<String>,
    val dropped: List<Dropped>,
    val engine: String
)

data class TtsInput(val id: String, val rawText: String)

data class TtsOutput(
    val id: String,
    val ttsText: String,
    val needsManualReview: Boolean,
    val flags: List<String>,
    val engine: String
)

data class EngineInfo(
    /** "rules" (không cần model) hoặc "llm" (đang dùng model GGUF cục bộ). */
    val kind: String,
    val modelName: String?,
    val ready: Boolean,
    val note: String
)

/**
 * Giao diện AI cục bộ. UI/bridge chỉ phụ thuộc vào interface này, không biết JNI.
 * Mọi hàm chạy ở luồng nền và phải tôn trọng [CancelToken].
 */
interface LocalAiEngine {
    fun info(): EngineInfo
    fun rankPosts(topic: String, posts: List<PostRecord>, cancel: CancelToken): List<PostRecord>
    fun rankComments(req: RankRequest, cancel: CancelToken): RankResult
    fun normalizeTts(items: List<TtsInput>, cancel: CancelToken): List<TtsOutput>
    fun caption(postText: String, commentTexts: List<String>, cancel: CancelToken): String
    /** Giải phóng bộ nhớ model (trước khi dựng/export video). */
    fun release()
}
