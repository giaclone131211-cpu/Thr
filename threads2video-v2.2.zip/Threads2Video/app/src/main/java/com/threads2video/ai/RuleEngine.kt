package com.threads2video.ai

import com.threads2video.core.Vn
import com.threads2video.data.PostRecord
import kotlin.math.min

/** Engine không cần model: luôn sẵn sàng, xác định, chạy offline. */
class RuleEngine : LocalAiEngine {

    override fun info() = EngineInfo(
        "rules", null, true,
        "Đang dùng luật xác định (không cần model). Cài model GGUF để AI cục bộ hiểu ngữ cảnh tốt hơn."
    )

    override fun rankPosts(topic: String, posts: List<PostRecord>, cancel: CancelToken): List<PostRecord> {
        val tt = CommentRanker.topicTokens(topic)
        val seen = HashSet<String>()
        val out = ArrayList<PostRecord>()
        for (p in posts) {
            cancel.check()
            if (!seen.add(p.id)) continue
            val n = Vn.collapseSpaces(Vn.stripEmoji(p.rawText)).length
            if (n < 30) continue                       // quá ngắn, không đủ ngữ cảnh để kể
            if (CommentRanker.spamReason(p.rawText) != null) continue
            if (p.isReply == true) continue            // chỉ lấy bài gốc, không lấy reply
            val (s, f) = CommentRanker.score(p.rawText, p.likeCount, Criteria.MIX, tt, emptySet())
            val reasons = ArrayList<String>()
            if (f.rel >= 0.34) reasons += "Khớp chủ đề"
            if (f.len >= 0.85) reasons += "Đủ ngữ cảnh để kể chuyện"
            if (p.hasReplies == true) reasons += "Có bình luận"
            out += p.copy(
                relevanceScore = (s + (if (p.hasReplies == true) 0.1 else 0.0) + 0.3 * f.rel).toFloat(),
                rankReasons = if (reasons.isEmpty()) listOf("Phù hợp mức thấp") else reasons
            )
        }
        // loại trùng permalink + trùng nội dung gần giống
        val uniq = ArrayList<PostRecord>()
        val keys = HashSet<String>()
        for (p in out.sortedByDescending { it.relevanceScore ?: 0f }) {
            val k = Vn.tokens(p.rawText).take(24).joinToString(" ")
            if (keys.add(k) && (p.sourceUrl == null || keys.add(p.sourceUrl))) uniq += p
        }
        return uniq
    }

    override fun rankComments(req: RankRequest, cancel: CancelToken): RankResult {
        cancel.check()
        return CommentRanker.rank(req)
    }

    override fun normalizeTts(items: List<TtsInput>, cancel: CancelToken): List<TtsOutput> =
        items.map {
            cancel.check()
            val r = TtsTextNormalizer.normalize(it.rawText)
            TtsOutput(it.id, r.text, r.needsReview, r.flags, "rules")
        }

    override fun caption(postText: String, commentTexts: List<String>, cancel: CancelToken): String {
        val first = Vn.collapseSpaces(Vn.stripEmoji(postText))
        val hook = if (first.length <= 90) first else first.substring(0, 87).trimEnd() + "…"
        val tags = LinkedHashSet<String>()
        Vn.tokens(first).filter { it.length >= 4 }.take(2).forEach { tags += "#$it" }
        tags += listOf("#threads", "#tamsu", "#xuhuong", "#fyp", "#tiktokvietnam")
        return "$hook\nBạn nghĩ sao? Để lại bình luận nhé!\n" + tags.take(7).joinToString(" ") +
            "\n(Caption mẫu tạo bằng luật, chưa dùng AI. Hãy chỉnh lại.)"
    }

    override fun release() {}
}
