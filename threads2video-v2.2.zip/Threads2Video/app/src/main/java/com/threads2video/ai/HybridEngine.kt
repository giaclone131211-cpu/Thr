package com.threads2video.ai

import com.threads2video.core.Json
import com.threads2video.core.Vn
import com.threads2video.core.bool
import com.threads2video.core.dbl
import com.threads2video.core.long
import com.threads2video.core.str
import com.threads2video.data.CommentRecord
import com.threads2video.data.PostRecord
import kotlin.math.min

/** Backend suy luận (llama.cpp qua JNI, hoặc bản giả khi test). */
interface LlmBackend {
    val modelName: String
    fun complete(system: String, user: String, maxTokens: Int, cancel: CancelToken): String
    fun close()
}

/** Kiểm tra đầu ra của model trước khi tin: model nhỏ hay bịa/đảo nghĩa. */
object TtsGuard {
    private val NEG = setOf("khong", "chang", "chua", "dung", "cha", "hong")
    private val DIGITS = Regex("\\d+")

    class Parsed(val text: String, val unsure: Boolean, val why: String)

    fun stripThink(s: String): String = s.replace(Regex("(?s)<think>.*?</think>"), "").trim()

    fun parse(out: String): Parsed? {
        val s = stripThink(out)
        val a = s.indexOf('{')
        val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try {
            val m = Json.parseObject(s.substring(a, b + 1))
            val t = m.str("t") ?: return null
            Parsed(t.trim(), m.bool("unsure") ?: false, (m.str("why") ?: "").take(120))
        } catch (e: Exception) {
            null
        }
    }

    /** Trả về null nếu chấp nhận, hoặc lý do từ chối. */
    fun check(raw: String, baseline: String, cand: String): String? {
        val c = cand.trim()
        if (c.isEmpty()) return "đầu ra rỗng"
        if (Vn.hasEmoji(c)) return "còn emoji"
        val fc = Vn.fold(c)
        if (fc.startsWith("day la") || fc.startsWith("ket qua") || fc.startsWith("van ban da")) return "có lời dẫn thừa"
        val bl = Vn.fold(baseline).length
        val cl = fc.length
        if (bl >= 20) {
            val ratio = cl.toDouble() / bl
            if (ratio < 0.5 || ratio > 1.8) return "độ dài lệch quá nhiều"
        } else if (kotlin.math.abs(cl - bl) > 25) return "độ dài lệch quá nhiều"

        val baseNums = DIGITS.findAll(baseline).map { it.value }.toSet()
        val rawNums = DIGITS.findAll(raw).map { it.value }.toSet()
        for (n in DIGITS.findAll(c).map { it.value }) if (n !in baseNums && n !in rawNums) return "xuất hiện số không có trong bản gốc"

        val bt = Vn.tokens(baseline)
        val ct = Vn.tokens(c)
        val bn = bt.count { it in NEG }
        val cn = ct.count { it in NEG }
        if (bn > 0 && cn == 0) return "mất từ phủ định"
        if (cn > bn) return "thêm từ phủ định"

        val bs = bt.filter { it.length >= 2 }.toSet()
        val cs = ct.filter { it.length >= 2 }.toSet()
        if (bs.isNotEmpty()) {
            val keep = bs.count { it in cs }.toDouble() / bs.size
            if (keep < 0.6) return "bỏ mất quá nhiều nội dung"
        }
        if (cs.isNotEmpty()) {
            val novel = cs.count { it !in bs }.toDouble() / cs.size
            if (novel > 0.4) return "thêm quá nhiều từ mới"
        }
        return null
    }
}

/**
 * Engine thật: luật xác định làm nền; nếu có model thì dùng model nhưng mọi đầu ra đều qua [TtsGuard]
 * hoặc kiểm tra cấu trúc. Khi model hỏng/không chắc → dùng luật và gắn cờ xem lại. Không bao giờ bịa kết quả.
 */
class HybridEngine(
    private val rules: RuleEngine = RuleEngine(),
    private val backend: () -> LlmBackend?
) : LocalAiEngine {

    override fun info(): EngineInfo {
        val b = backend()
        return if (b == null) rules.info()
        else EngineInfo("llm", b.modelName, true, "Đang dùng model cục bộ ${b.modelName} (có kiểm tra đầu ra bằng luật).")
    }

    override fun rankPosts(topic: String, posts: List<PostRecord>, cancel: CancelToken) = rules.rankPosts(topic, posts, cancel)

    override fun rankComments(req: RankRequest, cancel: CancelToken): RankResult {
        val base = rules.rankComments(req, cancel)
        val b = backend() ?: return base
        val pool = base.ranked.take(24)
        if (pool.size < 3) return base
        return try {
            cancel.check()
            val out = b.complete(
                PromptTemplates.RANK_SYSTEM,
                PromptTemplates.rankUser(req.criteria, req.topic, req.postText, pool.map { it.rawText }),
                60 + pool.size * 40, cancel
            )
            val scores = parseRank(out, pool.size) ?: return base
            val blended = pool.mapIndexed { i, c ->
                val s = scores[i + 1]
                if (s == null) c else {
                    val r = (c.rankScore ?: 0f) * 0.5f + (s.first / 10.0).toFloat() * 0.5f
                    c.copy(rankScore = r, rankReasons = c.rankReasons + (if (s.second.isNotBlank()) listOf("Model: " + s.second) else emptyList()))
                }
            } + base.ranked.drop(pool.size)
            val sorted = blended.sortedWith(compareByDescending<CommentRecord> { it.rankScore ?: 0f }.thenBy { it.id })
            RankResult(sorted, sorted.take(min(req.topN, sorted.size)).map { it.id }, base.dropped, "llm+rules")
        } catch (e: AiCancelled) {
            throw e
        } catch (e: Exception) {
            base
        }
    }

    /** index(1-based) → (điểm 0..10, lý do); null nếu đầu ra không dùng được. */
    internal fun parseRank(out: String, n: Int): Map<Int, Pair<Double, String>>? {
        val s = TtsGuard.stripThink(out)
        val a = s.indexOf('[')
        val b = s.lastIndexOf(']')
        if (a < 0 || b <= a) return null
        val arr = try { Json.asList(Json.parse(s.substring(a, b + 1))) } catch (e: Exception) { null } ?: return null
        val m = HashMap<Int, Pair<Double, String>>()
        for (x in arr) {
            val o = Json.asMap(x) ?: continue
            val i = o.long("i")?.toInt() ?: continue
            val sc = o.dbl("s") ?: continue
            if (i !in 1..n || sc < 0.0 || sc > 10.0) continue
            val r = (o.str("r") ?: "").replace(Regex("[\\p{Cntrl}]"), " ").trim().take(60)
            m.putIfAbsent(i, Pair(sc, r))
        }
        return if (m.size >= (n * 0.7).toInt().coerceAtLeast(2)) m else null
    }

    override fun normalizeTts(items: List<TtsInput>, cancel: CancelToken): List<TtsOutput> {
        val b = backend()
        return items.map { it0 ->
            cancel.check()
            val base = TtsTextNormalizer.normalize(it0.rawText)
            if (b == null) return@map TtsOutput(it0.id, base.text, base.needsReview, base.flags, "rules")
            try {
                val out = b.complete(
                    PromptTemplates.TTS_SYSTEM, PromptTemplates.ttsUser(it0.rawText, base.text),
                    min(400, 80 + it0.rawText.length), cancel
                )
                val p = TtsGuard.parse(out)
                val why = if (p == null) "đầu ra không phải JSON hợp lệ" else TtsGuard.check(it0.rawText, base.text, p.text)
                if (p != null && why == null) {
                    var t = Vn.collapseSpaces(p.text)
                    if (!Regex("[.!?…]$").containsMatchIn(t)) t += "."
                    val flags = base.flags + (if (p.unsure) listOf("Model chưa chắc" + (if (p.why.isNotBlank()) ": " + p.why else "")) else emptyList())
                    TtsOutput(it0.id, t, flags.isNotEmpty(), flags, "llm")
                } else {
                    val flags = base.flags + "Bản của model bị từ chối ($why), dùng bản luật. Hãy kiểm tra."
                    TtsOutput(it0.id, base.text, true, flags, "rules")
                }
            } catch (e: AiCancelled) {
                throw e
            } catch (e: Exception) {
                TtsOutput(it0.id, base.text, true, base.flags + "Model lỗi (${e.message?.take(80)}), dùng bản luật. Hãy kiểm tra.", "rules")
            }
        }
    }

    override fun caption(postText: String, commentTexts: List<String>, cancel: CancelToken): String {
        val b = backend() ?: return rules.caption(postText, commentTexts, cancel)
        return try {
            val t = TtsGuard.stripThink(b.complete(PromptTemplates.CAPTION_SYSTEM, PromptTemplates.captionUser(postText, commentTexts), 220, cancel))
            if (t.isBlank()) rules.caption(postText, commentTexts, cancel) else t.trim()
        } catch (e: AiCancelled) {
            throw e
        } catch (e: Exception) {
            rules.caption(postText, commentTexts, cancel)
        }
    }

    /** Vòng đời model do LocalAiService quản lý (nạp/đóng); engine không tự đóng. */
    override fun release() {}
}
