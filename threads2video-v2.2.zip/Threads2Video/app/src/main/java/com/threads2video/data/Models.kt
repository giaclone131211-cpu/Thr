package com.threads2video.data

import com.threads2video.core.Json
import com.threads2video.core.bool
import com.threads2video.core.dbl
import com.threads2video.core.long
import com.threads2video.core.str

/** Bài nguồn (từ Threads API hoặc nhập thủ công). `rawText` bất biến. */
data class PostRecord(
    val id: String,
    val sourceUrl: String?,
    val authorUsername: String?,
    val rawText: String,
    val createdAt: String?,
    val likeCount: Long?,
    val hasReplies: Boolean?,
    val isReply: Boolean?,
    val relevanceScore: Float?,
    val rankReasons: List<String>,
    val origin: String = ORIGIN_API
) {
    fun toMap(): Map<String, Any?> = linkedMapOf(
        "id" to id, "sourceUrl" to sourceUrl, "authorUsername" to authorUsername, "rawText" to rawText,
        "createdAt" to createdAt, "likeCount" to likeCount, "hasReplies" to hasReplies, "isReply" to isReply,
        "relevanceScore" to relevanceScore?.toDouble(), "rankReasons" to rankReasons, "origin" to origin
    )

    companion object {
        const val ORIGIN_API = "api"
        const val ORIGIN_MANUAL = "manual"

        fun fromMap(m: Map<String, Any?>): PostRecord? {
            val id = m.str("id") ?: return null
            val raw = m.str("rawText") ?: return null
            return PostRecord(
                id, m.str("sourceUrl"), m.str("authorUsername"), raw, m.str("createdAt"), m.long("likeCount"),
                m.bool("hasReplies"), m.bool("isReply"), m.dbl("relevanceScore")?.toFloat(),
                Json.asList(m["rankReasons"])?.mapNotNull { it as? String } ?: emptyList(),
                m.str("origin") ?: ORIGIN_API
            )
        }
    }
}

/**
 * Bình luận. Ngữ nghĩa theo đặc tả: `rawText` KHÔNG BAO GIỜ bị sửa; `ttsText` là bản riêng để đọc.
 * Các field tương tác (likeCount, createdAt, authorUsername) là null nếu API không trả về.
 */
data class CommentRecord(
    val id: String,
    val sourcePostId: String,
    val sourceUrl: String?,
    val authorUsername: String?,
    val rawText: String,
    val ttsText: String?,
    val likeCount: Long?,
    val createdAt: String?,
    val rankScore: Float?,
    val rankReasons: List<String>,
    val cardImageUri: String?,
    val ocrRequired: Boolean,
    val needsManualReview: Boolean,
    val approvedForVideo: Boolean,
    val origin: String = PostRecord.ORIGIN_API
) {
    /** Chỉ đổi ttsText; rawText giữ nguyên tuyệt đối. */
    fun withTts(tts: String?, review: Boolean) = copy(ttsText = tts, needsManualReview = review)

    fun toMap(): Map<String, Any?> = linkedMapOf(
        "id" to id, "sourcePostId" to sourcePostId, "sourceUrl" to sourceUrl, "authorUsername" to authorUsername,
        "rawText" to rawText, "ttsText" to ttsText, "likeCount" to likeCount, "createdAt" to createdAt,
        "rankScore" to rankScore?.toDouble(), "rankReasons" to rankReasons, "cardImageUri" to cardImageUri,
        "ocrRequired" to ocrRequired, "needsManualReview" to needsManualReview,
        "approvedForVideo" to approvedForVideo, "origin" to origin
    )

    companion object {
        fun fromMap(m: Map<String, Any?>): CommentRecord? {
            val id = m.str("id") ?: return null
            val raw = m.str("rawText") ?: return null
            return CommentRecord(
                id, m.str("sourcePostId") ?: "", m.str("sourceUrl"), m.str("authorUsername"), raw, m.str("ttsText"),
                m.long("likeCount"), m.str("createdAt"), m.dbl("rankScore")?.toFloat(),
                Json.asList(m["rankReasons"])?.mapNotNull { it as? String } ?: emptyList(),
                m.str("cardImageUri"), m.bool("ocrRequired") ?: false, m.bool("needsManualReview") ?: false,
                m.bool("approvedForVideo") ?: false, m.str("origin") ?: PostRecord.ORIGIN_API
            )
        }
    }
}
