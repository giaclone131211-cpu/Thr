package com.threads2video.data.local

import java.io.File

/**
 * Lưu trạng thái workflow (chủ đề, bài nguồn, danh sách, trạng thái duyệt) trong vùng riêng của app.
 * Ghi nguyên tử (file tạm rồi đổi tên) để không hỏng dữ liệu nếu app bị tắt giữa chừng.
 * Chỉ lưu dữ liệu cần thiết; có thể xóa một project hoặc toàn bộ.
 */
class ProjectStore(private val root: File) {
    private val dir get() = File(root, "projects").also { it.mkdirs() }

    private fun safe(id: String): String = id.replace(Regex("[^A-Za-z0-9_\\-]"), "_").take(64).ifEmpty { "default" }

    fun file(id: String) = File(dir, safe(id) + ".json")

    fun save(id: String, json: String) {
        val f = file(id)
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(json, Charsets.UTF_8)
        if (!tmp.renameTo(f)) {
            f.delete()
            if (!tmp.renameTo(f)) throw java.io.IOException("Không lưu được project")
        }
    }

    fun load(id: String): String? = file(id).takeIf { it.isFile }?.readText(Charsets.UTF_8)

    fun list(): List<String> = dir.listFiles { x -> x.name.endsWith(".json") }?.map { it.name.removeSuffix(".json") }?.sorted() ?: emptyList()

    fun delete(id: String): Boolean = file(id).delete()

    fun deleteAll() { dir.listFiles()?.forEach { it.delete() } }
}

/** Lưu ảnh card theo ID bình luận (không theo thứ tự, nên đổi thứ tự không đảo ảnh). */
class CardStore(private val root: File) {
    val dir get() = File(root, "cards").also { it.mkdirs() }

    fun safeName(id: String): String = id.replace(Regex("[^A-Za-z0-9_\\-]"), "_").take(80).ifEmpty { "card" }

    fun file(id: String) = File(dir, safeName(id) + ".png")

    fun save(id: String, png: ByteArray): File {
        if (png.size < 8 || png[0] != 0x89.toByte() || png[1] != 'P'.code.toByte() || png[2] != 'N'.code.toByte() || png[3] != 'G'.code.toByte())
            throw IllegalArgumentException("Dữ liệu không phải PNG")
        val f = file(id)
        val tmp = File(dir, f.name + ".tmp")
        tmp.writeBytes(png)
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        return f
    }

    fun delete(id: String) = file(id).delete()
    fun deleteAll() { dir.listFiles()?.forEach { it.delete() } }
}
