package com.threads2video.ai

import java.io.File

/**
 * Vòng đời model cục bộ: nạp tuần tự (tối đa MỘT model), kiểm tra RAM trước khi nạp, giải phóng khi cần
 * (trước dựng/export video). Nếu chưa có model hoặc bản APK không kèm llama.cpp thì engine tự dùng luật xác định.
 */
class AiService(
    private val models: LocalModelManager,
    private val availMemBytes: () -> Long,
    private val cpuCores: Int,
    private val opener: (path: String, name: String, nCtx: Int, threads: Int) -> LlmBackend =
        { p, n, c, t -> LlamaBackend.open(p, n, c, t) }
) {
    @Volatile private var backend: LlmBackend? = null
    @Volatile private var loadedFile: String? = null
    private val lock = Any()

    val engine: LocalAiEngine = HybridEngine { backend }

    companion object {
        /** Ngữ cảnh đủ cho một bình luận + prompt; không cần lớn hơn (tiết kiệm RAM KV-cache). */
        fun nCtxFor(fileName: String) = if (fileName.contains("4B", ignoreCase = true)) 3072 else 2048
        /** Hệ số ước lượng RAM cần = kích thước file × 1,25 + 500 MB (KV-cache, buffer). Chỉ là ngưỡng bảo vệ, chưa benchmark. */
        const val RAM_FACTOR = 1.25
        const val RAM_EXTRA = 500L * 1024 * 1024
    }

    fun status(): Map<String, Any?> {
        val i = engine.info()
        return linkedMapOf(
            "kind" to i.kind, "modelName" to i.modelName, "ready" to i.ready, "note" to i.note,
            "loadedFile" to loadedFile, "nativeAvailable" to LlamaNative.available()
        )
    }

    /** Nạp model đã cài. Ném AiUnavailable với hướng dẫn rõ nếu thiếu RAM / thiếu runtime / file hỏng. */
    fun load(fileName: String) {
        synchronized(lock) {
            val inst = models.installed().firstOrNull { it.fileName == fileName }
                ?: throw AiUnavailable("Chưa cài model “$fileName”. Hãy tải hoặc nhập file trong phần Model AI.")
            val need = (inst.sizeBytes * RAM_FACTOR).toLong() + RAM_EXTRA
            val avail = availMemBytes()
            if (avail in 1 until need) {
                throw AiUnavailable(
                    "Không đủ RAM trống để nạp model (cần ~${need / 1048576} MB, còn ${avail / 1048576} MB). " +
                        "Hãy đóng bớt ứng dụng hoặc chọn model nhẹ hơn."
                )
            }
            unloadLocked()
            val cores = cpuCores.coerceIn(2, 8)
            val b = opener(models.file(fileName).absolutePath, fileName, nCtxFor(fileName), (cores - 2).coerceIn(2, 4))
            backend = b
            loadedFile = fileName
        }
    }

    fun unload() { synchronized(lock) { unloadLocked() } }

    private fun unloadLocked() {
        try { backend?.close() } catch (_: Exception) {}
        backend = null
        loadedFile = null
    }

    /** Gọi trước khi dựng/export video để trả RAM. Không ném lỗi. */
    fun releaseForExport() { unload() }

    fun isLoaded(file: String) = loadedFile == file

    fun modelFile(name: String): File = models.file(name)
}
