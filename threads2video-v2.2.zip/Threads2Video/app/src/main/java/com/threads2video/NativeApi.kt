package com.threads2video

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.StatFs
import android.provider.OpenableColumns
import com.threads2video.ai.AiService
import com.threads2video.ai.LocalModelManager
import com.threads2video.bridge.NativeDispatcher
import com.threads2video.bridge.Platform
import com.threads2video.core.Json
import com.threads2video.data.local.CardStore
import com.threads2video.data.local.PrefsConfigStore
import com.threads2video.data.local.PrefsPendingStore
import com.threads2video.data.local.ProjectStore
import com.threads2video.data.local.SecureTokenStore
import com.threads2video.data.threads.ThreadsApiClient
import com.threads2video.data.threads.ThreadsOAuth
import com.threads2video.data.threads.UrlConnectionTransport
import java.io.File
import java.util.concurrent.Executors

/**
 * Lớp Android của cầu nối: tạo [NativeDispatcher], chạy lệnh ở luồng nền và trả kết quả về JS qua
 * window.__native(id, ok, json) / window.__nativeEvent(name, json). Mọi logic nghiệp vụ nằm trong NativeDispatcher.
 * `runJs` phải tự chuyển sang luồng UI.
 */
class NativeApi(private val activity: MainActivity, private val runJs: (String) -> Unit) {

    private val appCtx: Context = activity.applicationContext

    private val platform = object : Platform {
        override fun sysInfo(): Map<String, Any?> {
            val mi = ActivityManager.MemoryInfo()
            (appCtx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            return linkedMapOf(
                "totalMemBytes" to mi.totalMem, "availMemBytes" to mi.availMem, "lowMemory" to mi.lowMemory,
                "cores" to Runtime.getRuntime().availableProcessors(), "sdk" to Build.VERSION.SDK_INT,
                "model" to Build.MODEL, "abis" to Build.SUPPORTED_ABIS.toList()
            )
        }

        override fun availMemBytes(): Long {
            val mi = ActivityManager.MemoryInfo()
            (appCtx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            return mi.availMem
        }

        override fun freeDiskBytes(): Long = try { StatFs(appCtx.filesDir.path).availableBytes } catch (_: Exception) { 0L }

        override fun openBrowser(url: String) {
            activity.runOnUiThread {
                try {
                    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {
                    emit("auth.result", mapOf("ok" to false, "error" to mapOf("code" to "no_browser", "message" to "Không mở được trình duyệt để đăng nhập.")))
                }
            }
        }

        override fun pickModelFile() { activity.runOnUiThread { activity.launchModelPicker() } }

        override fun cardUri(commentId: String, version: Long): String =
            "https://appassets.androidplatform.net/cards/" + cards.safeName(commentId) + ".png?v=" + version
    }

    private val tokenStore = SecureTokenStore(appCtx)
    private val configStore = PrefsConfigStore(appCtx)
    private val oauth = ThreadsOAuth(configStore, tokenStore, PrefsPendingStore(appCtx), UrlConnectionTransport())
    private val api = ThreadsApiClient(UrlConnectionTransport(), { oauth.freshToken() })
    private val models = LocalModelManager(File(appCtx.filesDir, "models"))
    private val cards = CardStore(appCtx.filesDir)
    private val ai = AiService(models, { platform.availMemBytes() }, Runtime.getRuntime().availableProcessors())

    private val dispatcher = NativeDispatcher(
        platform, oauth, configStore, tokenStore, api, ai, models, ProjectStore(appCtx.filesDir), cards
    ) { event, payload -> emit(event, payload) }

    private val pool = Executors.newFixedThreadPool(3) { r -> Thread(r, "t2v-native").also { it.isDaemon = true } }

    private fun emit(event: String, payload: Map<String, Any?>) {
        runJs("window.__nativeEvent && window.__nativeEvent(" + quote(event) + "," + quote(Json.stringify(payload)) + ")")
    }

    /** JS → Kotlin: trả ngay, kết quả đến sau qua window.__native. */
    fun submit(id: String, name: String, argsJson: String) {
        pool.execute {
            val (ok, json) = dispatcher.invoke(name, argsJson)
            runJs("window.__native(" + quote(id) + "," + ok + "," + quote(json) + ")")
        }
    }

    /** Deep link threads2video://oauth?ticket=…&state=… (hoặc error=…). */
    fun finishAuth(uri: Uri) {
        val params = HashMap<String, String>()
        for (k in uri.queryParameterNames) uri.getQueryParameter(k)?.let { params[k] = it }
        pool.execute { dispatcher.finishAuth(params) }
    }

    fun importModel(uri: Uri) {
        pool.execute {
            var name = "model.gguf"
            var size = -1L
            try {
                appCtx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) name = c.getString(ni) ?: name
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
                val ins = appCtx.contentResolver.openInputStream(uri)
                if (ins == null) {
                    emit("model.done", mapOf("ok" to false, "error" to mapOf("code" to "model_io", "message" to "Không đọc được file đã chọn.")))
                } else ins.use { dispatcher.importModel(it, name, size) }
            } catch (e: Exception) {
                emit("model.done", mapOf("ok" to false, "error" to mapOf("code" to "model_io", "message" to "Không đọc được file đã chọn.")))
            }
        }
    }

    /** Giải phóng model khi Activity bị hủy. */
    fun shutdown() { try { ai.unload() } catch (_: Exception) {}; pool.shutdownNow() }

    private fun quote(s: String): String = org.json.JSONObject.quote(s)
}
