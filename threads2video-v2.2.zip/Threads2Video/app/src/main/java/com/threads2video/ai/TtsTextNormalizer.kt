package com.threads2video.ai

import com.threads2video.core.Vn

/**
 * Chuẩn hóa văn bản cho giọng đọc bằng luật xác định (không cần model).
 * Nguyên tắc: chỉ biến đổi những gì chắc chắn; từ không chắc thì để nguyên và gắn cờ xem lại.
 * Không bao giờ sửa rawText — hàm chỉ trả về bản mới.
 */
object TtsTextNormalizer {

    data class Result(
        val text: String,
        val flags: List<String>,
        val changes: List<String>
    ) {
        val needsReview: Boolean get() = flags.isNotEmpty()
    }

    /** Viết tắt/teencode không mơ hồ. */
    private val DICT: Map<String, String> = mapOf(
        "ko" to "không", "k" to "không", "hok" to "không", "hông" to "không", "hổng" to "không", "kg" to "ký",
        "dc" to "được", "đc" to "được", "đuợc" to "được", "dduoc" to "được",
        "vs" to "với", "vk" to "vợ", "ck" to "chồng", "ae" to "anh em", "mn" to "mọi người",
        "j" to "gì", "z" to "vậy", "zậy" to "vậy", "zạ" to "vậy", "zay" to "vậy",
        "r" to "rồi", "rùi" to "rồi", "roài" to "rồi",
        "wa" to "quá", "wá" to "quá", "qá" to "quá",
        "ntn" to "như thế nào", "nv" to "như vậy", "nvay" to "như vậy",
        "cx" to "cũng", "cg" to "cũng", "trc" to "trước",
        "sdt" to "số điện thoại", "kb" to "kết bạn",
        "thik" to "thích", "thix" to "thích", "iu" to "yêu", "bik" to "biết", "bít" to "biết",
        "mik" to "mình", "mjh" to "mình",
        "ny" to "người yêu", "nyc" to "người yêu cũ",
        "cmt" to "bình luận", "cmts" to "bình luận",
        "ib" to "nhắn tin", "bth" to "bình thường",
        "oke" to "ok", "okie" to "ok", "okla" to "ok",
        "tks" to "cảm ơn", "thks" to "cảm ơn",
        "hnay" to "hôm nay", "hqua" to "hôm qua", "ngta" to "người ta", "bjo" to "bao giờ",
        "dthw" to "dễ thương", "gđ" to "gia đình", "tgian" to "thời gian", "ctrinh" to "chương trình",
        "tphcm" to "thành phố Hồ Chí Minh", "hcm" to "Hồ Chí Minh", "hn" to "Hà Nội", "sg" to "Sài Gòn"
    )

    /** Có nhiều nghĩa hoặc thô tục: không tự đoán, để nguyên và gắn cờ xem lại. */
    private val AMBIGUOUS: Set<String> = setOf(
        "tg", "kh", "mk", "m", "t", "dk", "đk", "bt", "bn", "bh", "ng", "tl", "cc", "vl", "vcl", "đm", "dm", "đmm", "dcm", "clgt"
    )

    private val ALLOWED_NO_VOWEL: Set<String> = setOf("tv", "km", "cm", "ml", "vnd", "usd", "tp", "hr", "vn", "pm", "am", "mr", "ms", "ps", "dr")

    private val URL = Regex("(?i)(https?://\\S+|www\\.\\S+)")
    private val MENTION = Regex("@([\\p{L}\\p{N}_.]+)")
    private val HASHTAG = Regex("#([\\p{L}\\p{N}_]+)")
    private val EMOTICON = Regex("(?<![\\p{L}\\p{N}])(?:[:;=]['\\-]?[)(\\]\\[dDpPoO3*|/\\\\]+|<3|\\^_?\\^|T_T|-_-)")
    private val MONEY_K = Regex("(?i)(\\d+(?:[.,]\\d+)?)\\s?k(?![\\p{L}\\p{N}])")
    private val MONEY_TR = Regex("(?i)(\\d+(?:[.,]\\d+)?)\\s?tr(?![\\p{L}\\p{N}])")
    private val LAUGH_K = Regex("(?i)(?<![\\p{L}\\p{N}])k{3,}(?![\\p{L}\\p{N}])")
    private val LAUGH_HA = Regex("(?i)(?<![\\p{L}\\p{N}])(?:ha){2,}h?(?![\\p{L}\\p{N}])|(?<![\\p{L}\\p{N}])(?:hi){2,}h?(?![\\p{L}\\p{N}])|(?<![\\p{L}\\p{N}])(?:he){2,}h?(?![\\p{L}\\p{N}])")
    private val LETTERS_RUN = Regex("\\p{L}{3,}")
    private val PUNCT_MIX = Regex("[?!]{2,}")
    private val WORD = Regex("[\\p{L}\\p{N}]+")

    fun normalize(raw: String): Result {
        val flags = ArrayList<String>()
        val changes = ArrayList<String>()
        var s = Vn.nfc(raw)

        s = URL.replace(s, " ")
        s = Vn.stripEmoji(s)
        s = EMOTICON.replace(s, " ")
        s = MENTION.replace(s) { it.groupValues[1].replace('_', ' ').replace('.', ' ') }
        s = HASHTAG.replace(s) { it.groupValues[1].replace('_', ' ') }

        s = MONEY_K.replace(s) { changes += "${it.value.trim()}→nghìn"; it.groupValues[1] + " nghìn" }
        s = MONEY_TR.replace(s) { changes += "${it.value.trim()}→triệu"; it.groupValues[1] + " triệu" }
        s = s.replace("%", " phần trăm ").replace("&", " và ")

        // tiếng cười phải xử lý TRƯỚC khi gộp ký tự lặp, để "kkkkk" không biến thành "k" = "không"
        s = LAUGH_K.replace(s) { changes += "${it.value}→ha ha"; "ha ha" }
        s = LAUGH_HA.replace(s) { changes += "${it.value}→ha ha"; "ha ha" }

        s = collapseElongated(s)

        s = WORD.replace(s) { m ->
            val w = m.value
            val lw = w.lowercase()
            val rep = DICT[lw]
            when {
                rep != null -> {
                    changes += "$w→$rep"
                    if (w.length > 1 && w[0].isUpperCase() && !w.all { it.isUpperCase() }) rep.replaceFirstChar { it.uppercase() } else rep
                }
                lw in AMBIGUOUS -> {
                    flags += "Từ viết tắt có nhiều nghĩa hoặc nhạy cảm, giữ nguyên: \"$w\""
                    w
                }
                isUnknownAbbreviation(lw) -> {
                    flags += "Từ viết tắt lạ, chưa chắc cách đọc: \"$w\""
                    w
                }
                else -> w
            }
        }

        s = s.replace(Regex("[~*^|\\\\]+"), " ")
        s = PUNCT_MIX.replace(s) { if (it.value.contains('?')) "?" else "!" }
        s = s.replace(Regex("\\.{4,}"), "...").replace(Regex("…{2,}"), "…").replace(Regex(",{2,}"), ",")
        s = Vn.collapseSpaces(s)
        s = s.replace(Regex("\\s+([,.!?;:…])"), "$1")
        s = s.trim().trimStart(',', ';', ':', '-', '–', '—', ' ')

        if (Vn.letterDigitCount(s) == 0) {
            flags += "Không còn chữ để đọc sau khi làm sạch"
            return Result("", flags.distinct(), changes)
        }
        if (!Regex("[.!?…]$").containsMatchIn(s)) s += "."
        return Result(s, flags.distinct(), changes)
    }

    /**
     * "quáaaa" → "quá", "ôiiii" → "ôi": gom chuỗi ≥3 chữ cái cùng chữ gốc (không tính dấu) thành chữ đầu tiên.
     * Chuỗi 2 chữ giữ nguyên (tiếng Việt có "oo", "ee" trong "xoong", "keeng").
     */
    private fun collapseElongated(s: String): String {
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (!c.isLetter()) { sb.append(c); i++; continue }
            val base = Vn.fold(c.toString())
            var j = i + 1
            while (j < s.length && s[j].isLetter() && Vn.fold(s[j].toString()) == base) j++
            sb.append(c)
            if (j - i < 3) sb.append(s, i + 1, j)
            i = j
        }
        return sb.toString()
    }

    private fun isUnknownAbbreviation(lw: String): Boolean {
        if (lw.length !in 2..5) return false
        if (!lw.all { it.isLetter() }) return false
        if (lw in ALLOWED_NO_VOWEL) return false
        val f = Vn.fold(lw)
        return f.none { it in "aeiouy" }
    }
}
