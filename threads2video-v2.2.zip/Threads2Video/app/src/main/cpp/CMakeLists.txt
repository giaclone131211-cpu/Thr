# Chỉ được dùng khi build với -Pt2v.llama=true.
# Cần một bản checkout llama.cpp ĐÃ GHIM COMMIT/TAG mà bạn đã thử (xem README), ví dụ:
#   git submodule add https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp
#   -Pt2v.llamaDir=/đường/dẫn/tới/llama.cpp   (mặc định: app/src/main/cpp/llama.cpp)
cmake_minimum_required(VERSION 3.22.1)
project(t2vllama LANGUAGES C CXX)

if(NOT DEFINED LLAMA_CPP_DIR OR NOT EXISTS "${LLAMA_CPP_DIR}/CMakeLists.txt")
  message(FATAL_ERROR "Thiếu llama.cpp: đặt -Pt2v.llamaDir=<thư mục llama.cpp> (đã ghim commit).")
endif()

set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL OFF CACHE BOOL "" FORCE)
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)

add_subdirectory(${LLAMA_CPP_DIR} llama-build)

add_library(t2vllama SHARED t2v_llama.cpp)
target_include_directories(t2vllama PRIVATE ${LLAMA_CPP_DIR}/include ${LLAMA_CPP_DIR}/ggml/include)
target_link_libraries(t2vllama PRIVATE llama log)
# Android 15+/16: căn lề 16 KB cho thư viện native
target_link_options(t2vllama PRIVATE -Wl,-z,max-page-size=16384)
