// JNI tối giản cho llama.cpp (API đã đối chiếu với include/llama.h ngày 2026-11-14).
// CHƯA được biên dịch trong môi trường phát triển hiện tại (không có NDK). Hãy build và chạy thử
// trên thiết bị trước khi tin cậy. Mọi chuỗi đi qua JNI là byte UTF-8.
#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include "llama.h"

#define TAG "t2vllama"

namespace {

struct Handle {
    llama_model*   model   = nullptr;
    llama_context* ctx     = nullptr;
    llama_sampler* smpl    = nullptr;
    const llama_vocab* vocab = nullptr;
    int n_ctx = 0;
    int n_batch = 0;
    int remaining = 0;
    bool active = false;
};

std::string g_err;
std::once_flag g_init;

std::string bytes_to_string(JNIEnv* env, jbyteArray a) {
    if (!a) return {};
    jsize n = env->GetArrayLength(a);
    std::string s(static_cast<size_t>(n), '\0');
    if (n > 0) env->GetByteArrayRegion(a, 0, n, reinterpret_cast<jbyte*>(&s[0]));
    return s;
}

jbyteArray string_to_bytes(JNIEnv* env, const std::string& s) {
    jbyteArray a = env->NewByteArray(static_cast<jsize>(s.size()));
    if (!a) return nullptr;
    if (!s.empty()) env->SetByteArrayRegion(a, 0, static_cast<jsize>(s.size()), reinterpret_cast<const jbyte*>(s.data()));
    return a;
}

Handle* H(jlong h) { return reinterpret_cast<Handle*>(h); }

}  // namespace

extern "C" {

JNIEXPORT jbyteArray JNICALL
Java_com_threads2video_ai_LlamaNative_nativeLastError(JNIEnv* env, jclass) {
    return string_to_bytes(env, g_err);
}

JNIEXPORT jlong JNICALL
Java_com_threads2video_ai_LlamaNative_nativeLoad(JNIEnv* env, jclass, jbyteArray jpath, jint n_ctx, jint n_threads) {
    std::call_once(g_init, [] { llama_backend_init(); });
    std::string path = bytes_to_string(env, jpath);

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;  // CPU: không giả định backend GPU trên Galaxy A15
    llama_model* model = llama_model_load_from_file(path.c_str(), mp);
    if (!model) { g_err = "llama_model_load_from_file thất bại (file hỏng, thiếu RAM hoặc kiến trúc chưa hỗ trợ)"; return 0; }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = static_cast<uint32_t>(n_ctx);
    cp.n_batch = 512;
    cp.n_threads = n_threads;
    cp.n_threads_batch = n_threads;
    llama_context* ctx = llama_init_from_model(model, cp);
    if (!ctx) { llama_model_free(model); g_err = "llama_init_from_model thất bại (thiếu RAM cho context?)"; return 0; }

    auto* h = new Handle();
    h->model = model;
    h->ctx = ctx;
    h->vocab = llama_model_get_vocab(model);
    h->n_ctx = n_ctx;
    h->n_batch = static_cast<int>(cp.n_batch);
    h->smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(h->smpl, llama_sampler_init_greedy());  // xác định, hợp với chuẩn hóa văn bản
    return reinterpret_cast<jlong>(h);
}

JNIEXPORT jbyteArray JNICALL
Java_com_threads2video_ai_LlamaNative_nativeApplyTemplate(JNIEnv* env, jclass, jlong hh, jbyteArray jsys, jbyteArray juser) {
    Handle* h = H(hh);
    if (!h) { g_err = "handle rỗng"; return nullptr; }
    std::string sys = bytes_to_string(env, jsys), user = bytes_to_string(env, juser);
    const char* tmpl = llama_model_chat_template(h->model, nullptr);
    if (!tmpl) { g_err = "model không có chat template"; return nullptr; }
    llama_chat_message msgs[2] = {{"system", sys.c_str()}, {"user", user.c_str()}};
    std::vector<char> buf((sys.size() + user.size()) * 2 + 1024);
    int32_t n = llama_chat_apply_template(tmpl, msgs, 2, true, buf.data(), static_cast<int32_t>(buf.size()));
    if (n > static_cast<int32_t>(buf.size())) {
        buf.resize(static_cast<size_t>(n) + 1);
        n = llama_chat_apply_template(tmpl, msgs, 2, true, buf.data(), static_cast<int32_t>(buf.size()));
    }
    if (n < 0) { g_err = "llama_chat_apply_template thất bại (template chưa được hỗ trợ)"; return nullptr; }
    return string_to_bytes(env, std::string(buf.data(), static_cast<size_t>(n)));
}

JNIEXPORT jboolean JNICALL
Java_com_threads2video_ai_LlamaNative_nativeStart(JNIEnv* env, jclass, jlong hh, jbyteArray jprompt, jint max_tokens) {
    Handle* h = H(hh);
    if (!h) { g_err = "handle rỗng"; return JNI_FALSE; }
    std::string prompt = bytes_to_string(env, jprompt);

    // dung lượng token (hàm trả số âm = số token cần thiết khi buffer null)
    int32_t need = -llama_tokenize(h->vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()), nullptr, 0, true, true);
    if (need <= 0) { g_err = "tokenize thất bại"; return JNI_FALSE; }
    if (need + max_tokens > h->n_ctx) { g_err = "prompt quá dài so với context (" + std::to_string(need) + " token)"; return JNI_FALSE; }
    std::vector<llama_token> toks(static_cast<size_t>(need));
    int32_t got = llama_tokenize(h->vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()), toks.data(), need, true, true);
    if (got < 0) { g_err = "tokenize thất bại"; return JNI_FALSE; }

    llama_memory_clear(llama_get_memory(h->ctx), true);
    llama_sampler_reset(h->smpl);

    for (int32_t i = 0; i < got; i += h->n_batch) {
        int32_t n_eval = std::min<int32_t>(h->n_batch, got - i);
        if (llama_decode(h->ctx, llama_batch_get_one(toks.data() + i, n_eval)) != 0) {
            g_err = "llama_decode thất bại khi nạp prompt";
            return JNI_FALSE;
        }
    }
    h->remaining = max_tokens;
    h->active = true;
    return JNI_TRUE;
}

// Trả về byte của một token, hoặc null khi kết thúc (EOS/hết token).
JNIEXPORT jbyteArray JNICALL
Java_com_threads2video_ai_LlamaNative_nativeNext(JNIEnv* env, jclass, jlong hh) {
    Handle* h = H(hh);
    if (!h || !h->active) return nullptr;
    if (h->remaining <= 0) { h->active = false; return nullptr; }

    llama_token tok = llama_sampler_sample(h->smpl, h->ctx, -1);
    if (llama_vocab_is_eog(h->vocab, tok)) { h->active = false; return nullptr; }

    char buf[256];
    int32_t n = llama_token_to_piece(h->vocab, tok, buf, sizeof(buf), 0, false);
    if (n < 0) { h->active = false; g_err = "token_to_piece thất bại"; return nullptr; }

    h->remaining--;
    if (llama_decode(h->ctx, llama_batch_get_one(&tok, 1)) != 0) {
        h->active = false;
        g_err = "llama_decode thất bại khi sinh token";
    }
    return string_to_bytes(env, std::string(buf, static_cast<size_t>(n)));
}

JNIEXPORT void JNICALL
Java_com_threads2video_ai_LlamaNative_nativeFinish(JNIEnv*, jclass, jlong hh) {
    Handle* h = H(hh);
    if (!h) return;
    h->active = false;
    llama_memory_clear(llama_get_memory(h->ctx), true);
}

JNIEXPORT void JNICALL
Java_com_threads2video_ai_LlamaNative_nativeFree(JNIEnv*, jclass, jlong hh) {
    Handle* h = H(hh);
    if (!h) return;
    if (h->smpl) llama_sampler_free(h->smpl);
    if (h->ctx) llama_free(h->ctx);
    if (h->model) llama_model_free(h->model);
    delete h;
}

}  // extern "C"
