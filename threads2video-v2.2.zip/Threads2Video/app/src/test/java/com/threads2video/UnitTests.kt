package com.threads2video

import org.junit.Test

/** Cầu nối JUnit (Gradle `testDebugUnitTest`) tới bộ test thuần JVM. */
class UnitTests {
    @Test
    fun pureLogic() = TestSuite.runAll()
}
