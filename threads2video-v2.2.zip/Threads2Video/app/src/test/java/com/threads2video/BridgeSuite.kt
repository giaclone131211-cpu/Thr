package com.threads2video

import com.threads2video.ai.AiService
import com.threads2video.ai.CancelToken
import com.threads2video.ai.LlmBackend
import com.threads2video.ai.LocalModelManager
import com.threads2video.bridge.NativeDispatcher
import com.threads2video.bridge.Platform
import com.threads2video.core.Json
import com.threads2video.core.bool
import com.threads2video.core.str
import com.threads2video.data.local.CardStore
import com.threads2video.data.local.ProjectStore
import com.threads2video.data.threads.*
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.util.Base64

/** Test thuần JVM cho OAuth và hợp đồng cầu nối JS↔Kotlin (NativeDispatcher). Được TestSuite.runAll gọi. */
object BridgeSuite {
    private var count = 0
    private val failures = ArrayList<String>()
    fun ok(c: Boolean, m: String) { count++; if (!c) { failures += m; println("  FAIL: $m") } }
    private inline fun <reified T : Throwable> throwsA(m: String, f: () -> Unit) {
        count++
        try { f(); failures += "$m (không ném lỗi)"; println("  FAIL: $m (không ném lỗi)") }
        catch (e: Throwable) { if (e !is T) { failures += "$m (ném ${e::class.simpleName}: ${e.message})"; println("  FAIL: $m (ném ${e::class.simpleName}: ${e.message})") } }
    }

    // ---------- fakes ----------
    class MemTokens : TokenStore {
        var t: StoredToken? = null
        override fun load() = t
        override fun save(t: StoredToken) { this.t = t }
        override fun clear() { t = null }
    }
    class MemConfig(var c: ThreadsConfig = ThreadsConfig("", "")) : ConfigStore {
        override fun load() = c
        override fun save(c: ThreadsConfig) { this.c = c }
    }
    class MemPending : PendingStore {
        var v: Triple<String, String, Long>? = null
        override fun put(state: String, verifier: String, createdAtMs: Long) { v = Triple(state, verifier, createdAtMs) }
        override fun take(): Triple<String, String, Long>? { val x = v; v = null; return x }
    }
    class FakeTransport(val handler: (method: String, url: String, body: String?) -> HttpResult) : HttpTransport {
        val calls = ArrayList<Triple<String, String, String?>>()
        override fun get(url: String, timeoutMs: Int): HttpResult { calls += Triple("GET", url, null); return handler("GET", url, null) }
        override fun postJson(url: String, json: String, timeoutMs: Int): HttpResult { calls += Triple("POST", url, json); return handler("POST", url, json) }
    }
    class FakePlatform : Platform {
        val opened = ArrayList<String>()
        var picked = 0
        override fun sysInfo(): Map<String, Any?> = mapOf("totalMemBytes" to (8L shl 30), "cores" to 8)
        override fun availMemBytes() = 4L shl 30
        override fun freeDiskBytes() = 50L shl 30
        override fun openBrowser(url: String) { opened += url }
        override fun pickModelFile() { picked++ }
        override fun cardUri(commentId: String, version: Long) = "https://appassets.example/cards/$commentId.png?v=$version"
    }
    class FakeLlm : LlmBackend {
        override val modelName = "fake"
        var closed = false
        override fun complete(system: String, user: String, maxTokens: Int, cancel: CancelToken) = "{\"t\":\"x\"}"
        override fun close() { closed = true }
    }
    class FakeData(
        val search: () -> List<ApiItem> = { emptyList() },
        val replies: () -> List<ApiItem> = { emptyList() },
        var meFn: () -> MeInfo = { MeInfo("1", "toi") }
    ) : ThreadsDataSource {
        override fun me(): MeInfo = meFn()
        override fun keywordSearch(q: String, searchType: String, searchMode: String, limit: Int) = search()
        override fun replies(postId: String, maxPages: Int) = replies()
    }

    private fun item(id: String, text: String, user: String = "u$id", isReply: Boolean? = false) =
        ApiItem(id, text, user, "https://www.threads.com/@$user/post/$id", "2026-01-01T00:00:00+0000", "TEXT_POST", true, isReply, false, null, null)

    private const val SECRET = "THREADSTOKEN_abcdefghijklmnop123456"
    private val PNG = byteArrayOf(0x89.toByte(), 'P'.code.toByte(), 'N'.code.toByte(), 'G'.code.toByte(), 13, 10, 26, 10, 0, 0, 0, 0)

    class Rig(
        val tokens: MemTokens = MemTokens(), val config: MemConfig = MemConfig(), val pending: MemPending = MemPending(),
        val transport: FakeTransport = FakeTransport { _, _, _ -> HttpResult(404, "{}") },
        var now: Long = 1_000_000_000_000L, data: FakeData = FakeData()
    ) {
        val platform = FakePlatform()
        val dir: File = Files.createTempDirectory("t2vbridge").toFile()
        val events = ArrayList<Pair<String, Map<String, Any?>>>()
        val oauth = ThreadsOAuth(config, tokens, pending, transport, { now })
        val models = LocalModelManager(File(dir, "models"), marginBytes = 0)
        val llm = FakeLlm()
        val ai = AiService(models, { 4L shl 30 }, 8, { _, _, _, _ -> llm })
        val projects = ProjectStore(dir)
        val cards = CardStore(dir)
        val d = NativeDispatcher(platform, oauth, config, tokens, data, ai, models, projects, cards) { e, p -> events += e to p }
        fun call(name: String, vararg kv: Pair<String, Any?>) = d.dispatch(name, mapOf(*kv))
    }

    fun runAll(): Pair<Int, List<String>> {
        count = 0; failures.clear()
        oauth(); dispatcher()
        return count to failures.toList()
    }

    // ---------- OAuth ----------
    private fun oauth() {
        println("== ThreadsOAuth")
        val r0 = Rig()
        throwsA<ThreadsError.NotConfigured>("chưa cấu hình → NotConfigured") { r0.oauth.beginAuthorization() }
        r0.config.c = ThreadsConfig("12345678", "http://insecure.example")
        throwsA<ThreadsError.NotConfigured>("backend http:// bị từ chối") { r0.oauth.beginAuthorization() }

        val r = Rig(config = MemConfig(ThreadsConfig("12345678", "https://broker.example/")))
        val url = r.oauth.beginAuthorization()
        ok(url.startsWith("https://threads.com/oauth/authorize?"), "dùng cửa sổ cấp quyền chính thức")
        ok(url.contains("client_id=12345678") && url.contains("response_type=code"), "có client_id + response_type=code")
        ok(url.contains("redirect_uri=https%3A%2F%2Fbroker.example%2Fthreads%2Fcallback"), "redirect về backend")
        ok(url.contains("scope=threads_basic%2Cthreads_read_replies%2Cthreads_keyword_search"), "scope đúng")
        ok(!url.contains("secret"), "URL không chứa secret")
        val st = r.pending.v!!
        ok(st.first.substringAfter('.') == ThreadsOAuth.sha256Base64Url(st.second), "state chứa sha256(verifier)")
        ok(!url.contains(st.second), "verifier không lộ trong URL")

        throwsA<ThreadsError.NotAuthorized>("state sai bị từ chối") { r.oauth.handleCallback(mapOf("state" to "sai", "ticket" to "t")) }
        ok(r.tokens.t == null && r.pending.v == null, "state sai: không lưu token, phiên bị hủy")
        throwsA<ThreadsError.NotAuthorized>("không có phiên chờ → lỗi") { r.oauth.handleCallback(mapOf("state" to "x", "ticket" to "t")) }

        r.oauth.beginAuthorization()
        throwsA<ThreadsError.ConsentDenied>("người dùng từ chối") { r.oauth.handleCallback(mapOf("state" to r.pending.v!!.first, "error" to "access_denied")) }
        r.oauth.beginAuthorization()
        throwsA<ThreadsError.NotAuthorized>("lỗi khác từ Meta") { r.oauth.handleCallback(mapOf("state" to r.pending.v!!.first, "error" to "server_error")) }
        r.oauth.beginAuthorization()
        throwsA<ThreadsError.NotAuthorized>("thiếu ticket") { r.oauth.handleCallback(mapOf("state" to r.pending.v!!.first)) }

        r.oauth.beginAuthorization()
        r.now += 11 * 60 * 1000
        throwsA<ThreadsError.NotAuthorized>("phiên quá hạn (>10 phút)") { r.oauth.handleCallback(mapOf("state" to r.pending.v!!.first, "ticket" to "t")) }

        val t2 = Rig(config = MemConfig(ThreadsConfig("12345678", "https://broker.example")),
            transport = FakeTransport { _, u, b ->
                if (u.endsWith("/threads/redeem")) HttpResult(200, "{\"access_token\":\"$SECRET\",\"expires_in\":5183944,\"user_id\":\"77\"}") else HttpResult(404, "{}")
            })
        t2.oauth.beginAuthorization()
        val verifier = t2.pending.v!!.second
        val tok = t2.oauth.handleCallback(mapOf("state" to t2.pending.v!!.first, "ticket" to "TICKET1"))
        ok(tok.token == SECRET && tok.source == "oauth" && tok.expiresAtMs == t2.now + 5183944L * 1000, "đổi vé thành công, lưu token + hạn")
        val body = Json.parseObject(t2.transport.calls.single().third!!)
        ok(body.str("ticket") == "TICKET1" && body.str("verifier") == verifier && !t2.transport.calls.single().third!!.contains("secret"), "redeem gửi ticket + verifier, không có secret")
        throwsA<ThreadsError.NotAuthorized>("vé chỉ dùng một lần (phiên đã bị lấy)") { t2.oauth.handleCallback(mapOf("state" to "x", "ticket" to "TICKET1")) }

        val t3 = Rig(config = MemConfig(ThreadsConfig("12345678", "https://broker.example")), transport = FakeTransport { _, _, _ -> HttpResult(410, "{}") })
        t3.oauth.beginAuthorization()
        throwsA<ThreadsError.NotAuthorized>("backend từ chối vé") { t3.oauth.handleCallback(mapOf("state" to t3.pending.v!!.first, "ticket" to "t")) }
        val t4 = Rig(config = MemConfig(ThreadsConfig("12345678", "https://broker.example")), transport = FakeTransport { _, _, _ -> throw IOException("down") })
        t4.oauth.beginAuthorization()
        throwsA<ThreadsError.Network>("backend không kết nối được") { t4.oauth.handleCallback(mapOf("state" to t4.pending.v!!.first, "ticket" to "t")) }

        // token thủ công
        throwsA<ThreadsError.NotAuthorized>("token quá ngắn") { r.oauth.saveManualToken("abc", null) }
        throwsA<ThreadsError.NotAuthorized>("token có khoảng trắng") { r.oauth.saveManualToken("a".repeat(30) + " b", null) }
        r.oauth.saveManualToken(SECRET, null)
        ok(r.oauth.currentToken() == SECRET, "token thủ công dùng được (không hạn)")

        // hết hạn & gia hạn
        val e = Rig(); e.tokens.t = StoredToken(SECRET, e.now - 1, e.now - 99999999, null, null, "oauth")
        throwsA<ThreadsError.NotAuthorized>("token hết hạn → NotAuthorized") { e.oauth.freshToken() }
        ok(e.tokens.t == null, "token hết hạn bị xóa")

        val day = 24L * 3600 * 1000
        val g = Rig(transport = FakeTransport { _, u, _ -> if (u.contains("/refresh_access_token")) HttpResult(200, "{\"access_token\":\"NEWTOKEN_abcdefghijklmnop1234\",\"expires_in\":5184000}") else HttpResult(404, "{}") })
        g.tokens.t = StoredToken(SECRET, g.now + 3 * day, g.now - 5 * day, null, null, "oauth")
        ok(g.oauth.freshToken() == "NEWTOKEN_abcdefghijklmnop1234", "gần hết hạn + đủ 24h tuổi → gia hạn")
        ok(g.transport.calls.single().second.startsWith("https://graph.threads.com/refresh_access_token?grant_type=th_refresh_token&access_token="), "gia hạn đúng endpoint, không secret")
        ok(!g.transport.calls.single().second.contains("client_secret"), "gia hạn không cần client_secret")

        val y = Rig(transport = FakeTransport { _, _, _ -> HttpResult(200, "{}") })
        y.tokens.t = StoredToken(SECRET, y.now + 3 * day, y.now - 2 * 3600 * 1000, null, null, "oauth")
        ok(y.oauth.freshToken() == SECRET && y.transport.calls.isEmpty(), "token < 24h tuổi: không gia hạn")

        val f = Rig(transport = FakeTransport { _, _, _ -> HttpResult(400, "{}") })
        f.tokens.t = StoredToken(SECRET, f.now + 3 * day, f.now - 5 * day, null, null, "oauth")
        throwsA<ThreadsError.NotAuthorized>("gia hạn bị Meta từ chối → đăng nhập lại") { f.oauth.freshToken() }
        ok(f.tokens.t == null, "gia hạn thất bại: xóa token")

        val n = Rig(transport = FakeTransport { _, _, _ -> throw IOException("x") })
        n.tokens.t = StoredToken(SECRET, n.now + 3 * day, n.now - 5 * day, null, null, "oauth")
        ok(n.oauth.freshToken() == SECRET, "lỗi mạng khi gia hạn: vẫn dùng token cũ")

        r.oauth.logout()
        ok(r.tokens.t == null && r.oauth.currentToken() == null, "logout xóa token")
    }

    // ---------- Dispatcher ----------
    private fun dispatcher() {
        println("== NativeDispatcher")
        val long1 = "Tại sao người nấu ăn ở nhà đa số là phụ nữ nhưng đầu bếp thường là nam, nghe cứ như câu đố nhưng nghĩ kỹ lại thấy đúng."
        val reps = listOf(
            "Bếp núc ngày xưa toàn do bà ngoại mình đảm nhiệm suốt mấy chục năm không nghỉ 😂",
            "Lương đầu bếp nhà hàng năm sao cao gấp nhiều lần tiền công nội trợ chẳng ai trả",
            "Hàng xóm nhà tôi có ông chồng nấu ăn cực ngon còn vợ thì chỉ biết rửa bát nhé ko đùa đâu"
        ).mapIndexed { i, t -> item("r$i", t, isReply = true) }
        val rig = Rig(data = FakeData(search = { listOf(item("p1", long1)) }, replies = { reps }))
        rig.tokens.t = StoredToken(SECRET, null, 0, null, "toi", "manual")

        throwsA<com.threads2video.bridge.BridgeError>("lệnh lạ bị từ chối") { rig.call("nope") }
        val (okFlag, errJson) = rig.d.invoke("nope", "{}")
        ok(!okFlag && Json.parseObject(errJson).str("code") == "bad_request", "invoke trả lỗi có mã")
        ok(!rig.d.invoke("project.save", "{bad json").first, "JSON hỏng không làm sập cầu nối")

        // cấu hình
        throwsA<com.threads2video.bridge.BridgeError>("config.set từ chối http://") { rig.call("config.set", "appId" to "12345678", "brokerUrl" to "http://x") }
        throwsA<com.threads2video.bridge.BridgeError>("config.set từ chối App ID không phải số") { rig.call("config.set", "appId" to "abc", "brokerUrl" to "https://x") }
        val st = Json.asMap(rig.call("config.set", "appId" to "12345678", "brokerUrl" to "https://broker.example"))!!
        ok(st.bool("configured") == true && st.bool("loggedIn") == true, "config.set → configured, loggedIn")
        ok(!Json.stringify(st).contains(SECRET), "trạng thái đăng nhập không lộ token")
        rig.call("auth.begin")
        ok(rig.platform.opened.single().startsWith("https://threads.com/oauth/authorize?"), "auth.begin mở trình duyệt hệ thống tới cửa sổ OAuth")

        // research
        val rs = Json.asMap(rig.call("research.run", "topic" to "nấu ăn", "criteria" to "mix", "topN" to 8L))!!
        val src = Json.asMap(rs["source"])!!
        val cm = Json.asList(src["comments"])!!.map { Json.asMap(it)!! }
        ok(cm.size == 3 && Json.asList(src["topIds"])!!.size == 3, "Top = số thật (3), không ép đủ 8")
        ok(cm.all { it["likeCount"] == null }, "không bịa like")
        ok(cm.first { it.str("id") == "r0" }.str("rawText")!!.endsWith("😂"), "rawText giữ nguyên emoji")
        ok(rig.events.any { it.first == "research.progress" }, "có sự kiện tiến trình")
        ok(!Json.stringify(rs).contains(SECRET), "kết quả research không chứa token")

        // lỗi quyền → mã rõ ràng, không rơi về scraping
        val deny = Rig(data = FakeData(search = { throw ThreadsError.PermissionDenied("threads_keyword_search", "Chưa có quyền") }))
        val (o2, e2) = deny.d.invoke("research.run", "{\"topic\":\"x\"}")
        val em = Json.parseObject(e2)
        ok(!o2 && em.str("code") == "permission_denied" && em.str("permission") == "threads_keyword_search", "thiếu quyền → mã permission_denied + tên quyền")
        val rate = Rig(data = FakeData(search = { throw ThreadsError.RateLimited(30) }))
        ok(Json.parseObject(rate.d.invoke("research.run", "{\"topic\":\"x\"}").second)["retryAfterSec"] == 30L, "rate limit → retryAfterSec")
        val noauth = Rig(data = FakeData(meFn = { throw ThreadsError.NotAuthorized() }))
        ok(Json.parseObject(noauth.d.invoke("research.run", "{\"topic\":\"x\"}").second).str("code") == "not_authorized", "chưa đăng nhập → not_authorized")

        // rank thủ công + tts
        val rk = Json.asMap(rig.call("research.rank", "topic" to "nấu ăn", "criteria" to "funny", "topN" to 2L,
            "post" to mapOf("id" to "m0", "rawText" to long1, "origin" to "manual"),
            "comments" to cm))!!
        ok(Json.asList(rk["topIds"])!!.size == 2, "research.rank tôn trọng topN")
        val tts = Json.asList(rig.call("tts.normalize", "items" to listOf(mapOf("id" to "r0", "rawText" to "ko bik dc k 😂 hihi vl"))))!!
        val t0 = Json.asMap(tts[0])!!
        ok(t0.str("ttsText")!!.none { it.isSurrogate() }, "ttsText không còn emoji")
        ok(t0["rawText"] == null, "tts.normalize không trả/ghi đè rawText")

        // card + project
        val b64 = Base64.getEncoder().encodeToString(PNG)
        val c1 = Json.asMap(rig.call("card.save", "projectId" to "p", "commentId" to "r0", "pngBase64" to "data:image/png;base64,$b64"))!!
        ok(c1.str("uri")!!.contains("/cards/r0.png") && File(rig.dir, "cards/r0.png").readBytes().contentEquals(PNG), "card.save lưu file PNG riêng theo ID")
        throwsA<com.threads2video.bridge.BridgeError>("card.save base64 hỏng") { rig.call("card.save", "commentId" to "z", "pngBase64" to "###") }
        ok(!rig.d.invoke("card.save", "{\"commentId\":\"z\",\"pngBase64\":\"" + Base64.getEncoder().encodeToString(byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9)) + "\"}").first, "card.save từ chối dữ liệu không phải PNG")
        rig.call("project.save", "id" to "p", "json" to "{\"a\":1}")
        ok(Json.asMap(rig.call("project.load", "id" to "p"))!!.str("json") == "{\"a\":1}", "project round-trip")
        rig.call("project.deleteAll")
        ok(Json.asMap(rig.call("project.load", "id" to "p"))!!["json"] == null && !File(rig.dir, "cards/r0.png").exists(), "xóa toàn bộ dữ liệu project gồm cả card")

        // model + AI
        val cat = Json.asMap(rig.call("model.catalog"))!!
        ok(Json.asList(cat["profiles"])!!.size == 2, "danh mục có profile nhẹ + chất lượng")
        throwsA<com.threads2video.bridge.BridgeError>("tải model không có trong danh mục") { rig.call("model.download", "id" to "khong-co") }
        ok(rig.d.invoke("ai.load", "{\"fileName\":\"khong.gguf\"}").second.contains("ai_unavailable"), "nạp model chưa cài → ai_unavailable")
        rig.call("model.import", "sha256" to "")
        ok(rig.platform.picked == 1, "model.import mở bộ chọn file")
        val gguf = ByteArray(2048) { 1 }.also { it[0] = 71; it[1] = 71; it[2] = 85; it[3] = 70 }
        rig.d.importModel(ByteArrayInputStream(byteArrayOf(1, 2, 3, 4) + ByteArray(100)), "bad.gguf", 104)
        ok(rig.events.last().second.bool("ok") == false && rig.models.installed().isEmpty(), "file .gguf sai header bị từ chối")
        rig.d.importModel(ByteArrayInputStream(gguf), "tiny.gguf", 2048)
        ok(rig.events.last().first == "model.done" && rig.events.last().second.bool("ok") == true, "importModel phát sự kiện model.done")
        rig.call("ai.load", "fileName" to "tiny.gguf")
        ok(Json.asMap(rig.call("ai.status"))!!.str("kind") == "llm", "nạp model → engine llm")
        rig.call("export.prepare")
        ok(rig.llm.closed && Json.asMap(rig.call("ai.status"))!!.str("kind") == "rules", "export.prepare giải phóng model")
        val low = AiService(rig.models, { 1000L }, 8, { _, _, _, _ -> rig.llm })
        throwsA<com.threads2video.ai.AiUnavailable>("thiếu RAM → từ chối nạp") { low.load("tiny.gguf") }
        rig.call("model.delete", "fileName" to "tiny.gguf")
        ok(rig.models.installed().isEmpty(), "xóa model")

        // đăng xuất + sự kiện auth
        rig.call("auth.logout")
        ok(Json.asMap(rig.call("auth.status"))!!.bool("loggedIn") == false, "logout → loggedIn=false")
        rig.d.finishAuth(mapOf("state" to "sai", "ticket" to "t"))
        val ev = rig.events.last()
        ok(ev.first == "auth.result" && ev.second.bool("ok") == false, "deep link lỗi vẫn phát auth.result (UI không treo)")
    }
}
