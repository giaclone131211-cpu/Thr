package com.threads2video

import com.sun.net.httpserver.HttpServer
import com.threads2video.ai.*
import com.threads2video.core.Json
import com.threads2video.core.Vn
import com.threads2video.data.CommentRecord
import com.threads2video.data.PostRecord
import com.threads2video.data.local.CardStore
import com.threads2video.data.local.ProjectStore
import com.threads2video.data.threads.*
import com.threads2video.workflow.ResearchOptions
import com.threads2video.workflow.ResearchWorkflow
import java.io.ByteArrayInputStream
import java.io.File
import java.net.InetSocketAddress
import java.nio.file.Files
import java.security.MessageDigest

/** Bộ test thuần JVM (không cần Android). JUnit gọi [runAll]; cũng chạy được bằng main() khi không có Gradle. */
object TestSuite {
    private val failures = ArrayList<String>()
    private var count = 0

    private fun ok(cond: Boolean, msg: String) {
        count++
        if (!cond) { failures += msg; println("  FAIL: $msg") }
    }

    private inline fun <reified T : Throwable> throwsA(msg: String, f: () -> Unit) {
        count++
        try { f(); failures += "$msg (không ném lỗi)"; println("  FAIL: $msg (không ném lỗi)") }
        catch (e: Throwable) {
            if (e !is T) { failures += "$msg (ném ${e::class.simpleName}: ${e.message})"; println("  FAIL: $msg (ném ${e::class.simpleName}: ${e.message})") }
        }
    }

    private fun section(n: String) = println("== $n")

    fun runAll() {
        failures.clear(); count = 0
        json(); dtos(); client(); ranker(); normalizer(); guard(); hybrid(); workflow(); models(); stores()
        BridgeSuite.runAll().let { (n, f) -> count += n; failures += f }
        println("\n$count kiểm tra, ${failures.size} lỗi")
        if (failures.isNotEmpty()) throw AssertionError("Test thất bại:\n" + failures.joinToString("\n"))
    }

    // ---------- JSON ----------
    private fun json() {
        section("Json")
        val src = mapOf("a" to "xin chào \"bạn\"\n😀", "n" to 5L, "d" to 1.5, "b" to true, "z" to null, "l" to listOf(1L, "x"))
        val back = Json.parseObject(Json.stringify(src))
        ok(back["a"] == "xin chào \"bạn\"\n😀", "round-trip chuỗi có emoji/escape")
        ok(back["n"] == 5L && back["d"] == 1.5 && back["b"] == true && back["z"] == null, "round-trip số/bool/null")
        ok(Json.parse("\"\\ud83d\\ude00\"") == "😀", "\\u surrogate pair")
        throwsA<Json.JsonException>("JSON cụt bị từ chối") { Json.parse("{\"a\":") }
        throwsA<Json.JsonException>("JSON thừa bị từ chối") { Json.parse("{} x") }
        ok(!Json.stringify("a\u2028b").contains('\u2028'), "U+2028 được escape")
    }

    // ---------- DTO ----------
    private fun dtos() {
        section("DTO / Meta response")
        val p = ThreadsDtos.parseItems("""{"data":[{"id":"1","text":"Bài A","username":"u","permalink":"https://www.threads.com/@u/post/x","timestamp":"2026-01-01T00:00:00+0000","has_replies":true,"is_reply":false},{"text":"thiếu id"},{"id":"2"}],"paging":{"cursors":{"before":"b","after":"AAA"},"next":"https://graph..."}}""")
        ok(p.items.size == 2, "bỏ phần tử thiếu id")
        ok(p.nextCursor == "AAA", "lấy cursor after khi có paging.next")
        ok(p.items[0].likeCount == null, "like_count vắng → null (không bịa)")
        ok(ThreadsDtos.toPost(p.items[1]) == null, "post không có text bị bỏ")
        ok(ThreadsDtos.parseItems("""{"data":[],"paging":{"cursors":{"after":"X"}}}""").nextCursor == null, "không có next → hết trang")
        throwsA<ThreadsError.BadResponse>("thiếu data → BadResponse") { ThreadsDtos.parseItems("""{"x":1}""") }
        throwsA<ThreadsError.BadResponse>("không phải JSON → BadResponse") { ThreadsDtos.parseItems("<html>") }
        val c = ThreadsDtos.parseItems("""{"data":[{"id":"9","text":"hi","like_count":12}]}""").items[0]
        ok(c.likeCount == 12L, "like_count được đọc nếu API thật sự trả về")
        ok(ThreadsDtos.parseError(401, "{}", null) is ThreadsError.NotAuthorized, "401 → NotAuthorized")
        ok(ThreadsDtos.parseError(400, """{"error":{"code":190,"message":"expired"}}""", null) is ThreadsError.NotAuthorized, "code 190 → NotAuthorized")
        val pd = ThreadsDtos.parseError(403, """{"error":{"code":10,"message":"Application does not have permission threads_keyword_search"}}""", null)
        ok(pd is ThreadsError.PermissionDenied && pd.permission == "threads_keyword_search", "code 10 → PermissionDenied + tên quyền")
        ok(ThreadsDtos.parseError(429, "{}", 30).let { it is ThreadsError.RateLimited && it.retryAfterSec == 30 }, "429 → RateLimited(30)")
        ok(ThreadsDtos.parseError(400, """{"error":{"code":4,"message":"limit"}}""", null) is ThreadsError.RateLimited, "code 4 → RateLimited")
        ok(ThreadsDtos.parseError(500, "oops", null) is ThreadsError.Network, "5xx → Network")
        ok(ThreadsDtos.parseError(400, """{"error":{"code":100,"message":"Invalid field xyz"}}""", null) is ThreadsError.BadField, "code 100 field → BadField")
    }

    // ---------- API client ----------
    private class FakeTransport(val handler: (String) -> HttpResult) : HttpTransport {
        val urls = ArrayList<String>()
        override fun get(url: String, timeoutMs: Int): HttpResult { urls += url; return handler(url) }
        override fun postJson(url: String, json: String, timeoutMs: Int): HttpResult = HttpResult(404, "")
    }

    private fun client() {
        section("ThreadsApiClient")
        val t = FakeTransport { HttpResult(200, """{"data":[{"id":"1","text":"x y z","username":"a"}]}""") }
        val api = ThreadsApiClient(t, { "TOK" })
        api.keywordSearch("tình yêu", "TOP", "KEYWORD", 500)
        val u = t.urls[0]
        ok(u.startsWith("https://graph.threads.com/v1.0/keyword_search?"), "đúng endpoint keyword_search")
        ok(u.contains("q=t%C3%ACnh+y%C3%AAu"), "q được mã hóa UTF-8")
        ok(u.contains("search_type=TOP") && u.contains("search_mode=KEYWORD"), "search_type/search_mode")
        ok(u.contains("limit=100"), "limit bị chặn ở 100 theo tài liệu")
        ok(u.contains("access_token=TOK"), "token đi qua access_token")
        ok(u.contains("fields=id%2Ctext"), "có fields")
        throwsA<IllegalArgumentException>("search_type sai bị chặn") { api.keywordSearch("a", "HOT", "KEYWORD", 5) }
        throwsA<ThreadsError.NotAuthorized>("không có token → NotAuthorized") { ThreadsApiClient(t, { null }).me() }

        // field bị từ chối → thử bộ field tối thiểu
        var n = 0
        val t2 = FakeTransport { if (n++ == 0) HttpResult(400, """{"error":{"code":100,"message":"Invalid field has_replies"}}""") else HttpResult(200, """{"data":[{"id":"1","text":"hello"}]}""") }
        val r2 = ThreadsApiClient(t2, { "T" }).keywordSearch("a", "TOP", "KEYWORD", 10)
        ok(r2.size == 1 && t2.urls.size == 2 && t2.urls[1].contains("fields=id%2Ctext%2Cpermalink%2Ctimestamp%2Cusername"), "field lỗi → fallback bộ field tối thiểu")

        // replies: phân trang theo cursor, dừng ở maxPages, chống vòng lặp cursor
        var pg = 0
        val t3 = FakeTransport { pg++; HttpResult(200, """{"data":[{"id":"r$pg","text":"c$pg"}],"paging":{"cursors":{"after":"C$pg"},"next":"n"}}""") }
        val rr = ThreadsApiClient(t3, { "T" }).replies("123", 3)
        ok(rr.size == 3 && t3.urls.size == 3, "replies dừng ở maxPages=3")
        ok(t3.urls[1].contains("after=C1") && t3.urls[0].contains("/123/replies?"), "dùng cursor after của trang trước")
        ok(t3.urls.all { it.contains("reverse=false") }, "reverse=false")
        val t4 = FakeTransport { HttpResult(200, """{"data":[{"id":"r","text":"c"}],"paging":{"cursors":{"after":"SAME"},"next":"n"}}""") }
        ok(ThreadsApiClient(t4, { "T" }).replies("1", 10).size == 2 && t4.urls.size == 2, "cursor lặp → dừng")
        val t5 = FakeTransport { throw java.net.SocketTimeoutException() }
        throwsA<ThreadsError.Network>("timeout → Network") { ThreadsApiClient(t5, { "T" }).me() }
        val t6 = FakeTransport { HttpResult(200, "{}") }
        ok(ThreadsApiClient(t6, { "T" }, "https://graph.threads.com/v1.0").let { runCatching { it.me() }.isFailure }, "/me thiếu id → lỗi")
    }

    // ---------- ranker ----------
    private fun cm(id: String, text: String, likes: Long? = null, url: String? = null) = CommentRecord(
        id, "p1", url, null, text, null, likes, null, null, emptyList(), null, false, false, false
    )

    private fun ranker() {
        section("CommentRanker")
        val list = listOf(
            cm("1", "😂😂😂"),
            cm("2", "Inbox mình để nhận tư vấn kiếm tiền online nhé"),
            cm("3", "Mình không đồng ý, nấu ăn ở nhà mà không ai trả lương thì sao gọi là bình đẳng được. Thực ra vấn đề nằm ở chỗ khác."),
            cm("4", "Nấu cho cả nhà ăn thì không ai trả lương, nấu ở nhà hàng thì có lương và có danh xưng bếp trưởng."),
            cm("5", "Nấu cho cả nhà ăn thì không ai trả lương, nấu ở nhà hàng thì có lương và có danh xưng bếp trưởng!!"),
            cm("6", "haha đúng rồi, bá đạo thật sự luôn"),
            cm("7", "Ba tôi từng nấu ngon nhất nhà nhưng cả đời chỉ nấu dịp Tết, còn mẹ tôi nấu mỗi ngày mà chưa ai khen lần nào. Tôi cảm thấy buồn."),
            cm("8", "xem ở https://spam.example.com/abc"),
            cm("1", "trùng id")
        )
        val rq = RankRequest("nấu ăn", "Tại sao người nấu ăn ở nhà là phụ nữ nhưng đầu bếp thường là nam?", list, Criteria.MIX, 8)
        val r = CommentRanker.rank(rq)
        val dropIds = r.dropped.map { it.id }
        ok("1" in dropIds, "emoji-only bị loại")
        ok("2" in dropIds, "spam inbox bị loại")
        ok("8" in dropIds, "link bị loại")
        ok(r.dropped.count { it.id == "1" } == 2, "trùng ID bị loại (1 emoji + 1 trùng id)")
        ok("5" in dropIds && "4" !in dropIds, "bản trùng nội dung bị loại, bản đầu giữ")
        ok(r.ranked.any { it.id == "3" }, "ý kiến trái chiều KHÔNG bị loại")
        ok(r.ranked.all { it.rankScore != null && it.rankReasons.isNotEmpty() }, "mọi bình luận có điểm + lý do")
        ok(r.ranked.all { it.likeCount == null }, "likes vẫn null (không bịa)")
        ok(r.topIds.size == r.ranked.size && r.topIds.size == 4, "Top không ép đủ 8 khi dữ liệu hợp lệ ít hơn: ${r.topIds.size}")
        ok(r.ranked.zipWithNext().all { (a, b) -> (a.rankScore ?: 0f) >= (b.rankScore ?: 0f) }, "sắp xếp giảm dần")
        val funny = CommentRanker.rank(rq.copy(criteria = Criteria.FUNNY)).topIds.first()
        val deep = CommentRanker.rank(rq.copy(criteria = Criteria.DEEP)).topIds.first()
        val drama = CommentRanker.rank(rq.copy(criteria = Criteria.DRAMA)).topIds.first()
        ok(funny == "6", "tiêu chí hài chọn bình luận hài (nhận $funny)")
        ok(deep == "7", "tiêu chí sâu sắc chọn bình luận sâu (nhận $deep)")
        ok(drama == "3", "tiêu chí drama chọn bình luận tranh luận (nhận $drama)")
        ok(CommentRanker.rank(rq).ranked.map { it.id } == r.ranked.map { it.id }, "xếp hạng xác định (lặp lại cho cùng kết quả)")
        val perm = CommentRanker.rank(rq.copy(comments = listOf(cm("a", "Một bình luận đủ dài để xếp hạng nhé", url = "u1"), cm("b", "Bình luận khác hoàn toàn về chủ đề khác", url = "u1"))))
        ok(perm.dropped.any { it.id == "b" && it.reason.contains("permalink") }, "trùng permalink bị loại")
        val liked = CommentRanker.rank(rq.copy(comments = listOf(cm("x", "Nội dung bình luận bình thường số một đây", likes = 5000), cm("y", "Nội dung bình luận bình thường số hai kia", likes = 0)), topN = 2))
        ok(liked.ranked.first().id == "x" && (liked.ranked[0].rankScore!! - liked.ranked[1].rankScore!!) < 0.15f, "likes chỉ là tín hiệu phụ (chênh nhỏ)")
        val one = CommentRanker.rank(rq.copy(comments = list.take(1).map { cm("z", "Chỉ có một bình luận hợp lệ dài đủ để đọc.") }))
        ok(one.topIds == listOf("z"), "1 bình luận → Top có 1")
    }

    // ---------- TTS normalizer ----------
    private fun normalizer() {
        section("TtsTextNormalizer")
        fun n(s: String) = TtsTextNormalizer.normalize(s)
        ok(n("ko đi đc đâu vs ai").text == "không đi được đâu với ai.", "teencode: ${n("ko đi đc đâu vs ai").text}")
        ok(n("Hay quá 😂😂 🔥").text == "Hay quá.", "bỏ emoji: ${n("Hay quá 😂😂 🔥").text}")
        ok(!Vn.hasEmoji(n("👨‍👩‍👧 gia đình ❤️").text), "emoji ghép ZWJ/variation bị bỏ sạch")
        ok(n("quáaaaa đẹpppp").text == "quá đẹp.", "gộp chữ kéo dài: ${n("quáaaaa đẹpppp").text}")
        ok(n("kkkkkk buồn cười").text == "ha ha buồn cười.", "'kkkk' là tiếng cười, không phải 'không': ${n("kkkkkk buồn cười").text}")
        ok(n("hahaha").text == "ha ha.", "hahaha → ha ha")
        ok(n("giá 50k, lương 15tr").text == "giá 50 nghìn, lương 15 triệu.", "tiền: ${n("giá 50k, lương 15tr").text}")
        ok(n("ko thích").text == "không thích.", "phủ định giữ nguyên nghĩa")
        ok(n("Ko thích").text == "Không thích.", "viết hoa đầu câu được giữ")
        val amb = n("tg này mk thấy hay")
        ok(amb.needsReview && amb.text.contains("tg") && amb.text.contains("mk"), "viết tắt mơ hồ: giữ nguyên + gắn cờ")
        ok(n("btw hcm xyz").needsReview, "viết tắt lạ bị gắn cờ")
        ok(n("đm").needsReview && n("đm").text.contains("đm"), "chửi thề viết tắt không tự mở rộng, gắn cờ")
        val e = n("😂😂😂")
        ok(e.text.isEmpty() && e.needsReview, "chỉ có emoji → rỗng + gắn cờ")
        ok(n("xem https://a.com/x nhé").text == "xem nhé.", "bỏ URL")
        ok(n("@user_a nói đúng!!!").text == "user a nói đúng!", "mention + dấu câu lặp: ${n("@user_a nói đúng!!!").text}")
        ok(n("đúng không???").text == "đúng không?", "dấu hỏi lặp")
        ok(n("Một câu bình thường.").text == "Một câu bình thường.", "câu sạch không đổi")
        ok(n("tỉ số 3:30 nhé").text.contains("3:30"), "không nhầm 3:30 với emoticon")
        // bất biến rawText
        val raw = "ko đi 😂 đc"
        val c = cm("q", raw)
        val d = c.withTts(TtsTextNormalizer.normalize(c.rawText).text, false)
        ok(d.rawText == raw && d.ttsText != raw && !Vn.hasEmoji(d.ttsText!!), "withTts không đổi rawText, ttsText không emoji")
        ok(Vn.hasEmoji(d.rawText), "emoji vẫn còn trong rawText")
    }

    // ---------- guard ----------
    private fun guard() {
        section("TtsGuard")
        val raw = "ko đi đâu hết, 3 người thôi"
        val base = TtsTextNormalizer.normalize(raw).text
        ok(TtsGuard.check(raw, base, "Không đi đâu hết, 3 người thôi.") == null, "đầu ra tốt được chấp nhận")
        ok(TtsGuard.check(raw, base, "Đi hết, 3 người thôi.") != null, "mất phủ định bị từ chối")
        ok(TtsGuard.check(raw, base, "Không đi đâu hết, 9 người thôi.") != null, "số mới bị từ chối")
        ok(TtsGuard.check(raw, base, "Không đi đâu hết, 3 người thôi 😂") != null, "emoji bị từ chối")
        ok(TtsGuard.check(raw, base, "Không đi đâu hết và tôi cực kỳ yêu thích chuyến đi du lịch biển này lắm luôn nha.") != null, "bịa thêm bị từ chối")
        ok(TtsGuard.check("tôi đi", "Tôi đi.", "Đây là bản chuẩn hóa: Tôi đi.") != null, "lời dẫn thừa bị từ chối")
        ok(TtsGuard.check(raw, base, "") != null, "rỗng bị từ chối")
        val bad = TtsGuard.parse("blah <think>x</think> {\"t\":\"Xin chào.\",\"unsure\":true,\"why\":\"lạ\"} rác")
        ok(bad?.text == "Xin chào." && bad.unsure, "parse JSON lẫn rác + think")
        ok(TtsGuard.parse("không phải json") == null, "parse thất bại → null")
    }

    // ---------- hybrid ----------
    private class FakeLlm(val reply: (String, String) -> String) : LlmBackend {
        override val modelName = "fake-model"
        var calls = 0
        override fun complete(system: String, user: String, maxTokens: Int, cancel: CancelToken): String { calls++; cancel.check(); return reply(system, user) }
        override fun close() {}
    }

    private fun hybrid() {
        section("HybridEngine")
        val ct = CancelToken()
        val items = listOf(TtsInput("a", "ko đi đâu 😂 đc"), TtsInput("b", "ko đi đâu hết"))
        val none = HybridEngine { null }.normalizeTts(items, ct)
        ok(none.all { it.engine == "rules" } && none[0].ttsText == "không đi đâu được.", "không model → dùng luật: ${none[0].ttsText}")

        val good = FakeLlm { _, u -> if (u.contains("ko đi đâu 😂")) """{"t":"Không đi đâu được.","unsure":false,"why":""}""" else """{"t":"Đi hết.","unsure":false,"why":""}""" }
        val r = HybridEngine { good }.normalizeTts(items, ct)
        ok(r[0].engine == "llm" && !r[0].needsManualReview, "đầu ra model tốt được dùng")
        ok(r[1].engine == "rules" && r[1].needsManualReview && r[1].ttsText.startsWith("không"), "đảo nghĩa bị từ chối → bản luật + cần xem lại")

        val junk = FakeLlm { _, _ -> "xin lỗi tôi không biết" }
        val r2 = HybridEngine { junk }.normalizeTts(items.take(1), ct)
        ok(r2[0].needsManualReview && r2[0].engine == "rules", "model trả rác → fallback + cờ")

        val unsure = FakeLlm { _, _ -> """{"t":"Không đi đâu hết.","unsure":true,"why":"không rõ từ"}""" }
        ok(HybridEngine { unsure }.normalizeTts(items.drop(1), ct)[0].needsManualReview, "model báo chưa chắc → cần xem lại")

        val boom = FakeLlm { _, _ -> throw IllegalStateException("OOM") }
        ok(HybridEngine { boom }.normalizeTts(items.take(1), ct)[0].needsManualReview, "model ném lỗi → fallback")

        val c2 = CancelToken(); c2.cancel()
        throwsA<AiCancelled>("hủy được tác vụ") { HybridEngine { good }.normalizeTts(items, c2) }

        // rank blending
        val comments = listOf(
            cm("c1", "Tôi thấy chuyện này hoàn toàn bình thường thôi, chẳng có gì to tát."),
            cm("c2", "Ngày xưa nhà tôi cũng thế, mẹ nấu cơm còn bố thì đọc báo cả ngày."),
            cm("c3", "Điều khiến tôi suy nghĩ là cách xã hội gán nhãn cho công việc bếp núc."),
            cm("c4", "Quán cơm đầu ngõ nhà mình toàn đàn ông đứng bếp, vợ chỉ bưng bê."),
            cm("c5", "Đầu bếp nổi tiếng thế giới đa số là nam nhưng nội trợ thì đa số là nữ.")
        )
        val rq = RankRequest("chủ đề", "bài gốc", comments, Criteria.MIX, 3)
        val llm = FakeLlm { _, _ -> """[{"i":1,"s":1,"r":"nhạt"},{"i":2,"s":2},{"i":3,"s":10,"r":"rất hay"},{"i":4,"s":3},{"i":5,"s":4}]""" }
        val rr = HybridEngine { llm }.rankComments(rq, ct)
        ok(rr.engine == "llm+rules" && rr.topIds.first() == "c3", "model đẩy c3 lên đầu: ${rr.topIds}")
        ok(rr.ranked.first { it.id == "c3" }.rankReasons.any { it.startsWith("Model:") }, "lý do của model được ghi")
        ok(HybridEngine { FakeLlm { _, _ -> "[{\"i\":99,\"s\":5}]" } }.rankComments(rq, ct).engine == "rules", "chỉ số sai → bỏ model")
        ok(HybridEngine { FakeLlm { _, _ -> "không phải JSON" } }.rankComments(rq, ct).engine == "rules", "rank rác → bỏ model")
        ok(HybridEngine { null }.info().kind == "rules" && HybridEngine { good }.info().kind == "llm", "info() phản ánh trạng thái model")
        ok(HybridEngine { null }.caption("Bài viết dài đủ", emptyList(), ct).contains("chưa dùng AI"), "caption luật nói rõ chưa dùng AI")
    }

    // ---------- workflow ----------
    private class FakeData(
        val me: MeInfo? = MeInfo("1", "toi"),
        val search: (String, String, String) -> List<ApiItem> = { _, _, _ -> emptyList() },
        val replies: (String) -> List<ApiItem> = { emptyList() }
    ) : ThreadsDataSource {
        var searchCalls = 0
        override fun me() = me ?: throw ThreadsError.NotAuthorized()
        override fun keywordSearch(q: String, searchType: String, searchMode: String, limit: Int): List<ApiItem> { searchCalls++; return search(q, searchType, searchMode) }
        override fun replies(postId: String, maxPages: Int) = replies(postId)
    }

    private fun item(id: String, text: String, user: String = "nguoi$id", hasReplies: Boolean? = true, isReply: Boolean? = false, link: String? = "https://www.threads.com/@$user/post/$id") =
        ApiItem(id, text, user, link, "2026-01-01T00:00:00+0000", "TEXT_POST", hasReplies, isReply, false, null, null)

    private fun workflow() {
        section("ResearchWorkflow")
        val ct = CancelToken()
        val longText = "Tại sao người nấu ăn ở nhà đa số là phụ nữ nhưng đầu bếp thường là nam, nghe cứ như câu đố nhưng nghĩ kỹ lại thấy đúng."
        val distinct = listOf(
            "Bếp núc ngày xưa toàn do bà ngoại mình đảm nhiệm suốt mấy chục năm không nghỉ",
            "Lương đầu bếp nhà hàng năm sao cao gấp nhiều lần tiền công nội trợ chẳng ai trả",
            "Hàng xóm nhà tôi có ông chồng nấu ăn cực ngon còn vợ thì chỉ biết rửa bát",
            "Ngày Tết cả họ tụ tập thì đàn ông ngồi uống trà, phụ nữ chạy quanh bếp",
            "Báo chí hay phong anh hùng cho bếp trưởng nhưng chưa từng nhắc tới những người mẹ",
            "Trường học nên dạy các bạn nam nấu một bữa cơm tử tế trước khi ra đời",
            "Con cái lớn lên mới hiểu bữa cơm mẹ nấu mỗi tối là cả một sự hy sinh",
            "Công bằng là khi hai vợ chồng chia việc theo sức, chứ không phải theo giới tính",
            "Chuyện này đúng nhưng đừng đổ lỗi cho đàn ông, cả xã hội cùng tạo ra định kiến",
            "Mình từng làm phụ bếp và thấy áp lực nghề này khác hẳn nấu cơm cho gia đình",
            "Nhìn sang Nhật Bản thì đầu bếp sushi cũng toàn nam, lý do lại là truyền thống lâu đời",
            "Cuối cùng vẫn là chuyện của từng nhà, thương nhau thì ai rảnh người đó vào bếp"
        )
        val replyItems = (1..12).map { item("r$it", distinct[it - 1], hasReplies = false, isReply = true) } +
            item("rr", "😂😂", isReply = true) + item("rs", "Inbox mình nhận tư vấn nhé", isReply = true)
        val d = FakeData(
            search = { _, _, _ -> listOf(item("p1", longText), item("p1", longText), item("p2", "Quá ngắn"), item("p3", "Làm việc nhà không lương mà còn bị coi là nghĩa vụ, các bạn thấy công bằng không, mình thấy hơi buồn.", user = "toi")) },
            replies = { replyItems }
        )
        val wf = ResearchWorkflow(d, HybridEngine { null })
        val res = wf.research(ResearchOptions("nấu ăn"), ct)
        ok(res.candidates.map { it.id }.toSet() == setOf("p1", "p3"), "dedupe theo ID + loại bài quá ngắn: ${res.candidates.map { it.id }}")
        ok(res.source != null && res.source.comments.size == 12, "bỏ emoji-only và spam: ${res.source?.comments?.size}")
        ok(res.source!!.topIds.size == 8, "Top 8 khi đủ dữ liệu")
        ok(res.source.notices.any { it.code == Notices.NO_LIKES }, "thông báo không có dữ liệu tim")
        ok(d.searchCalls in 2..4, "số truy vấn bị giới hạn: ${d.searchCalls}")
        ok(res.source.comments.none { it.likeCount != null }, "không bịa likes")

        val own = FakeData(search = { _, _, _ -> listOf(item("a", longText, user = "toi"), item("b", longText + " nữa", user = "TOI")) }, replies = { replyItems })
        ok(ResearchWorkflow(own, HybridEngine { null }).research(ResearchOptions("x"), ct).notices.any { it.code == Notices.OWN_POSTS_ONLY }, "phát hiện app chỉ thấy bài của chính mình")

        val empty = ResearchWorkflow(FakeData(), HybridEngine { null }).research(ResearchOptions("x"), ct)
        ok(empty.candidates.isEmpty() && empty.notices.any { it.code == Notices.EMPTY } && empty.source == null, "API rỗng → thông báo, không bịa kết quả")

        throwsA<ThreadsError.PermissionDenied>("thiếu quyền ở truy vấn đầu → ném PermissionDenied") {
            ResearchWorkflow(FakeData(search = { _, _, _ -> throw ThreadsError.PermissionDenied("threads_keyword_search", "x") }), HybridEngine { null }).research(ResearchOptions("x"), ct)
        }
        throwsA<ThreadsError.NotAuthorized>("chưa đăng nhập → NotAuthorized") { ResearchWorkflow(FakeData(me = null), HybridEngine { null }).research(ResearchOptions("x"), ct) }
        throwsA<ThreadsError.RateLimited>("rate limit ở truy vấn đầu → ném") {
            ResearchWorkflow(FakeData(search = { _, _, _ -> throw ThreadsError.RateLimited(5) }), HybridEngine { null }).research(ResearchOptions("x"), ct)
        }

        var first = true
        val partial = FakeData(search = { _, _, _ -> if (first) { first = false; listOf(item("p1", longText)) } else throw ThreadsError.RateLimited(1) }, replies = { replyItems })
        val pr = ResearchWorkflow(partial, HybridEngine { null }).research(ResearchOptions("nấu ăn"), ct)
        ok(pr.candidates.isNotEmpty() && pr.notices.any { it.code == "rate_limited_partial" }, "rate limit giữa chừng → dùng phần đã có + thông báo")

        val deniedReplies = FakeData(search = { _, _, _ -> listOf(item("p1", longText)) }, replies = { throw ThreadsError.PermissionDenied("threads_read_replies", "no") })
        val dr = ResearchWorkflow(deniedReplies, HybridEngine { null }).research(ResearchOptions("x"), ct)
        ok(dr.source == null && dr.candidates.size == 1 && dr.notices.any { it.code == Notices.REPLY_FETCH_FAILED } && dr.notices.any { it.code == Notices.NO_REPLIES }, "không đọc được replies → báo rõ, vẫn giữ danh sách bài")

        val few = FakeData(search = { _, _, _ -> listOf(item("p1", longText)) }, replies = { replyItems.take(3) })
        val fr = ResearchWorkflow(few, HybridEngine { null }).research(ResearchOptions("x"), ct)
        ok(fr.source!!.topIds.size == 3 && fr.source.notices.any { it.code == Notices.FEWER_THAN_TARGET }, "ít hơn 8 → hiện số thật + lý do")

        val cc = CancelToken(); cc.cancel()
        throwsA<ThreadsError.Cancelled>("hủy giữa workflow") { ResearchWorkflow(d, HybridEngine { null }).research(ResearchOptions("x"), cc) }
        ok(wf.buildQueries("tình yêu", emptyList(), 4).size == 2, "chủ đề nhiều từ: TOP + RECENT, không TAG")
        ok(wf.buildQueries("cafe", listOf("quán cà phê"), 4).map { it.third } == listOf("KEYWORD", "KEYWORD", "TAG", "KEYWORD"), "chủ đề 1 từ thêm TAG + từ khóa phụ")
        ok(wf.buildQueries("a", List(20) { "k$it" }, 99).size <= 6, "số truy vấn có trần")
    }

    // ---------- model manager ----------
    private fun fakeGguf(n: Int): ByteArray = ByteArray(n) { (it % 251).toByte() }.also { it[0] = 'G'.code.toByte(); it[1] = 'G'.code.toByte(); it[2] = 'U'.code.toByte(); it[3] = 'F'.code.toByte() }
    private fun sha(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    private fun models() {
        section("LocalModelManager")
        val data = fakeGguf(3_000_000)
        var slow = false
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/m.gguf") { ex ->
            val range = ex.requestHeaders.getFirst("Range")
            var start = 0
            var code = 200
            if (range != null && range.startsWith("bytes=")) { start = range.removePrefix("bytes=").substringBefore('-').toInt(); code = 206 }
            if (start >= data.size) { ex.sendResponseHeaders(416, -1); ex.close(); return@createContext }
            val len = data.size - start
            ex.sendResponseHeaders(code, len.toLong())
            ex.responseBody.use { o ->
                var off = start
                while (off < data.size) {
                    val n = minOf(65536, data.size - off)
                    o.write(data, off, n); off += n
                    if (slow) Thread.sleep(15)
                }
            }
        }
        server.createContext("/redir") { ex -> ex.responseHeaders.add("Location", "/m.gguf"); ex.sendResponseHeaders(302, -1); ex.close() }
        server.createContext("/bad.gguf") { ex -> val b = ByteArray(1000) { 1 }; ex.sendResponseHeaders(200, b.size.toLong()); ex.responseBody.use { it.write(b) } }
        server.start()
        val base = "http://127.0.0.1:${server.address.port}"
        val dir = Files.createTempDirectory("t2vmodels").toFile()
        try {
            val mm = LocalModelManager(dir, allowInsecureHttp = true, marginBytes = 0)
            throwsA<ModelError>("HTTP thường bị chặn mặc định") { LocalModelManager(dir).download("http://x/m.gguf", "m.gguf", null, CancelToken()) { _, _ -> } }
            var lastDone = 0L
            val inst = mm.download("$base/redir", "m.gguf", sha(data), CancelToken()) { d, _ -> lastDone = d }
            ok(inst.verified && inst.sizeBytes == data.size.toLong() && lastDone == data.size.toLong(), "tải + xác minh SHA-256 + theo dõi tiến trình + redirect")
            ok(mm.installed().single().verified, "installed() báo đã xác minh")
            ok(mm.delete("m.gguf") && mm.installed().isEmpty(), "xóa model")

            throwsA<ModelError>("sai checksum → báo lỗi") { mm.download("$base/m.gguf", "m2.gguf", "0".repeat(64), CancelToken()) { _, _ -> } }
            ok(!File(dir, "m2.gguf").exists() && mm.installed().isEmpty(), "sai checksum → file bị xóa")

            // hủy giữa chừng rồi tải tiếp (resume)
            slow = true
            val cancel = CancelToken()
            var doneAtCancel = 0L
            throwsA<AiCancelled>("hủy tải giữa chừng") {
                mm.download("$base/m.gguf", "m3.gguf", sha(data), cancel) { d, _ -> doneAtCancel = d; if (d > 500_000) cancel.cancel() }
            }
            val partial = mm.partialBytes("m3.gguf")
            ok(partial in 1 until data.size.toLong(), "file dở được giữ ($partial byte)")
            slow = false
            var firstProgress = -1L
            val r = mm.download("$base/m.gguf", "m3.gguf", sha(data), CancelToken()) { d, _ -> if (firstProgress < 0) firstProgress = d }
            ok(r.verified && firstProgress >= partial, "tải tiếp từ vị trí dở, không tải lại từ đầu (bắt đầu ở $firstProgress ≥ $partial)")
            ok(sha(File(dir, "m3.gguf").readBytes()) == sha(data), "file sau resume đúng từng byte")

            throwsA<ModelError>("file không phải GGUF bị từ chối") { mm.download("$base/bad.gguf", "bad.gguf", null, CancelToken()) { _, _ -> } }
            val tiny = LocalModelManager(dir, allowInsecureHttp = true, freeSpace = { 1000L }, marginBytes = 0)
            val e = runCatching { tiny.download("$base/m.gguf", "m4.gguf", null, CancelToken()) { _, _ -> } }.exceptionOrNull()
            ok(e is ModelError && e.code == "no_space", "thiếu dung lượng → no_space (${(e as? ModelError)?.code})")

            val imp = mm.import(ByteArrayInputStream(data), "my model.gguf", data.size.toLong(), null, CancelToken()) { _, _ -> }
            ok(imp.fileName == "my_model.gguf" && !imp.verified, "import không có checksum → verified=false (trung thực)")
            ok(mm.installed().any { it.fileName == "my_model.gguf" && !it.verified }, "installed() không đánh dấu verified sai")
            throwsA<ModelError>("import không phải .gguf bị từ chối") { mm.import(ByteArrayInputStream(data), "a.bin", -1, null, CancelToken()) { _, _ -> } }
            throwsA<ModelError>("tên file path traversal bị chặn") { mm.import(ByteArrayInputStream(data), "../../x/..", -1, null, CancelToken()) { _, _ -> } }
            ok(ModelCatalog.PROFILES.all { it.url?.startsWith("https://huggingface.co/Qwen/") == true && it.sha256?.length == 64 }, "catalog có URL https + SHA-256 64 ký tự")
        } finally {
            server.stop(0); dir.deleteRecursively()
        }
    }

    // ---------- stores ----------
    private fun stores() {
        section("ProjectStore / CardStore / Models")
        val dir = Files.createTempDirectory("t2vstore").toFile()
        try {
            val ps = ProjectStore(dir)
            ps.save("p/../1", """{"a":1}""")
            ok(ps.load("p/../1") == """{"a":1}""" && ps.list().size == 1, "lưu/đọc project (tên bị làm sạch)")
            ps.save("p/../1", """{"a":2}""")
            ok(ps.load("p/../1") == """{"a":2}""", "ghi đè nguyên tử")
            ok(ps.delete("p/../1") && ps.load("p/../1") == null, "xóa project")
            ps.save("x", "{}"); ps.deleteAll(); ok(ps.list().isEmpty(), "xóa toàn bộ")
            val cs = CardStore(dir)
            val png = byteArrayOf(0x89.toByte(), 'P'.code.toByte(), 'N'.code.toByte(), 'G'.code.toByte(), 13, 10, 26, 10, 0, 0)
            val f = cs.save("c:1/../x", png)
            ok(f.isFile && f.parentFile == cs.dir && f.name.endsWith(".png") && f.readBytes().contentEquals(png), "card lưu theo ID, nằm trong thư mục cards")
            throwsA<IllegalArgumentException>("không phải PNG bị từ chối") { cs.save("c2", ByteArray(20)) }
            ok(cs.file("a").name != cs.file("b").name, "mỗi ID một file riêng")
            val c = CommentRecord("i", "p", null, null, "raw 😂", null, null, null, null, emptyList(), null, false, false, false)
            val back = CommentRecord.fromMap(Json.parseObject(Json.stringify(c.withTts("tts", false).toMap())))!!
            ok(back.rawText == "raw 😂" && back.ttsText == "tts" && back.likeCount == null && !back.approvedForVideo, "CommentRecord round-trip JSON, rawText/likes null giữ nguyên")
            val po = PostRecord.fromMap(Json.parseObject(Json.stringify(PostRecord("1", null, null, "t", null, null, true, false, 0.5f, listOf("a")).toMap())))!!
            ok(po.rawText == "t" && po.rankReasons == listOf("a") && po.origin == PostRecord.ORIGIN_API, "PostRecord round-trip")
        } finally { dir.deleteRecursively() }
    }
}
