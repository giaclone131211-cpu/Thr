plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.threads2video"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.threads2video"
        minSdk = 29
        targetSdk = 34
        versionCode = 4
        versionName = "2.2"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // llama.cpp/JNI chỉ được biên dịch khi bạn bật rõ ràng: gradle assembleDebug -Pt2v.llama=true -Pt2v.llamaDir=/đường/dẫn/llama.cpp
    // (cần NDK + CMake; xem README, mục "AI cục bộ"). Mặc định TẮT để bản build thường không phụ thuộc NDK và không có mã chưa thử.
    if (providers.gradleProperty("t2v.llama").orNull == "true") {
        val llamaDir = providers.gradleProperty("t2v.llamaDir").orNull ?: "${projectDir}/src/main/cpp/llama.cpp"
        defaultConfig {
            ndk { abiFilters += listOf("arm64-v8a") }
            externalNativeBuild { cmake { arguments += listOf("-DLLAMA_CPP_DIR=$llamaDir", "-DANDROID_STL=c++_shared") } }
        }
        externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.webkit:webkit:1.11.0")

    testImplementation("junit:junit:4.13.2")
}
