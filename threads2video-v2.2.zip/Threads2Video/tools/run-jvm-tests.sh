#!/usr/bin/env bash
# Biên dịch + chạy các test thuần JVM (không cần Android SDK). Dùng Kotlin compiler đi kèm Gradle.
# Cách dùng: tools/run-jvm-tests.sh [thư mục build tạm]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GL="${GRADLE_LIB:-$(dirname "$(readlink -f "$(command -v gradle)")")/../lib}"
OUT="${1:-${TMPDIR:-/tmp}/t2v-jvm-build}"
rm -rf "$OUT"; mkdir -p "$OUT"
KC="$GL/kotlin-compiler-embeddable-2.0.21.jar:$GL/kotlin-stdlib-2.0.21.jar:$GL/kotlin-script-runtime-2.0.21.jar:$GL/kotlin-reflect-2.0.21.jar:$GL/kotlin-daemon-embeddable-2.0.21.jar:$GL/trove4j-1.0.20200330.jar:$GL/annotations-24.0.1.jar:$GL/kotlinx-coroutines-core-jvm-1.6.4.jar"
# Chỉ các file không phụ thuộc android.* / androidx.* / org.json (phần Android không biên dịch được ở đây).
mapfile -t FILES < <(grep -L -E "import (android|androidx)\.|import org\.json" $(find "$ROOT/app/src/main/java" "$ROOT/app/src/test" -name '*.kt'))
java -cp "$KC" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -nowarn \
  -cp "$GL/kotlin-stdlib-2.0.21.jar:$GL/junit-4.13.2.jar" -d "$OUT" "${FILES[@]}" 2>&1 | grep -v "^Picked up" || true
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "$OUT:$GL/kotlin-stdlib-2.0.21.jar:$GL/junit-4.13.2.jar:$GL/hamcrest-core-1.3.jar" \
  org.junit.runner.JUnitCore com.threads2video.UnitTests 2>&1 | grep -v "^Picked up"
